# BenefitsBridge

**Project Name:** BenefitsBridge

**Problem:** Disabled individuals face fragmented access to healthcare benefits, support services, and assistance programs. Rules, applications, and documents are split across agencies, insurers, schools, and nonprofits, so people spend time figuring out where to start instead of getting care.

**Solution:** A personalized benefits navigation and application management platform. A person answers a short, skippable profile (or opens a fictional Georgia student profile), sees which programs may be worth exploring, tracks applications and tasks, and previews how a life change could affect what they need to re-check.

## Core Functionality

These features work in the browser, with no account and no server:

- **Onboarding.** Age, state, employment, student status, income range, insurance, support needs, and assistance goals. Every question can be skipped. A fictional demo profile, Jordan, loads a Georgia college student who uses a wheelchair, has no earned income, and is looking for healthcare, transportation, and work support.
- **Benefits matching.** `matchBenefits(profile)` returns Potential Match, More Information Needed, or Not Currently Matched. Results change when state, age, income range, insurance, student status, support needs, or goals change. Each result includes reasons, missing information, and a next action, and links to the official source.
- **Dashboard.** Overview states what may be worth exploring, which applications are in progress, what is blocked or due, and the next action.
- **Discover and program detail.** Search and filter the catalog, open a program, save it, start an application, and create tasks.
- **Application tracking.** Status, document checklist, user-entered dates, and linked tasks. The person updates the status. Nothing is synced to a government system.
- **Tasks.** Add, edit, complete, and set deadlines. Simulator questions and equipment steps can be added as tasks.
- **Life-event simulator.** `simulateLifeEvent(profile, event)` covers starting a job, losing a job, an income increase, moving states, and a coverage renewal. It shows a before/after snapshot from those inputs, programs that may need another look, missing information, questions to verify, and suggested tasks. It does not predict benefit losses, approvals, dates, or dollar amounts.
- **Equipment access.** For a mobility device, the person compares Georgia Medicaid, Tools for Life, and vocational rehabilitation; checks off documentation and authorization questions to verify; and records whether they have confirmed funding information or a supplier name. Those notes are the user’s, not a coverage decision.

## Significance

BenefitsBridge helps someone move from a scattered list of programs to a short set of possible fits, a document checklist, and a next step. It is aimed at the administrative barrier in front of healthcare: knowing which office to contact, which facts are still missing, and what to re-check after a job, a move, or a renewal.

## Medical Supply Chain Connection

Assistive technology and durable medical equipment reach a person only after several administrative steps: a coverage or assistance pathway, documentation a payer asks for, authorization when a payer requires it, and a supplier or reuse program the person has actually contacted. Those steps sit in front of the medical supply chain. A wheelchair is not delivered because a website listed it. It moves when a payer, a clinician’s documentation, and a supplier or loan program line up.

BenefitsBridge addresses that front end. The equipment checklist points to real pathways (Georgia Medicaid, Tools for Life at Georgia Tech, and Georgia Vocational Rehabilitation), asks the person to confirm documentation and authorization with those sources, and lets them record whether funding details or a supplier name have been confirmed. It does not manage supplier logistics, inventory, shipping, claims, or orders.

## Technology

React 18, TypeScript, Tailwind CSS 3, and Vite 5. Matching and simulation run in the browser. Profile, applications, tasks, and equipment notes stay in `sessionStorage`. Display preferences stay in `localStorage`. Routing is hash-based, so the production build can be hosted as static files.

## Limitations

- Results are not official eligibility or approval. Only the program can decide.
- The catalog is a small, Georgia-first set of real programs. Descriptions are plain-language summaries. They do not state income thresholds, benefit amounts, or dates. Unverified rules are shown as missing information, with a link to the official site.
- The demonstration profile and all saved dates are fictional.
- There is no connection to Medicaid, Social Security, insurers, or suppliers.
- Equipment notes are what the person records. The app cannot confirm coverage, inventory, or an order.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:5173 and choose **Explore the demo as Jordan**.

Production build: `npm run build`, then `npm run preview`. The `dist/` folder is static. Hash routes (`#/app/overview`) do not need server rewrites.
