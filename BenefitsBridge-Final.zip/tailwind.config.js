/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        canvas: '#F8FAFC',
        ink: '#101828',
        muted: '#64748B',
        line: '#E2E8F0',
        night: { DEFAULT: '#111827', 2: '#1F2937', 3: '#374151' },
        brand: { DEFAULT: '#5146E5', hover: '#4338CA', soft: '#EEF0FF', ring: '#A5B4FC' },
        positive: { DEFAULT: '#07876D', ink: '#066B57', soft: '#E7F6F1' },
        caution: { ink: '#92400E', soft: '#FEF3C7', line: '#F5D78E' },
        danger: { ink: '#B42318', soft: '#FEF3F2' },
      },
      fontFamily: {
        sans: ['Geist', 'Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"Geist Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: { DEFAULT: '6px', md: '8px', lg: '10px', xl: '14px' },
      boxShadow: {
        card: '0 1px 2px rgba(16,24,40,0.04)',
        raised: '0 1px 2px rgba(16,24,40,0.05), 0 8px 24px -8px rgba(16,24,40,0.12)',
      },
    },
  },
  plugins: [],
};
