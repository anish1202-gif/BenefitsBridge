# BenefitsBridge

**Your benefits. Your healthcare. One clear path.**

A disability-benefits and healthcare-access command center: discover programs that may fit, track applications and documents, manage tasks and dates, and explore how life changes might affect your support.

Hackathon frontend — React 18 · TypeScript · Tailwind CSS 3 · Lucide icons · Vite 5. No backend, no account, no external state library.

---

## Quick start

```bash
npm install
npm run dev          # http://localhost:5173
```

| Script | What it does |
| --- | --- |
| `npm run dev` | Dev server with hot reload |
| `npm run build` | Typecheck + production build to `dist/` |
| `npm run build:single` | Typecheck + one self-contained `dist-single/index.html` (handy for sharing a demo) |
| `npm run preview` | Serve the production build |
| `npm run typecheck` | `tsc --noEmit` |

Requires Node 18+. Routing is hash-based (`#/app/overview`), so `dist/` works on any static host (Netlify, Vercel, GitHub Pages, S3) with no rewrite rules.

## Demo journey (≈2 minutes)

1. Open the landing page → **Explore the demo as Jordan** (fictional 19-year-old Georgia college student, wheelchair user, no earned income).
2. **Overview** — what is in progress, what is blocked, possible fits, and the next move.
3. **Discover Benefits** → filter *Transportation* → open **MARTA Mobility Paratransit**.
4. Review overview, reasons, missing info, documents, official link → **Save**.
5. **Track application** (creates a document checklist) and **Create application tasks**.
6. **Life Simulator** → *Start a job* → change hours / pay / employer coverage → review before/after, affected programs, *Needs verification*, questions → **Add all** tasks.
7. **Equipment Access** (also under More on a phone) → check off administrative steps for a mobility device, record whether funding or a supplier name has been confirmed, and add the open steps as tasks.
8. Back to **Overview** — new tasks appear in Next moves.

Or choose **Set up your own profile** for the 5-step onboarding (every question skippable, “Why we ask” on each).

## Project structure

```
src/
  components/            Shared design system
    AppShell.tsx           Sidebar (desktop), top bar + bottom nav + "More" sheet (mobile), skip link
    Button.tsx             Button, LinkButton (external links announce "opens in a new tab"), IconButton
    Field.tsx              TextField, SelectField, ChoiceGroup (radio), CheckGroup, Switch — labelled, with hint/error wiring
    Dialog.tsx             Native <dialog> modal: focus containment, Esc, focus return
    Toast.tsx              Polite live-region notifications with Undo actions
    Badges.tsx             MatchBadge / AppStatusBadge / ImpactBadge — icon + text, never color alone
    Primitives.tsx         PageHeader (focus on navigation), Panel, ProgressBar, StatusPath, EmptyState, Notice, Logo
  pages/                 Screens: Landing, Onboarding, Overview, Discover, ProgramDetail,
                         MyBenefits, Applications, Equipment, Simulator, Tasks, Settings
  features/
    onboarding/            Step definitions + reusable profile fields (also used in Settings)
    dashboard/             Next moves and related dashboard sections
    benefits/              ProgramCard, SaveButton, skeletons
    applications/          ApplicationCard (status, stage path, documents, linked tasks, key date)
    tasks/                 TaskComposer (shared create/edit dialog), TaskRow
  types/index.ts         Shared domain contract (Profile, MatchResult, LifeEvent, SimulationResult, …)
  lib/
    integration.ts         Integration boundary: matchBenefits and simulateLifeEvent
    demo/demoMatcher.ts    In-browser matcher (deterministic signals, not an official decision)
    demo/demoSimulator.ts  In-browser life-event simulator (qualitative only)
    equipment.ts           Mobility-device checklist steps (user-recorded)
    programs.ts            Program catalog (illustrative summaries + official URLs)
    store.tsx              Context + reducer state, match loading/error state
    demoProfile.ts         Fictional Jordan profile and seed data (dates relative to today)
    router.tsx, dates.ts, labels.ts
```

## Integrating the real engines

The UI calls **only** these two functions, from `src/lib/integration.ts`:

```ts
matchBenefits(profile: Profile): Promise<MatchResponse>
simulateLifeEvent(profile: Profile, event: LifeEvent): Promise<SimulationResult>
```

Types are in `src/types/index.ts`. To plug in the real modules, register them once in `src/main.tsx`:

```ts
import { registerBenefitsMatcher, registerLifeEventSimulator } from './lib/integration';
import { matcher } from '../path/to/teammate/matcher';
import { simulator } from '../path/to/teammate/simulator';

registerBenefitsMatcher(matcher);
registerLifeEventSimulator(simulator);
```

Settings → **Integrations** shows whether each one is the *Demo adapter* or *Live*.

Contract rules the UI relies on:

- `MatchStatus` is only `potential_match | more_info_needed | not_matched`. Don't return "approved"/"eligible".
- `MatchResult.missingInfo` feeds “Still needed” on cards and the dashboard's *Information still missing* panel.
- `SimulationResult.affectedPrograms[].impact` is `review | needs_verification | no_link_identified`. Use `needs_verification` plus an `unknowns` entry when data is insufficient. Don't return dates, probabilities or dollar outcomes.
- Throwing/rejecting is fine — the UI shows an error state with **Try again**. Loading states are shown while promises are pending.
- `before`/`after` snapshots must be the same length and order (rendered as a comparison table).

The demo adapters are clearly labelled, never apply real limits, and nothing in this repo implements eligibility rules, so there is nothing of the backend to overwrite.

## Program data

All 13 program descriptions in `src/lib/programs.ts` are **illustrative** (`sourceStatus: 'illustrative'`) and avoid figures, thresholds and dates. Each shows an *Illustrative* notice on its detail page and links to the official site (medicaid.georgia.gov, ssa.gov/ssi, gvs.georgia.gov, itsmarta.com, gatfl.gatech.edu, healthcare.gov, studentaid.gov, …). If your team adds a verified source, mark only those records `verified`.

## Accessibility (targeting WCAG 2.2 AA)

- Semantic landmarks, one `h1` per screen, logical heading order; skip link.
- On every route change focus moves to the page heading and `document.title` updates.
- Full keyboard support: native radios/checkboxes styled as large targets, `aria-pressed` filter chips, native `<dialog>` modals with Esc and focus return.
- Visible 3px focus ring everywhere (lighter variant on dark surfaces).
- Statuses always combine icon + text; contrast checked for text tokens (body slate ≥ 4.5:1; emerald text uses a darker ink).
- Errors are announced with `aria-invalid` + `aria-describedby`; focus moves to the invalid field.
- Live regions for toasts, result counts and simulator updates.
- Text size (Default / Large / Larger — rem-based, layouts reflow), Simplified interface, Reduce motion (also honours `prefers-reduced-motion`), forced-colors fallback.
- Targets ≥ 36px (most 44px); mobile bottom nav is 64px tall.

## Privacy

- No account, no server calls. App data lives in `sessionStorage` (survives refresh, cleared when the tab closes); only display preferences use `localStorage`.
- Onboarding asks about *support needs*, never diagnoses, records, or ID numbers. Income is a range.

## PWA readiness

`public/manifest.webmanifest` is in place and routing is static-host friendly. To make it installable: add icons to the manifest and a service worker (e.g. `vite-plugin-pwa`).

## Known limits

- Program catalog is Georgia-first; other states see national programs plus "Not Currently Matched" for Georgia ones.
- Matching and the life simulator run in the browser. They are not official eligibility decisions and do not use unpublished income limits.
- Equipment Access records steps you verify yourself. It does not check supplier inventory, approve claims, or place orders.
- Display fonts: Atkinson Hyperlegible and Schibsted Grotesk are local; Geist falls back to Inter/system UI if it is not installed.
