import { useEffect } from 'react';
import { Compass } from 'lucide-react';
import { useRoute, navigate } from './lib/router';
import { useStore } from './lib/store';
import { AppShell } from './components/AppShell';
import { EmptyState } from './components/Primitives';
import { LinkButton } from './components/Button';
import { LandingPage } from './pages/Landing';
import { OnboardingPage } from './pages/Onboarding';
import { OverviewPage } from './pages/Overview';
import { DiscoverPage } from './pages/Discover';
import { ProgramDetailPage } from './pages/ProgramDetail';
import { MyBenefitsPage } from './pages/MyBenefits';
import { ApplicationsPage } from './pages/Applications';
import { EquipmentPage } from './pages/Equipment';
import { SimulatorPage } from './pages/Simulator';
import { TasksPage } from './pages/Tasks';
import { SettingsPage } from './pages/Settings';

export default function App() {
  const path = useRoute();
  const { state } = useStore();
  const parts = path.split('/').filter(Boolean); // e.g. ['app', 'discover', 'ssi']

  const inApp = parts[0] === 'app';
  const needsProfile = inApp && !state.profile;

  useEffect(() => {
    if (needsProfile) navigate('/onboarding');
  }, [needsProfile]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [path]);

  if (parts.length === 0) return <LandingPage />;
  if (parts[0] === 'onboarding') return <OnboardingPage />;
  if (!inApp || needsProfile) {
    if (needsProfile) return null;
    return <NotFound />;
  }

  const section = parts[1] ?? 'overview';
  let page: JSX.Element;
  switch (section) {
    case 'overview':
      page = <OverviewPage />;
      break;
    case 'discover':
      page = parts[2] ? <ProgramDetailPage key={parts[2]} id={parts[2]} /> : <DiscoverPage />;
      break;
    case 'benefits':
      page = <MyBenefitsPage />;
      break;
    case 'applications':
      page = <ApplicationsPage />;
      break;
    case 'equipment':
      page = <EquipmentPage />;
      break;
    case 'simulator':
      page = <SimulatorPage />;
      break;
    case 'tasks':
      page = <TasksPage />;
      break;
    case 'settings':
      page = <SettingsPage />;
      break;
    default:
      page = <NotFoundBody />;
  }

  return <AppShell section={section}>{page}</AppShell>;
}

function NotFoundBody() {
  return (
    <EmptyState icon={<Compass className="h-5 w-5" />} title="Page not found" action={<LinkButton href="#/app/overview" variant="primary">Go to overview</LinkButton>}>
      That page doesn’t exist. Your data is safe.
    </EmptyState>
  );
}

function NotFound() {
  return (
    <main className="mx-auto max-w-lg px-4 py-24">
      <NotFoundBody />
    </main>
  );
}
