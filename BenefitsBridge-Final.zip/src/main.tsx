import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { StoreProvider } from './lib/store';
import { ToastProvider } from './components/Toast';
import { TaskComposerProvider } from './features/tasks/TaskComposer';
import './index.css';

// ── Integration point ──────────────────────────────────────────────
// When teammates' modules are ready, register them here, e.g.:
//   import { registerBenefitsMatcher, registerLifeEventSimulator } from './lib/integration';
//   registerBenefitsMatcher(realMatcher);
//   registerLifeEventSimulator(realSimulator);
// ───────────────────────────────────────────────────────────────────

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <StoreProvider>
      <ToastProvider>
        <TaskComposerProvider>
          <App />
        </TaskComposerProvider>
      </ToastProvider>
    </StoreProvider>
  </React.StrictMode>,
);
