import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Check, Plus, Trash2, X } from 'lucide-react';
import type { Application, ApplicationStatus } from '../../types';
import { useStore } from '../../lib/store';
import { getProgram } from '../../lib/programs';
import { APP_STATUS_LABEL, APP_STATUS_ORDER } from '../../lib/labels';
import { formatDate } from '../../lib/dates';
import { Link } from '../../lib/router';
import { Button, IconButton, LinkButton } from '../../components/Button';
import { ProgressBar, StatusPath } from '../../components/Primitives';
import { SelectField, TextField } from '../../components/Field';
import { Dialog } from '../../components/Dialog';
import { useToast } from '../../components/Toast';
import { useTaskComposer } from '../tasks/TaskComposer';
import { TaskRow } from '../tasks/TaskRow';
import { cx } from '../../components/cx';

export function ApplicationCard({ app, focused }: { app: Application; focused?: boolean }) {
  const { state, dispatch } = useStore();
  const notify = useToast();
  const compose = useTaskComposer();
  const program = getProgram(app.programId)!;
  const [newDoc, setNewDoc] = useState('');
  const [docError, setDocError] = useState<string>();
  const [confirmRemove, setConfirmRemove] = useState(false);
  const ref = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (focused && ref.current) {
      ref.current.scrollIntoView({ block: 'start' });
      ref.current.focus({ preventScroll: true });
    }
  }, [focused]);

  const tasks = state.tasks.filter((t) => t.programId === app.programId);
  const docsDone = app.documents.filter((d) => d.done).length;
  const tasksDone = tasks.filter((t) => t.done).length;
  const totalSteps = app.documents.length + tasks.length;
  const doneSteps = docsDone + tasksDone;

  const addDoc = (e: FormEvent) => {
    e.preventDefault();
    const label = newDoc.trim();
    if (!label) {
      setDocError('Enter a document name.');
      return;
    }
    dispatch({ type: 'addDoc', appId: app.id, label });
    setNewDoc('');
    setDocError(undefined);
    notify(`Added “${label}” to the checklist.`);
  };

  const setStatus = (s: ApplicationStatus) => {
    dispatch({ type: 'setAppStatus', id: app.id, status: s });
    notify(`${program.name}: status set to ${APP_STATUS_LABEL[s]}.`);
  };

  const hid = `app-${app.id}-title`;

  return (
    <article aria-labelledby={hid} className={cx('scroll-mt-24 rounded-lg border bg-white shadow-card', focused ? 'border-brand/50 ring-4 ring-brand/10' : 'border-line')}>
      <header className="flex flex-col gap-4 border-b border-line p-5 md:flex-row md:items-start md:justify-between">
        <div className="min-w-0">
          <h2 id={hid} ref={ref} tabIndex={-1} className="text-lg font-semibold leading-snug">
            <Link to={`/app/discover/${program.id}`} className="hover:underline underline-offset-4">
              {program.name}
            </Link>
          </h2>
          <p className="mt-0.5 text-sm text-muted">
            {program.provider} · Updated {formatDate(app.updatedAt.slice(0, 10))}
          </p>
        </div>
        <div className="w-full md:w-60">
          <SelectField label="Your reported status" value={app.status} onChange={(e) => setStatus(e.target.value as ApplicationStatus)}>
            {APP_STATUS_ORDER.map((s) => (
              <option key={s} value={s}>
                {APP_STATUS_LABEL[s]}
              </option>
            ))}
          </SelectField>
        </div>
      </header>

      <div className="border-b border-line px-5 py-6">
        <StatusPath status={app.status} />
        <div className="mt-6 flex items-center gap-3">
          <div className="flex-1">
            <ProgressBar value={doneSteps} max={totalSteps} label={`${program.name} checklist progress`} />
          </div>
          <span className="whitespace-nowrap text-sm text-muted tnum">
            {doneSteps} of {totalSteps} steps done
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 [&>*]:min-w-0">
        {/* Documents */}
        <section aria-labelledby={`${hid}-docs`} className="border-b border-line p-5 md:border-b-0 md:border-r">
          <h3 id={`${hid}-docs`} className="mb-3 text-[0.9375rem] font-semibold">
            Documents <span className="font-normal text-muted tnum">· {docsDone}/{app.documents.length}</span>
          </h3>
          <ul className="space-y-1">
            {app.documents.map((d) => {
              const cid = `${app.id}-${d.id}`;
              return (
                <li key={d.id} className="group flex items-center gap-3 rounded-md px-1 py-1.5 hover:bg-slate-50">
                  <span className="relative flex">
                    <input
                      id={cid}
                      type="checkbox"
                      checked={d.done}
                      onChange={() => dispatch({ type: 'toggleDoc', appId: app.id, docId: d.id })}
                      className="peer h-5 w-5 cursor-pointer appearance-none rounded border-2 border-slate-300 bg-white checked:border-positive checked:bg-positive"
                    />
                    <Check aria-hidden strokeWidth={3} className="pointer-events-none absolute left-1 top-1 hidden h-3 w-3 text-white peer-checked:block" />
                  </span>
                  <label htmlFor={cid} className={cx('flex-1 cursor-pointer text-[0.9375rem]', d.done && 'text-muted line-through decoration-slate-400')}>
                    {d.label}
                  </label>
                  <IconButton label={`Remove “${d.label}”`} className="h-8 w-8" onClick={() => dispatch({ type: 'removeDoc', appId: app.id, docId: d.id })}>
                    <X aria-hidden className="h-4 w-4" />
                  </IconButton>
                </li>
              );
            })}
          </ul>
          <form onSubmit={addDoc} className="mt-3 flex items-start gap-2" noValidate>
            <TextField
              label="Add a document"
              className="min-w-0 flex-1 [&_label]:sr-only"
              placeholder="Add a document"
              value={newDoc}
              onChange={(e) => setNewDoc(e.target.value)}
              error={docError}
            />
            <Button type="submit" className="mt-0" icon={<Plus aria-hidden className="h-4 w-4" />}>
              Add
            </Button>
          </form>
        </section>

        {/* Tasks + dates */}
        <section aria-labelledby={`${hid}-tasks`} className="flex flex-col">
          <div className="flex items-center justify-between px-5 pt-5">
            <h3 id={`${hid}-tasks`} className="text-[0.9375rem] font-semibold">
              Tasks <span className="font-normal text-muted tnum">· {tasksDone}/{tasks.length}</span>
            </h3>
            <Button size="sm" variant="ghost" onClick={() => compose({ programId: program.id })} icon={<Plus aria-hidden className="h-4 w-4" />}>
              Add<span className="sr-only"> task for {program.name}</span>
            </Button>
          </div>
          {tasks.length ? (
            <ul className="-mx-0 mt-1 divide-y divide-line">
              {tasks.map((t) => (
                <TaskRow key={t.id} task={t} />
              ))}
            </ul>
          ) : (
            <p className="px-5 py-3 text-sm text-muted">No tasks linked yet.</p>
          )}

          <div className="mt-auto grid grid-cols-1 gap-3 border-t border-line p-5 sm:grid-cols-2 [&>*]:min-w-0">
            <TextField
              label="Key date label"
              optional
              placeholder="e.g. Submitted on"
              value={app.keyDateLabel ?? ''}
              onChange={(e) => dispatch({ type: 'updateApplication', id: app.id, patch: { keyDateLabel: e.target.value } })}
            />
            <TextField
              label="Date"
              optional
              type="date"
              value={app.keyDate ?? ''}
              onChange={(e) => dispatch({ type: 'updateApplication', id: app.id, patch: { keyDate: e.target.value || undefined } })}
            />
          </div>
        </section>
      </div>

      <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-line bg-canvas px-5 py-3 rounded-b-lg">
        {program.officialUrl ? (
          <LinkButton href={program.officialUrl} external size="sm" variant="ghost" className="-ml-2 h-auto min-h-9 whitespace-normal py-1.5 text-left">
            Apply or learn more at {program.officialLabel}
          </LinkButton>
        ) : (
          <span className="text-sm text-muted">Contact the provider to apply.</span>
        )}
        <Button size="sm" variant="ghost" className="text-danger-ink hover:bg-danger-soft" onClick={() => setConfirmRemove(true)} icon={<Trash2 aria-hidden className="h-4 w-4" />}>
          Stop tracking
        </Button>
      </footer>

      <Dialog
        open={confirmRemove}
        onClose={() => setConfirmRemove(false)}
        title="Stop tracking this application?"
        description={`The checklist for ${program.name} will be removed. Your tasks and saved program stay.`}
        size="sm"
        footer={
          <>
            <Button onClick={() => setConfirmRemove(false)}>Keep tracking</Button>
            <Button
              variant="danger"
              onClick={() => {
                setConfirmRemove(false);
                dispatch({ type: 'removeApplication', id: app.id });
                notify(`Stopped tracking ${program.name}.`);
              }}
            >
              Stop tracking
            </Button>
          </>
        }
      >
        <p className="text-sm text-slate-700">This only affects BenefitsBridge. It doesn’t withdraw anything you’ve submitted to the program.</p>
      </Dialog>
    </article>
  );
}
