import type { BenefitCategory, EmploymentStatus, IncomeRange, InsuranceStatus, Profile, StudentStatus, SupportNeed } from '../../types';
import { CheckGroup, ChoiceGroup, SelectField, TextField } from '../../components/Field';
import { CATEGORY_LABEL, EMPLOYMENT_LABEL, INCOME_LABEL, INSURANCE_LABEL, STUDENT_LABEL, SUPPORT_LABEL, US_STATES } from '../../lib/labels';

export const STEPS = [
  {
    key: 'basics',
    title: 'Where you live',
    lede: 'Many programs are run by your state, so location shapes everything else.',
    why: 'State decides which Medicaid, transit and vocational programs apply. Age affects programs such as student services and ABLE accounts. Your name is only used to greet you.',
  },
  {
    key: 'work',
    title: 'Work and school',
    lede: 'Some programs support people who are working, studying, or both.',
    why: 'Employment and enrollment change which employment services, student exemptions and work incentives may be relevant.',
  },
  {
    key: 'money',
    title: 'Income and coverage',
    lede: 'A range is enough. We never ask for exact figures or account details.',
    why: 'Many health and financial programs consider income. Knowing your current coverage helps avoid suggesting things you already have.',
  },
  {
    key: 'support',
    title: 'Support needs',
    lede: 'Choose the kinds of support that matter to you. No diagnosis needed.',
    why: 'This helps surface transportation, assistive technology and employment supports. We don’t ask about medical conditions.',
  },
  {
    key: 'goals',
    title: 'What you’re looking for',
    lede: 'We’ll put these categories first. You can still browse everything.',
    why: 'Prioritizing your goals keeps the dashboard focused on what you came for.',
  },
] as const;

export type AgeError = string | undefined;

export function validateAge(raw: string): { age?: number; error?: string } {
  if (raw.trim() === '') return {};
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 0 || n > 120) return { error: 'Enter your age as a whole number between 0 and 120, or leave it blank.' };
  return { age: n };
}

export function StepFields({
  step,
  profile,
  onChange,
  ageText,
  setAgeText,
  ageError,
}: {
  step: number;
  profile: Profile;
  onChange: (p: Profile) => void;
  ageText: string;
  setAgeText: (s: string) => void;
  ageError?: string;
}) {
  const set = (patch: Partial<Profile>) => onChange({ ...profile, ...patch });

  switch (STEPS[step].key) {
    case 'basics':
      return (
        <div className="space-y-5">
          <TextField label="What should we call you?" optional autoComplete="given-name" value={profile.firstName ?? ''} onChange={(e) => set({ firstName: e.target.value })} />
          <div className="grid gap-5 sm:grid-cols-2">
            <SelectField label="State" optional value={profile.state ?? ''} onChange={(e) => set({ state: e.target.value || undefined })}>
              <option value="">Select a state</option>
              {US_STATES.map(([c, n]) => (
                <option key={c} value={c}>
                  {n}
                </option>
              ))}
            </SelectField>
            <TextField
              id="age-input"
              label="Age"
              optional
              inputMode="numeric"
              value={ageText}
              onChange={(e) => setAgeText(e.target.value)}
              error={ageError}
              hint="Whole years."
            />
          </div>
          {profile.state && profile.state !== 'GA' && (
            <p className="rounded-md bg-slate-50 px-3 py-2.5 text-sm text-slate-700">
              Our program library is Georgia-first right now. National programs will still appear for you.
            </p>
          )}
        </div>
      );
    case 'work':
      return (
        <div className="space-y-7">
          <ChoiceGroup<EmploymentStatus>
            legend="Employment"
            name="employment"
            value={profile.employment}
            onChange={(v) => set({ employment: v })}
            options={(Object.keys(EMPLOYMENT_LABEL) as EmploymentStatus[]).map((v) => ({ value: v, label: EMPLOYMENT_LABEL[v] }))}
            columns={2}
          />
          <ChoiceGroup<StudentStatus>
            legend="Are you a student?"
            name="student"
            value={profile.student}
            onChange={(v) => set({ student: v })}
            options={(Object.keys(STUDENT_LABEL) as StudentStatus[]).map((v) => ({ value: v, label: STUDENT_LABEL[v] }))}
            columns={2}
          />
        </div>
      );
    case 'money':
      return (
        <div className="space-y-7">
          <ChoiceGroup<IncomeRange>
            legend="Your monthly earned income"
            hint="Before taxes, from work. Leave it blank if you’d rather not say."
            name="income"
            value={profile.monthlyIncome}
            onChange={(v) => set({ monthlyIncome: v })}
            options={(Object.keys(INCOME_LABEL) as IncomeRange[]).map((v) => ({ value: v, label: INCOME_LABEL[v] }))}
            columns={2}
          />
          <ChoiceGroup<InsuranceStatus>
            legend="Current health coverage"
            name="insurance"
            value={profile.insurance}
            onChange={(v) => set({ insurance: v })}
            options={(Object.keys(INSURANCE_LABEL) as InsuranceStatus[]).map((v) => ({ value: v, label: INSURANCE_LABEL[v] }))}
            columns={2}
          />
        </div>
      );
    case 'support':
      return (
        <CheckGroup<SupportNeed>
          legend="Support needs"
          hint="Select all that apply."
          values={profile.supportNeeds}
          onChange={(v) => set({ supportNeeds: v })}
          options={(Object.keys(SUPPORT_LABEL) as SupportNeed[]).map((v) => ({ value: v, label: SUPPORT_LABEL[v] }))}
        />
      );
    case 'goals':
      return (
        <CheckGroup<BenefitCategory>
          legend="Types of help"
          hint="Select all that apply."
          values={profile.assistanceSought}
          onChange={(v) => set({ assistanceSought: v })}
          options={(Object.keys(CATEGORY_LABEL) as BenefitCategory[]).map((v) => ({ value: v, label: CATEGORY_LABEL[v] }))}
        />
      );
  }
}
