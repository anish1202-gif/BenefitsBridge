import { ArrowRight, Bookmark, BookmarkCheck, CircleHelp } from 'lucide-react';
import type { MatchResult, Program } from '../../types';
import { useStore } from '../../lib/store';
import { CATEGORY_LABEL } from '../../lib/labels';
import { Link } from '../../lib/router';
import { MatchBadge } from '../../components/Badges';
import { Button, LinkButton } from '../../components/Button';
import { useToast } from '../../components/Toast';
import { cx } from '../../components/cx';

export function useSaveToggle() {
  const { state, dispatch } = useStore();
  const notify = useToast();
  return (program: Program) => {
    const was = state.saved.includes(program.id);
    dispatch({ type: 'toggleSave', programId: program.id });
    notify(was ? `Removed ${program.name} from My Benefits.` : `Saved ${program.name} to My Benefits.`, {
      label: 'Undo',
      onClick: () => dispatch({ type: 'toggleSave', programId: program.id }),
    });
  };
}

export function SaveButton({ program, size = 'sm', className }: { program: Program; size?: 'sm' | 'md'; className?: string }) {
  const { state } = useStore();
  const toggle = useSaveToggle();
  const saved = state.saved.includes(program.id);
  return (
    <Button
      size={size}
      variant="secondary"
      aria-pressed={saved}
      onClick={() => toggle(program)}
      className={className}
      icon={saved ? <BookmarkCheck aria-hidden className="h-4 w-4 text-brand" /> : <Bookmark aria-hidden className="h-4 w-4" />}
    >
      {saved ? 'Saved' : 'Save'}
      <span className="sr-only"> {program.name}</span>
    </Button>
  );
}

/** Information-rich program card used on Discover and the Overview. */
export function ProgramCard({ program, match, headingLevel = 3 }: { program: Program; match?: MatchResult; headingLevel?: 2 | 3 }) {
  const H = headingLevel === 2 ? 'h2' : 'h3';
  const muted = match?.status === 'not_matched';
  return (
    <article className={cx('flex h-full flex-col rounded-lg border border-line bg-white p-5 shadow-card transition-shadow hover:shadow-raised', muted && 'bg-slate-50/60')}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-[0.8125rem] font-medium text-muted">
          {CATEGORY_LABEL[program.category]} · {program.jurisdiction === 'US' ? 'National' : program.jurisdiction}
        </p>
        {match && <MatchBadge status={match.status} />}
      </div>

      <H className="mt-3 text-[1.0625rem] font-semibold leading-snug">
        <Link to={`/app/discover/${program.id}`} className="rounded-sm hover:underline decoration-slate-300 underline-offset-4">
          {program.name}
        </Link>
      </H>

      {match && (
        <div className="mt-2.5 space-y-2.5 text-sm">
          <p className="text-slate-700">
            <span className="sr-only">Why it surfaced: </span>
            {match.reasons.slice(0, 2).join(' ')}
          </p>
          {match.missingInfo.length > 0 && (
            <p className="detail flex gap-2 text-slate-700">
              <CircleHelp aria-hidden className="mt-0.5 h-4 w-4 shrink-0 text-caution-ink" />
              <span>
                <span className="font-medium text-ink">Still needed: </span>
                {match.missingInfo.join(', ')}
              </span>
            </p>
          )}
        </div>
      )}

      <div className="mt-auto pt-4">
        {match && match.status !== 'not_matched' && (
          <p className="detail mb-4 border-t border-line pt-3 text-sm">
            <span className="font-medium">Next: </span>
            <span className="text-slate-700">{match.nextAction}</span>
          </p>
        )}
        <div className="flex flex-wrap items-center gap-2">
          <LinkButton href={`#/app/discover/${program.id}`} size="sm" variant="primary" className="flex-1 sm:flex-none">
            View details <ArrowRight aria-hidden className="h-4 w-4" />
            <span className="sr-only"> for {program.name}</span>
          </LinkButton>
          <SaveButton program={program} />
          {program.officialUrl && (
            <LinkButton href={program.officialUrl} external size="sm" variant="ghost" className="detail">
              Official site
            </LinkButton>
          )}
        </div>
      </div>
    </article>
  );
}

export function ProgramCardSkeleton() {
  return (
    <div className="rounded-lg border border-line bg-white p-5" aria-hidden>
      <div className="flex justify-between">
        <div className="skeleton h-4 w-32" />
        <div className="skeleton h-6 w-28 rounded-full" />
      </div>
      <div className="skeleton mt-4 h-5 w-3/4" />
      <div className="skeleton mt-3 h-4 w-full" />
      <div className="skeleton mt-2 h-4 w-5/6" />
      <div className="mt-6 flex gap-2">
        <div className="skeleton h-9 w-28" />
        <div className="skeleton h-9 w-20" />
      </div>
    </div>
  );
}
