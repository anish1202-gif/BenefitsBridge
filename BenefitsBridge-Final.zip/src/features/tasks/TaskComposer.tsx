import { createContext, useCallback, useContext, useState, type FormEvent, type ReactNode } from 'react';
import { Dialog } from '../../components/Dialog';
import { Button } from '../../components/Button';
import { SelectField, TextField } from '../../components/Field';
import { useStore } from '../../lib/store';
import { useToast } from '../../components/Toast';
import { PROGRAMS } from '../../lib/programs';
import type { Task, TaskPriority } from '../../types';
import { navigate } from '../../lib/router';

interface Draft {
  id?: string;
  title?: string;
  programId?: string;
  dueDate?: string;
  priority?: TaskPriority;
}

const Ctx = createContext<(draft?: Draft) => void>(() => {});
export const useTaskComposer = () => useContext(Ctx);

/** One shared, accessible dialog for creating and editing tasks from anywhere in the app. */
export function TaskComposerProvider({ children }: { children: ReactNode }) {
  const { state, dispatch } = useStore();
  const notify = useToast();
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Draft>({});
  const [error, setError] = useState<string>();

  const openComposer = useCallback((d: Draft = {}) => {
    setDraft({ priority: 'normal', ...d });
    setError(undefined);
    setOpen(true);
  }, []);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const title = (draft.title ?? '').trim();
    if (!title) {
      setError('Enter a short description of the task.');
      (document.getElementById('task-title') as HTMLInputElement | null)?.focus();
      return;
    }
    const payload: Partial<Task> = {
      title,
      programId: draft.programId || undefined,
      dueDate: draft.dueDate || undefined,
      priority: draft.priority ?? 'normal',
    };
    if (draft.id) {
      dispatch({ type: 'updateTask', id: draft.id, patch: payload });
      notify('Task updated.');
    } else {
      dispatch({ type: 'addTask', task: { ...(payload as Required<Pick<Task, 'title' | 'priority'>>), programId: payload.programId, dueDate: payload.dueDate, source: 'user' } });
      notify(`Task added: “${title}”`, { label: 'View tasks', onClick: () => navigate('/app/tasks') });
    }
    setOpen(false);
  };

  const savedFirst = [...PROGRAMS].sort((a, b) => Number(state.saved.includes(b.id)) - Number(state.saved.includes(a.id)));

  return (
    <Ctx.Provider value={openComposer}>
      {children}
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title={draft.id ? 'Edit task' : 'New task'}
        description="Tasks and dates are yours to set. They aren’t official program deadlines."
        footer={
          <>
            <Button onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" type="submit" form="task-form">
              {draft.id ? 'Save changes' : 'Add task'}
            </Button>
          </>
        }
      >
        <form id="task-form" onSubmit={submit} noValidate className="space-y-4">
          <TextField
            id="task-title"
            label="Task"
            value={draft.title ?? ''}
            onChange={(e) => {
              setDraft({ ...draft, title: e.target.value });
              if (error) setError(undefined);
            }}
            error={error}
            placeholder="e.g. Call GVRA to schedule intake"
            autoComplete="off"
            required
          />
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField label="Due date" optional type="date" value={draft.dueDate ?? ''} onChange={(e) => setDraft({ ...draft, dueDate: e.target.value })} />
            <SelectField label="Priority" value={draft.priority ?? 'normal'} onChange={(e) => setDraft({ ...draft, priority: e.target.value as TaskPriority })}>
              <option value="normal">Normal</option>
              <option value="high">High</option>
            </SelectField>
          </div>
          <SelectField label="Related program" optional value={draft.programId ?? ''} onChange={(e) => setDraft({ ...draft, programId: e.target.value })}>
            <option value="">None</option>
            {savedFirst.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
                {state.saved.includes(p.id) ? ' (saved)' : ''}
              </option>
            ))}
          </SelectField>
        </form>
      </Dialog>
    </Ctx.Provider>
  );
}
