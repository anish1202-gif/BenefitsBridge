import { Check, Pencil, Trash2, Flag } from 'lucide-react';
import type { Task } from '../../types';
import { useStore } from '../../lib/store';
import { getProgram } from '../../lib/programs';
import { daysUntil, formatDate, relativeDue } from '../../lib/dates';
import { Link } from '../../lib/router';
import { IconButton } from '../../components/Button';
import { useToast } from '../../components/Toast';
import { useTaskComposer } from './TaskComposer';
import { cx } from '../../components/cx';

export function TaskRow({ task, showActions = true }: { task: Task; showActions?: boolean }) {
  const { dispatch } = useStore();
  const notify = useToast();
  const compose = useTaskComposer();
  const program = task.programId ? getProgram(task.programId) : undefined;
  const d = task.dueDate ? daysUntil(task.dueDate) : undefined;
  const overdue = !task.done && d !== undefined && d < 0;
  const soon = !task.done && d !== undefined && d >= 0 && d <= 3;
  const cid = `task-${task.id}`;

  const toggle = () => {
    dispatch({ type: 'toggleTask', id: task.id });
    notify(task.done ? `Reopened “${task.title}”` : `Completed “${task.title}”`, { label: 'Undo', onClick: () => dispatch({ type: 'toggleTask', id: task.id }) });
  };

  return (
    <li className="group flex items-start gap-3 px-5 py-3.5">
      <span className="relative mt-0.5 flex">
        <input id={cid} type="checkbox" checked={task.done} onChange={toggle} className="peer h-6 w-6 cursor-pointer appearance-none rounded-full border-2 border-slate-300 bg-white transition-colors checked:border-positive checked:bg-positive hover:border-slate-400" />
        <Check aria-hidden strokeWidth={3} className="pointer-events-none absolute left-1.5 top-1.5 hidden h-3 w-3 text-white peer-checked:block" />
      </span>
      <div className="min-w-0 flex-1">
        <label htmlFor={cid} className={cx('block cursor-pointer text-[0.9375rem] font-medium leading-snug', task.done && 'text-muted line-through decoration-slate-400')}>
          {task.title}
        </label>
        <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted">
          {task.priority === 'high' && !task.done && (
            <span className="inline-flex items-center gap-1 font-medium text-ink">
              <Flag aria-hidden className="h-3.5 w-3.5 text-brand" /> High priority
            </span>
          )}
          {task.dueDate && (
            <span className={cx('tnum', overdue && 'font-semibold text-danger-ink', soon && 'font-medium text-ink')}>
              {formatDate(task.dueDate)} · {task.done ? 'Done' : relativeDue(task.dueDate)}
            </span>
          )}
          {program && (
            <Link to={`/app/discover/${program.id}`} className="truncate underline decoration-slate-300 underline-offset-2 hover:text-ink hover:decoration-ink">
              {program.name}
            </Link>
          )}
        </p>
      </div>
      {showActions && (
        <div className="-mr-2 flex shrink-0">
          <IconButton label={`Edit “${task.title}”`} onClick={() => compose({ id: task.id, title: task.title, programId: task.programId, dueDate: task.dueDate, priority: task.priority })}>
            <Pencil aria-hidden className="h-4 w-4" />
          </IconButton>
          <IconButton
            label={`Delete “${task.title}”`}
            onClick={() => {
              dispatch({ type: 'deleteTask', id: task.id });
              notify('Task deleted.', { label: 'Undo', onClick: () => dispatch({ type: 'addTask', task: { ...task } }) });
            }}
          >
            <Trash2 aria-hidden className="h-4 w-4" />
          </IconButton>
        </div>
      )}
    </li>
  );
}
