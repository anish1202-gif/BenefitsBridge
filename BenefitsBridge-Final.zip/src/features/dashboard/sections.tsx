import { ArrowRight, CalendarClock, CircleHelp, FileCheck2, Flag, Plus, UserRoundPen } from 'lucide-react';
import { useMemo } from 'react';
import type { MatchResult, Task } from '../../types';
import { useMatches, useStore } from '../../lib/store';
import { EQUIPMENT_STEPS } from '../../lib/equipment';
import { getProgram } from '../../lib/programs';
import { daysUntil, formatDate, relativeDue } from '../../lib/dates';
import { Link, navigate } from '../../lib/router';
import { Button, LinkButton } from '../../components/Button';
import { AppStatusBadge } from '../../components/Badges';
import { EmptyState, Panel, ProgressBar, StatusPath } from '../../components/Primitives';
import { useToast } from '../../components/Toast';
import { useTaskComposer } from '../tasks/TaskComposer';
import { cx } from '../../components/cx';

// ───────────────────────── Metric ledger ─────────────────────────

export function MetricLedger() {
  const { state } = useStore();
  const { match } = useMatches();
  const results = match.status === 'ready' ? match.data.results : [];
  const potential = results.filter((r) => r.status === 'potential_match').length;
  const moreInfo = results.filter((r) => r.status === 'more_info_needed').length;
  const inProgress = state.applications.filter((a) => a.status !== 'awaiting_decision').length;
  const openTasks = state.tasks.filter((t) => !t.done);
  const thisWeek = openTasks.filter((t) => t.dueDate && daysUntil(t.dueDate) <= 7).length;
  const loading = match.status === 'loading';

  const cells = [
    { label: 'Programs being explored', value: loading ? '—' : potential + moreInfo, sub: loading ? 'Updating…' : `${potential} potential ${potential === 1 ? 'match' : 'matches'}`, to: '/app/discover' },
    { label: 'Applications in progress', value: inProgress, sub: `${state.applications.length} tracked in total`, to: '/app/applications' },
    { label: 'Upcoming tasks', value: openTasks.length, sub: thisWeek ? `${thisWeek} due within 7 days` : 'Nothing due this week', to: '/app/tasks' },
    { label: 'Saved benefits', value: state.saved.length, sub: 'In My Benefits', to: '/app/benefits' },
  ];

  return (
    <section aria-label="Summary" className="detail mb-8 grid grid-cols-2 overflow-hidden rounded-lg border border-line bg-white shadow-card lg:grid-cols-4">
      {cells.map((c, i) => (
        <Link
          key={c.label}
          to={c.to}
          className={cx(
            'group relative block px-5 py-5 transition-colors hover:bg-slate-50 focus-visible:z-10',
            i % 2 === 1 && 'border-l border-line',
            i >= 2 && 'border-t border-line lg:border-t-0',
            i === 2 && 'lg:border-l',
          )}
        >
          <span className="block text-sm text-muted">{c.label}</span>
          <span className="mt-2 block text-[2rem] font-semibold leading-none tnum">{c.value}</span>
          <span className="mt-2 flex items-center gap-1 text-sm text-slate-700">
            {c.sub}
            <ArrowRight aria-hidden className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
          </span>
        </Link>
      ))}
    </section>
  );
}

// ───────────────────────── Next moves ─────────────────────────

interface Move {
  key: string;
  title: string;
  context: string;
  priority?: boolean;
  primary: { label: string; onClick: () => void };
  secondary?: { label: string; href: string };
}

export function NextMoves() {
  const { state, dispatch } = useStore();
  const { match } = useMatches();
  const notify = useToast();
  const compose = useTaskComposer();

  const moves: Move[] = useMemo(() => {
    const open = state.tasks
      .filter((t) => !t.done)
      .sort((a, b) => (a.priority === 'high' ? 0 : 1) - (b.priority === 'high' ? 0 : 1) || (a.dueDate ?? '9999').localeCompare(b.dueDate ?? '9999'));

    const taskMoves: Move[] = open.slice(0, 3).map((t: Task) => {
      const program = t.programId ? getProgram(t.programId) : undefined;
      return {
        key: t.id,
        title: t.title,
        context: [t.dueDate ? relativeDue(t.dueDate) : 'No due date', program?.name].filter(Boolean).join(' · '),
        priority: t.priority === 'high',
        primary: {
          label: 'Mark done',
          onClick: () => {
            dispatch({ type: 'toggleTask', id: t.id });
            notify(`Completed “${t.title}”`, { label: 'Undo', onClick: () => dispatch({ type: 'toggleTask', id: t.id }) });
          },
        },
        secondary: program ? { label: 'Open program', href: `#/app/discover/${program.id}` } : undefined,
      };
    });

    const suggestions: Move[] = [];
    const results = match.status === 'ready' ? match.data.results : [];
    const unsaved = results.find((r) => r.status === 'potential_match' && !state.saved.includes(r.programId) && !state.tasks.some((t) => t.programId === r.programId));
    if (unsaved) {
      const p = getProgram(unsaved.programId)!;
      suggestions.push({
        key: `s-${p.id}`,
        title: `Review ${p.name}`,
        context: 'Potential match you haven’t saved yet',
        primary: { label: 'Review', onClick: () => navigate(`/app/discover/${p.id}`) },
      });
    }
    const pf = state.profile;
    const openEquipment = EQUIPMENT_STEPS.filter((s) => !state.equipment.completedStepIds.includes(s.id));
    if (pf?.supportNeeds.includes('mobility') && openEquipment.length > 0) {
      suggestions.push({
        key: 's-equipment',
        title: 'Continue the mobility-device checklist',
        context: `${openEquipment.length} administrative ${openEquipment.length === 1 ? 'step' : 'steps'} still to record`,
        primary: { label: 'Open checklist', onClick: () => navigate('/app/equipment') },
      });
    }
    if (pf && (!pf.state || !pf.monthlyIncome || !pf.insurance || pf.assistanceSought.length === 0)) {
      suggestions.push({
        key: 's-profile',
        title: 'Fill in the rest of your profile',
        context: 'More answers means fewer “More Information Needed” results',
        primary: { label: 'Edit profile', onClick: () => navigate('/app/settings') },
      });
    }
    return [...taskMoves, ...suggestions].slice(0, 5);
  }, [state, match, dispatch, notify]);

  return (
    <Panel
      id="next-moves"
      title="Your next moves"
      description="Prioritized from your tasks and results."
      action={
        <Button size="sm" onClick={() => compose()} icon={<Plus aria-hidden className="h-4 w-4" />}>
          Add task
        </Button>
      }
      bodyClassName=""
    >
      {moves.length === 0 ? (
        <div className="p-5">
          <EmptyState icon={<FileCheck2 className="h-5 w-5" />} title="You’re all caught up" action={<Button onClick={() => compose()}>Add a task</Button>}>
            Add a task when something new comes up.
          </EmptyState>
        </div>
      ) : (
        <ol className="divide-y divide-line">
          {moves.map((m, i) => (
            <li key={m.key} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center">
              <span aria-hidden className="hidden h-7 w-7 shrink-0 items-center justify-center rounded-full bg-slate-100 text-sm font-semibold text-slate-700 tnum sm:flex">
                {i + 1}
              </span>
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-2 text-[0.9375rem] font-medium">
                  {m.title}
                  {m.priority && (
                    <span className="inline-flex items-center gap-1 text-xs font-medium text-brand">
                      <Flag aria-hidden className="h-3 w-3" />
                      High
                    </span>
                  )}
                </p>
                <p className="mt-0.5 text-sm text-muted">{m.context}</p>
              </div>
              <div className="flex shrink-0 gap-2">
                {m.secondary && (
                  <LinkButton size="sm" variant="ghost" href={m.secondary.href} className="detail">
                    {m.secondary.label}
                  </LinkButton>
                )}
                <Button size="sm" variant={i === 0 ? 'primary' : 'secondary'} onClick={m.primary.onClick}>
                  {m.primary.label}
                  <span className="sr-only">: {m.title}</span>
                </Button>
              </div>
            </li>
          ))}
        </ol>
      )}
    </Panel>
  );
}

// ───────────────────────── Deadlines ─────────────────────────

export function DeadlineTimeline({ limit = 5 }: { limit?: number }) {
  const { state } = useStore();
  const compose = useTaskComposer();

  const items = [
    ...state.tasks.filter((t) => !t.done && t.dueDate).map((t) => ({ id: t.id, date: t.dueDate!, title: t.title, programId: t.programId, kind: 'Task' })),
    ...state.applications.filter((a) => a.keyDate).map((a) => ({ id: a.id, date: a.keyDate!, title: a.keyDateLabel || 'Key date', programId: a.programId, kind: 'Application' })),
  ]
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, limit);

  return (
    <Panel
      id="deadlines"
      title="Upcoming deadlines"
      description="Dates you’ve entered — not official deadlines."
      action={
        <LinkButton size="sm" variant="ghost" href="#/app/tasks">
          All
          <span className="sr-only"> tasks and deadlines</span>
        </LinkButton>
      }
    >
      {items.length === 0 ? (
        <EmptyState icon={<CalendarClock className="h-5 w-5" />} title="No dates yet" action={<Button size="sm" onClick={() => compose()}>Add a dated task</Button>}>
          Add a due date to any task to see it here.
        </EmptyState>
      ) : (
        <ol className="relative">
          {items.map((it, i) => {
            const n = daysUntil(it.date);
            const program = it.programId ? getProgram(it.programId) : undefined;
            return (
              <li key={it.id} className="relative flex gap-4 pb-5 last:pb-0">
                {i < items.length - 1 && <span aria-hidden className="absolute left-[27px] top-12 bottom-0 w-px bg-line" />}
                <div className={cx('flex h-12 w-14 shrink-0 flex-col items-center justify-center rounded-md border tnum', n < 0 ? 'border-danger-ink/30 bg-danger-soft text-danger-ink' : n <= 3 ? 'border-brand/30 bg-brand-soft text-brand' : 'border-line bg-white')}>
                  <span className="text-[0.6875rem] font-semibold uppercase leading-none tracking-wide">{formatDate(it.date, { month: 'short' })}</span>
                  <span className="mt-0.5 text-lg font-semibold leading-none">{formatDate(it.date, { day: 'numeric' })}</span>
                </div>
                <div className="min-w-0 pt-0.5">
                  <p className="text-[0.9375rem] font-medium leading-snug">{it.title}</p>
                  <p className={cx('mt-0.5 text-sm', n < 0 ? 'font-medium text-danger-ink' : 'text-muted')}>
                    {relativeDue(it.date)}
                    {program ? ` · ${program.name}` : ''}
                  </p>
                </div>
              </li>
            );
          })}
        </ol>
      )}
    </Panel>
  );
}

// ───────────────────────── Applications summary ─────────────────────────

export function ApplicationsSummary() {
  const { state } = useStore();
  return (
    <Panel
      id="apps-summary"
      title="Applications"
      description="Stages are what you’ve reported, not official updates."
      action={
        <LinkButton size="sm" variant="ghost" href="#/app/applications">
          Manage
          <span className="sr-only"> applications</span>
        </LinkButton>
      }
      bodyClassName=""
    >
      {state.applications.length === 0 ? (
        <div className="p-5">
          <EmptyState
            icon={<FileCheck2 className="h-5 w-5" />}
            title="No applications tracked"
            action={
              <LinkButton href="#/app/discover" variant="primary" size="sm">
                Find a program
              </LinkButton>
            }
          >
            Open any program and choose “Track application” to build a checklist.
          </EmptyState>
        </div>
      ) : (
        <ul className="divide-y divide-line">
          {state.applications.map((a) => {
            const p = getProgram(a.programId);
            const done = a.documents.filter((d) => d.done).length;
            return (
              <li key={a.id} className="px-5 py-5">
                <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-[0.9375rem] font-semibold">
                    <Link to={`/app/applications?focus=${a.id}`} className="hover:underline underline-offset-4">
                      {p?.name}
                    </Link>
                  </h3>
                  <AppStatusBadge status={a.status} />
                </div>
                <StatusPath status={a.status} compact />
                <div className="mt-4 flex items-center gap-3">
                  <div className="flex-1">
                    <ProgressBar value={done} max={a.documents.length} label={`${p?.name} documents`} tone="positive" />
                  </div>
                  <span className="text-sm text-muted tnum whitespace-nowrap">
                    {done}/{a.documents.length} documents
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}

// ───────────────────────── Missing information ─────────────────────────

export function MissingInfo() {
  const { match } = useMatches();
  const results: MatchResult[] = match.status === 'ready' ? match.data.results : [];
  const counts = new Map<string, string[]>();
  results
    .filter((r) => r.status !== 'not_matched')
    .forEach((r) => r.missingInfo.forEach((m) => counts.set(m, [...(counts.get(m) ?? []), r.programId])));
  const rows = [...counts.entries()].sort((a, b) => b[1].length - a[1].length).slice(0, 5);

  return (
    <Panel id="missing" title="Information still missing" description="Answering these would sharpen your results." bodyClassName="">
      {match.status === 'loading' ? (
        <div className="space-y-3 p-5" aria-hidden>
          <div className="skeleton h-4 w-3/4" />
          <div className="skeleton h-4 w-2/3" />
          <div className="skeleton h-4 w-1/2" />
        </div>
      ) : rows.length === 0 ? (
        <p className="p-5 text-sm text-muted">Nothing outstanding right now.</p>
      ) : (
        <>
          <ul className="divide-y divide-line">
            {rows.map(([label, ids]) => (
              <li key={label} className="flex items-start gap-3 px-5 py-3">
                <CircleHelp aria-hidden className="mt-0.5 h-4 w-4 shrink-0 text-caution-ink" />
                <div className="min-w-0 flex-1 text-sm">
                  <p className="font-medium text-ink">{label}</p>
                  <p className="mt-0.5 text-muted">
                    Affects {ids.length} {ids.length === 1 ? 'program' : 'programs'}: {ids.map((id) => getProgram(id)?.name).join(', ')}
                  </p>
                </div>
              </li>
            ))}
          </ul>
          <div className="border-t border-line px-5 py-3">
            <LinkButton href="#/app/settings" size="sm" variant="ghost" icon={<UserRoundPen aria-hidden className="h-4 w-4" />}>
              Update profile
            </LinkButton>
          </div>
        </>
      )}
    </Panel>
  );
}
