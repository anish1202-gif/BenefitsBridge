import { Check } from 'lucide-react';
import { useMatches, useStore } from '../lib/store';
import { EQUIPMENT_PATHWAY_IDS, EQUIPMENT_STEPS } from '../lib/equipment';
import { getProgram } from '../lib/programs';
import { addDays } from '../lib/dates';
import { navigate } from '../lib/router';
import { Button, LinkButton } from '../components/Button';
import { MatchBadge } from '../components/Badges';
import { ChoiceGroup, TextField } from '../components/Field';
import { Notice, PageHeader, Panel, ProgressBar } from '../components/Primitives';
import { useToast } from '../components/Toast';
import { cx } from '../components/cx';
import type { FundingRecord, SupplierRecord } from '../types';

const FUNDING: { value: FundingRecord; label: string; description: string }[] = [
  { value: 'not_recorded', label: 'Not recorded', description: 'You have not written down a funding check yet.' },
  { value: 'still_verifying', label: 'Still verifying', description: 'You are checking with the program or payer.' },
  { value: 'confirmed_with_source', label: 'Confirmed with the source', description: 'You personally confirmed details with the official source.' },
];

const SUPPLIER: { value: SupplierRecord; label: string; description: string }[] = [
  { value: 'not_recorded', label: 'Not recorded', description: 'No supplier note yet.' },
  { value: 'not_yet', label: 'Not identified yet', description: 'You have not contacted a supplier or reuse program.' },
  { value: 'recorded', label: 'Name recorded', description: 'You have a name from a contact you already made.' },
];

const PATHWAY_NOTE: Record<(typeof EQUIPMENT_PATHWAY_IDS)[number], string> = {
  'ga-medicaid-abd':
    'Georgia Medicaid can include durable medical equipment for members. Whether a specific device is covered, and which documents are required, has to be confirmed with the program.',
  'tools-for-life':
    'Tools for Life offers device demonstrations, short-term loans, and reuse guidance in Georgia. That is not an insurance approval and not an order.',
  'gvra-vr':
    'Vocational rehabilitation may discuss assistive technology tied to a work goal. Whether a mobility device fits that goal has to be confirmed with GVRA.',
};

export function EquipmentPage() {
  const { state, dispatch } = useStore();
  const { byProgram } = useMatches();
  const notify = useToast();
  const equipment = state.equipment;
  const done = EQUIPMENT_STEPS.filter((s) => equipment.completedStepIds.includes(s.id)).length;
  const mobility = state.profile?.supportNeeds.includes('mobility');

  const addTasks = () => {
    const open = EQUIPMENT_STEPS.filter((s) => !equipment.completedStepIds.includes(s.id));
    const fresh = open.filter((s) => !state.tasks.some((t) => t.title === s.title && !t.done));
    fresh.forEach((s, i) =>
      dispatch({
        type: 'addTask',
        task: { title: s.title, programId: 'tools-for-life', dueDate: addDays(7 * (i + 1)), priority: i === 0 ? 'high' : 'normal', source: 'suggested' },
      }),
    );
    notify(fresh.length ? `Added ${fresh.length} equipment ${fresh.length === 1 ? 'task' : 'tasks'}. Due dates are samples you can change.` : 'Those steps are already on your task list.', {
      label: 'View tasks',
      onClick: () => navigate('/app/tasks'),
    });
  };

  return (
    <>
      <PageHeader
        eyebrow="Medical equipment"
        title="Mobility device access"
        description="Track the administrative steps between a mobility need and a device — coverage to verify, documents to ask about, and whether you have confirmed funding or a supplier."
        actions={
          <Button onClick={addTasks} variant="primary">
            Add open steps as tasks
          </Button>
        }
      />

      <Notice tone="caution">
        <p className="font-medium">BenefitsBridge does not supply equipment.</p>
        <p className="mt-1">
          This page does not check inventory, approve insurance, contact suppliers, or place orders. Statuses below are what you record after you verify them. Only the program or payer can confirm coverage.
        </p>
      </Notice>

      {!mobility && (
        <div className="mt-4">
          <Notice>
            Your profile does not list a mobility need. The example below is a wheelchair or similar device. The same steps apply if you are exploring other assistive equipment.
          </Notice>
        </div>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-12">
        <Panel
          id="equip-steps"
          title="Steps to verify"
          description="Check a step when you have done it. Unchecked means it still needs your attention."
          className="lg:col-span-7"
          bodyClassName="px-5 py-4"
        >
          <div className="mb-4">
            <ProgressBar value={done} max={EQUIPMENT_STEPS.length} label="Equipment steps recorded" />
            <p className="mt-2 text-sm text-muted" aria-live="polite">
              {done} of {EQUIPMENT_STEPS.length} steps recorded
            </p>
          </div>
          <ul className="divide-y divide-line">
            {EQUIPMENT_STEPS.map((step) => {
              const checked = equipment.completedStepIds.includes(step.id);
              const cid = `equip-${step.id}`;
              return (
                <li key={step.id} className="flex items-start gap-3 py-3">
                  <span className="relative mt-0.5 flex">
                    <input
                      id={cid}
                      type="checkbox"
                      checked={checked}
                      onChange={() => dispatch({ type: 'toggleEquipmentStep', id: step.id })}
                      className="peer h-5 w-5 cursor-pointer appearance-none rounded border-2 border-slate-300 bg-white checked:border-positive checked:bg-positive focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-offset-2 focus-visible:outline-brand"
                    />
                    <Check aria-hidden strokeWidth={3} className="pointer-events-none absolute left-1 top-1 hidden h-3 w-3 text-white peer-checked:block" />
                  </span>
                  <label htmlFor={cid} className="min-w-0 cursor-pointer">
                    <span className={cx('block text-[0.9375rem] font-medium', checked && 'text-muted line-through decoration-slate-400')}>{step.title}</span>
                    <span className="mt-0.5 block text-sm text-slate-700">{step.detail}</span>
                  </label>
                </li>
              );
            })}
          </ul>
        </Panel>

        <Panel
          id="equip-pathways"
          title="Pathways to compare"
          description="Potential routes from your profile. Open each one and confirm the rules at the official source."
          className="lg:col-span-5"
          bodyClassName="p-0"
        >
          <ul className="divide-y divide-line">
            {EQUIPMENT_PATHWAY_IDS.map((id) => {
              const program = getProgram(id);
              const match = byProgram.get(id);
              if (!program) return null;
              return (
                <li key={id} className="px-5 py-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-[0.9375rem] font-semibold">
                      <a className="rounded-sm underline-offset-2 hover:underline" href={`#/app/discover/${id}`}>
                        {program.name}
                      </a>
                    </h3>
                    {match && <MatchBadge status={match.status} />}
                  </div>
                  <p className="mt-1.5 text-sm text-slate-700">{PATHWAY_NOTE[id]}</p>
                  {program.officialUrl && (
                    <p className="mt-2">
                      <LinkButton href={program.officialUrl} external size="sm" variant="ghost">
                        {program.officialLabel ?? 'Official source'}
                      </LinkButton>
                    </p>
                  )}
                </li>
              );
            })}
          </ul>
        </Panel>
      </div>

      <Panel id="equip-record" title="What you have confirmed" description="These fields store your notes. They do not update from an insurer or supplier." className="mt-6">
        <div className="grid gap-8 lg:grid-cols-2">
          <ChoiceGroup
            legend="Funding information"
            hint="Record only what you have confirmed yourself."
            name="funding-status"
            value={equipment.fundingStatus}
            onChange={(fundingStatus) => {
              dispatch({ type: 'setEquipment', patch: { fundingStatus } });
              if (fundingStatus === 'confirmed_with_source' && !equipment.completedStepIds.includes('funding')) {
                dispatch({ type: 'toggleEquipmentStep', id: 'funding' });
              }
            }}
            options={FUNDING}
          />
          <div>
            <ChoiceGroup
              legend="Supplier or reuse program"
              hint="A name is a note, not a verified vendor."
              name="supplier-status"
              value={equipment.supplierStatus}
              onChange={(supplierStatus) => {
                dispatch({ type: 'setEquipment', patch: { supplierStatus } });
                if (supplierStatus === 'recorded' && !equipment.completedStepIds.includes('supplier')) {
                  dispatch({ type: 'toggleEquipmentStep', id: 'supplier' });
                }
              }}
              options={SUPPLIER}
            />
            {equipment.supplierStatus === 'recorded' && (
              <TextField
                className="mt-4"
                label="Name you contacted"
                hint="Optional. Stored only in this browser tab."
                optional
                value={equipment.supplierNote}
                onChange={(e) => dispatch({ type: 'setEquipment', patch: { supplierNote: e.target.value } })}
                autoComplete="off"
              />
            )}
          </div>
        </div>
      </Panel>
    </>
  );
}
