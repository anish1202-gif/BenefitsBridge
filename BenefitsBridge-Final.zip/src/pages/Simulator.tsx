import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, BriefcaseBusiness, CalendarClock, Check, ClipboardCopy, CircleHelp, MapPin, Plus, RefreshCw, TrendingUp, UserX, ShieldAlert } from 'lucide-react';
import type { IncomeRange, LifeEvent, LifeEventType, SimulationResult } from '../types';
import { simulateLifeEvent } from '../lib/integration';
import { useStore } from '../lib/store';
import { getProgram } from '../lib/programs';
import { INCOME_LABEL, US_STATES } from '../lib/labels';
import { addDays } from '../lib/dates';
import { Link, navigate } from '../lib/router';
import { Button } from '../components/Button';
import { ImpactBadge, Tag } from '../components/Badges';
import { ChoiceGroup, SelectField, TextField } from '../components/Field';
import { Notice, Panel } from '../components/Primitives';
import { useToast } from '../components/Toast';
import { cx } from '../components/cx';

const SCENARIOS: { type: LifeEventType; label: string; icon: typeof BriefcaseBusiness }[] = [
  { type: 'start_job', label: 'Start a job', icon: BriefcaseBusiness },
  { type: 'lose_job', label: 'Lose a job', icon: UserX },
  { type: 'income_increase', label: 'Income increases', icon: TrendingUp },
  { type: 'move_state', label: 'Move to another state', icon: MapPin },
  { type: 'coverage_renewal', label: 'Coverage renewal', icon: CalendarClock },
];

const AFTER_LABEL: Record<LifeEventType, string> = {
  start_job: 'If you start this job',
  lose_job: 'If you lose your job',
  income_increase: 'If your income increases',
  move_state: 'If you move',
  coverage_renewal: 'At renewal time',
};

export function SimulatorPage() {
  const { state, dispatch } = useStore();
  const notify = useToast();
  const profile = state.profile!;

  const [type, setType] = useState<LifeEventType>('start_job');
  const [hours, setHours] = useState<'under_20' | '20_to_34' | '35_plus'>('under_20');
  const [jobIncome, setJobIncome] = useState<IncomeRange>('under_1000');
  const [coverage, setCoverage] = useState<'yes' | 'no' | 'unknown'>('unknown');
  const [newIncome, setNewIncome] = useState<IncomeRange>('1000_2000');
  const [toState, setToState] = useState(profile.state === 'FL' ? 'AL' : 'FL');
  const [renewal, setRenewal] = useState('');

  const event: LifeEvent = useMemo(() => {
    switch (type) {
      case 'start_job':
        return { type, hoursPerWeek: hours, monthlyIncome: jobIncome, employerCoverage: coverage };
      case 'lose_job':
        return { type };
      case 'income_increase':
        return { type, monthlyIncome: newIncome };
      case 'move_state':
        return { type, toState };
      case 'coverage_renewal':
        return { type, renewalDate: renewal || undefined };
    }
  }, [type, hours, jobIncome, coverage, newIncome, toState, renewal]);

  const [result, setResult] = useState<SimulationResult>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>();
  const [attempt, setAttempt] = useState(0);
  const [added, setAdded] = useState<Set<string>>(new Set());

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(undefined);
    simulateLifeEvent(profile, event)
      .then((r) => !cancelled && setResult(r))
      .catch((e: unknown) => !cancelled && setError(e instanceof Error ? e.message : 'The simulator did not respond.'))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [profile, event, attempt]);

  useEffect(() => setAdded(new Set()), [type]);
  useEffect(() => {
    document.title = 'Life Simulator · BenefitsBridge';
    document.getElementById('sim-title')?.focus({ preventScroll: true });
  }, []);

  const tracked = new Set([...state.saved, ...state.applications.map((a) => a.programId)]);
  const affected = (result?.affectedPrograms ?? []).slice().sort((a, b) => Number(tracked.has(b.programId)) - Number(tracked.has(a.programId)));

  const addAction = (a: SimulationResult['suggestedActions'][number]) => {
    dispatch({ type: 'addTask', task: { title: a.title, programId: a.programId, dueDate: addDays(14), priority: 'normal', source: 'simulator' } });
    setAdded((s) => new Set(s).add(a.id));
    notify(`Task added: “${a.title}” (sample due date in 2 weeks).`, { label: 'View tasks', onClick: () => navigate('/app/tasks') });
  };

  const addAll = () => {
    const pending = (result?.suggestedActions ?? []).filter((a) => !added.has(a.id));
    pending.forEach((a) => dispatch({ type: 'addTask', task: { title: a.title, programId: a.programId, dueDate: addDays(14), priority: 'normal', source: 'simulator' } }));
    setAdded(new Set((result?.suggestedActions ?? []).map((a) => a.id)));
    notify(`Added ${pending.length} tasks to your list.`, { label: 'Back to overview', onClick: () => navigate('/app/overview') });
  };

  const copyQuestions = async () => {
    const text = (result?.questionsToVerify ?? []).map((q, i) => `${i + 1}. ${q}`).join('\n');
    try {
      await navigator.clipboard.writeText(text);
      notify('Questions copied to your clipboard.');
    } catch {
      notify('Couldn’t access the clipboard. Select the questions and copy them manually.');
    }
  };

  const scenarioLabel = SCENARIOS.find((s) => s.type === type)!.label;

  return (
    <>
      {/* Hero band */}
      <section aria-labelledby="sim-title" className="on-dark -mx-4 -mt-6 mb-8 bg-night px-4 pb-6 pt-8 text-white sm:-mx-6 sm:px-6 md:-mt-8 lg:-mx-10 lg:-mt-10 lg:px-10 lg:pb-8 lg:pt-12">
        <div className="max-w-3xl">
          <p className="text-sm font-medium text-brand-ring">Life Simulator</p>
          <h1 id="sim-title" tabIndex={-1} className="mt-2 text-[1.875rem] font-semibold leading-tight text-white md:text-[2.5rem] text-balance">
            See how life changes could affect your support.
          </h1>
          <p className="mt-3 max-w-2xl text-base text-slate-300">
            Pick a change to explore which of your programs might need a closer look, what’s still unknown, and what to ask. It’s a planning aid — not a forecast or eligibility decision.
          </p>
        </div>

        <fieldset className="mt-8">
          <legend className="sr-only">Choose a life change</legend>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
            {SCENARIOS.map((s) => {
              const on = s.type === type;
              return (
                <label
                  key={s.type}
                  className={cx(
                    'flex min-h-[3.5rem] cursor-pointer items-center gap-3 rounded-md border px-3.5 py-3 text-[0.9375rem] font-medium transition-colors has-[:focus-visible]:outline has-[:focus-visible]:outline-[3px] has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-brand-ring',
                    on ? 'border-brand-ring bg-white text-ink' : 'border-white/15 text-slate-200 hover:border-white/30 hover:bg-white/5',
                  )}
                >
                  <input type="radio" name="scenario" value={s.type} checked={on} onChange={() => setType(s.type)} className="sr-only" />
                  <s.icon aria-hidden className={cx('h-5 w-5 shrink-0', on ? 'text-brand' : 'text-slate-400')} />
                  {s.label}
                </label>
              );
            })}
          </div>
        </fieldset>
      </section>

      <div className="grid gap-8 lg:grid-cols-[320px_1fr]">
        {/* Inputs */}
        <aside aria-label="Scenario details" className="lg:sticky lg:top-8 lg:self-start">
          <Panel title="Scenario details" description={scenarioLabel}>
            <div className="space-y-5">
              {type === 'start_job' && (
                <>
                  <SelectField label="Hours per week" value={hours} onChange={(e) => setHours(e.target.value as typeof hours)}>
                    <option value="under_20">Under 20 hours</option>
                    <option value="20_to_34">20–34 hours</option>
                    <option value="35_plus">35 hours or more</option>
                  </SelectField>
                  <SelectField label="Expected monthly pay" value={jobIncome} onChange={(e) => setJobIncome(e.target.value as IncomeRange)}>
                    {(Object.keys(INCOME_LABEL) as IncomeRange[])
                      .filter((k) => k !== 'none')
                      .map((k) => (
                        <option key={k} value={k}>
                          {INCOME_LABEL[k]}
                        </option>
                      ))}
                  </SelectField>
                  <ChoiceGroup
                    legend="Does the job offer health insurance?"
                    name="coverage"
                    value={coverage}
                    onChange={setCoverage}
                    options={[
                      { value: 'yes', label: 'Yes' },
                      { value: 'no', label: 'No' },
                      { value: 'unknown', label: 'Not sure yet' },
                    ]}
                  />
                </>
              )}
              {type === 'lose_job' && <p className="text-sm text-slate-700">No extra details needed. We’ll compare your current profile with having no earned income.</p>}
              {type === 'income_increase' && (
                <SelectField label="New monthly earned income" value={newIncome} onChange={(e) => setNewIncome(e.target.value as IncomeRange)}>
                  {(Object.keys(INCOME_LABEL) as IncomeRange[]).map((k) => (
                    <option key={k} value={k}>
                      {INCOME_LABEL[k]}
                    </option>
                  ))}
                </SelectField>
              )}
              {type === 'move_state' && (
                <SelectField label="Moving to" value={toState} onChange={(e) => setToState(e.target.value)}>
                  {US_STATES.filter(([c]) => c !== profile.state).map(([c, n]) => (
                    <option key={c} value={c}>
                      {n}
                    </option>
                  ))}
                </SelectField>
              )}
              {type === 'coverage_renewal' && (
                <TextField label="Renewal date from your notice" optional type="date" value={renewal} onChange={(e) => setRenewal(e.target.value)} hint="Leave blank if you don’t have it yet." />
              )}
            </div>
          </Panel>
          <p className="mt-3 px-1 text-sm text-muted">
            Based on your{' '}
            <Link to="/app/settings" className="font-medium text-brand underline underline-offset-2">
              current profile
            </Link>
            . Nothing here changes it.
          </p>
        </aside>

        {/* Results */}
        <div className="min-w-0 space-y-6" aria-busy={loading}>
          <p role="status" aria-live="polite" className="sr-only">
            {loading ? 'Updating simulation…' : result ? `Simulation updated for: ${scenarioLabel}.` : ''}
          </p>

          <Notice tone="caution" icon={<ShieldAlert className="h-4 w-4" />}>
            <span className="font-semibold">Not an eligibility determination.</span> This doesn’t predict approvals, end dates or payment amounts. Use it to prepare questions for each program
            or a benefits counselor.
          </Notice>

          {error ? (
            <Notice tone="caution">
              <p className="font-medium">The simulator didn’t respond.</p>
              <p className="mt-0.5">{error}</p>
              <Button size="sm" className="mt-3" onClick={() => setAttempt((n) => n + 1)} icon={<RefreshCw aria-hidden className="h-4 w-4" />}>
                Try again
              </Button>
            </Notice>
          ) : !result ? (
            <div className="space-y-3" aria-hidden>
              <div className="skeleton h-48" />
              <div className="skeleton h-32" />
            </div>
          ) : (
            <div className={cx('space-y-6 transition-opacity', loading && 'opacity-60')}>
              {/* Before / after */}
              <section aria-labelledby="cmp-title" className="overflow-hidden rounded-lg border border-line bg-white shadow-card">
                <h2 id="cmp-title" className="border-b border-line px-5 py-4 text-[1.0625rem] font-semibold">
                  Your situation, before and after
                </h2>

                {/* Desktop/tablet: real table */}
                <table className="hidden w-full text-left md:table">
                  <caption className="sr-only">Comparison of your current situation with the simulated change: {scenarioLabel}</caption>
                  <thead>
                    <tr className="border-b border-line bg-canvas text-xs font-medium uppercase tracking-wide text-muted">
                      <th scope="col" className="w-[28%] px-5 py-2.5 font-medium">
                        Detail
                      </th>
                      <th scope="col" className="px-5 py-2.5 font-medium">
                        Today
                      </th>
                      <th scope="col" className="w-10 px-0 py-2.5">
                        <span className="sr-only">Changes to</span>
                      </th>
                      <th scope="col" className="px-5 py-2.5 font-medium text-brand">
                        {AFTER_LABEL[type]}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {result.before.map((b, i) => {
                      const a = result.after[i];
                      const changed = a.value !== b.value;
                      return (
                        <tr key={b.key} className={cx(changed && 'bg-brand-soft/40')}>
                          <th scope="row" className={cx('px-5 py-3.5 text-sm font-medium', changed && 'border-l-[3px] border-brand pl-[17px]')}>
                            {b.label}
                          </th>
                          <td className={cx('px-5 py-3.5 text-[0.9375rem]', changed ? 'text-muted' : 'text-ink')}>{b.value}</td>
                          <td className="px-0 py-3.5 text-center">
                            {changed && <ArrowRight aria-hidden className="mx-auto h-4 w-4 text-brand" />}
                          </td>
                          <td className={cx('px-5 py-3.5 text-[0.9375rem]', changed && 'font-semibold text-ink')}>
                            {a.value}
                            {changed ? <span className="ml-2 align-middle text-xs font-medium text-brand">Changed</span> : <span className="sr-only"> (no change)</span>}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Mobile: stacked cards */}
                <ul className="divide-y divide-line md:hidden">
                  {result.before.map((b, i) => {
                    const a = result.after[i];
                    const changed = a.value !== b.value;
                    return (
                      <li key={b.key} className={cx('px-5 py-4', changed && 'border-l-[3px] border-brand bg-brand-soft/40 pl-[17px]')}>
                        <p className="flex items-center justify-between text-sm font-medium">
                          {b.label}
                          {changed && <span className="text-xs font-medium text-brand">Changed</span>}
                        </p>
                        <dl className="mt-2 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-sm">
                          <dt className="text-muted">Today</dt>
                          <dd>{b.value}</dd>
                          <dt className="text-muted">After</dt>
                          <dd className={cx(changed && 'font-semibold')}>{a.value}</dd>
                        </dl>
                      </li>
                    );
                  })}
                </ul>
              </section>

              {/* Affected programs */}
              <Panel id="affected" title="Programs that may be affected" description="Your saved and tracked programs are listed first." bodyClassName="">
                {affected.length === 0 ? (
                  <p className="p-5 text-sm text-muted">No program links identified for this change.</p>
                ) : (
                  <ul className="divide-y divide-line">
                    {affected.map((a) => {
                      const p = getProgram(a.programId);
                      if (!p) return null;
                      return (
                        <li key={a.programId} className="flex flex-col gap-2 px-5 py-4 sm:flex-row sm:items-start sm:gap-5">
                          <div className="sm:w-44 sm:shrink-0">
                            <ImpactBadge impact={a.impact} />
                          </div>
                          <div className="min-w-0">
                            <p className="flex flex-wrap items-center gap-2 text-[0.9375rem] font-semibold">
                              <Link to={`/app/discover/${p.id}`} className="hover:underline underline-offset-4">
                                {p.name}
                              </Link>
                              {tracked.has(p.id) && <Tag>You’re tracking this</Tag>}
                            </p>
                            <p className="mt-1 text-sm text-slate-700">{a.explanation}</p>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </Panel>

              <div className="grid gap-6 xl:grid-cols-2">
                {/* Unknowns */}
                <Panel id="unknowns" title="Needs verification" description="What we can’t know from your profile." bodyClassName="">
                  <ul className="divide-y divide-line">
                    {result.unknowns.map((u) => (
                      <li key={u.label} className="flex gap-3 px-5 py-3.5">
                        <CircleHelp aria-hidden className="mt-0.5 h-4 w-4 shrink-0 text-caution-ink" />
                        <div className="text-sm">
                          <p className="font-medium text-ink">
                            <span className="sr-only">Needs verification: </span>
                            {u.label}
                          </p>
                          <p className="mt-0.5 text-slate-700">{u.why}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </Panel>

                {/* Questions */}
                <Panel
                  id="questions"
                  title="Questions to ask"
                  description="Bring these to the program or a benefits counselor."
                  action={
                    <Button size="sm" variant="ghost" onClick={copyQuestions} icon={<ClipboardCopy aria-hidden className="h-4 w-4" />}>
                      Copy
                    </Button>
                  }
                >
                  <ol className="space-y-3">
                    {result.questionsToVerify.map((q, i) => (
                      <li key={q} className="flex gap-3 text-sm text-slate-700">
                        <span aria-hidden className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-semibold text-ink tnum">
                          {i + 1}
                        </span>
                        <span className="pt-0.5">{q}</span>
                      </li>
                    ))}
                  </ol>
                </Panel>
              </div>

              {/* Actions */}
              <Panel
                id="actions"
                title="Suggested next actions"
                description="Add any of these to your task list."
                action={
                  <Button size="sm" variant="primary" onClick={addAll} disabled={result.suggestedActions.every((a) => added.has(a.id))}>
                    Add all
                  </Button>
                }
                bodyClassName=""
              >
                <ul className="divide-y divide-line">
                  {result.suggestedActions.map((a) => {
                    const done = added.has(a.id);
                    const p = a.programId ? getProgram(a.programId) : undefined;
                    return (
                      <li key={a.id} className="flex flex-col gap-3 px-5 py-3.5 sm:flex-row sm:items-center">
                        <div className="min-w-0 flex-1">
                          <p className="text-[0.9375rem] font-medium">{a.title}</p>
                          {p && <p className="mt-0.5 text-sm text-muted">{p.name}</p>}
                        </div>
                        <Button
                          size="sm"
                          onClick={() => addAction(a)}
                          disabled={done}
                          icon={done ? <Check aria-hidden className="h-4 w-4 text-positive" /> : <Plus aria-hidden className="h-4 w-4" />}
                        >
                          {done ? 'Added' : 'Add task'}
                          <span className="sr-only">: {a.title}</span>
                        </Button>
                      </li>
                    );
                  })}
                </ul>
              </Panel>

              <p className="text-xs text-muted">
                Engine: {result.engine.name}
                {result.engine.kind === 'demo' ? ' — replace with the team’s simulator module.' : ''}
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
