import { ArrowRight, Plus, RefreshCw } from 'lucide-react';
import { useMatches, useStore } from '../lib/store';
import { greeting } from '../lib/dates';
import { getProgram } from '../lib/programs';
import { Button, LinkButton } from '../components/Button';
import { Notice, PageHeader } from '../components/Primitives';
import { ApplicationsSummary, DeadlineTimeline, MetricLedger, MissingInfo, NextMoves } from '../features/dashboard/sections';
import { ProgramCard, ProgramCardSkeleton } from '../features/benefits/ProgramCard';
import { useTaskComposer } from '../features/tasks/TaskComposer';

export function OverviewPage() {
  const { state } = useStore();
  const { match, retry } = useMatches();
  const compose = useTaskComposer();
  const name = state.profile?.firstName?.trim();

  const recommended =
    match.status === 'ready'
      ? match.data.results
          .filter((r) => r.status === 'potential_match')
          .sort((a, b) => Number(state.saved.includes(a.programId)) - Number(state.saved.includes(b.programId)))
          .slice(0, 3)
      : [];

  return (
    <>
      <PageHeader
        title={`${greeting()}${name ? `, ${name}` : ''}.`}
        description="Here’s where things stand with your benefits."
        actions={
          <>
            <Button onClick={() => compose()} icon={<Plus aria-hidden className="h-4 w-4" />}>
              Add task
            </Button>
            <LinkButton href="#/app/simulator" variant="dark">
              Simulate a change
            </LinkButton>
          </>
        }
      />

      <MetricLedger />

      <div className="grid gap-6 lg:grid-cols-12">
        <div className="lg:col-span-8">
          <NextMoves />
        </div>
        <div className="lg:col-span-4">
          <DeadlineTimeline />
        </div>
      </div>

      <section aria-labelledby="rec-title" className="mt-10">
        <div className="mb-4 flex items-end justify-between gap-4">
          <div>
            <h2 id="rec-title" className="text-xl font-semibold">
              Recommended programs
            </h2>
            <p className="mt-0.5 text-sm text-muted">Potential matches based on your profile. Not eligibility decisions.</p>
          </div>
          <LinkButton href="#/app/discover" size="sm" variant="ghost">
            See all <ArrowRight aria-hidden className="h-4 w-4" />
          </LinkButton>
        </div>

        {match.status === 'error' ? (
          <Notice tone="caution">
            <p className="font-medium">We couldn’t load recommendations.</p>
            <p className="mt-0.5">{match.message}</p>
            <Button size="sm" className="mt-3" onClick={retry} icon={<RefreshCw aria-hidden className="h-4 w-4" />}>
              Try again
            </Button>
          </Notice>
        ) : match.status !== 'ready' ? (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3" aria-busy="true" aria-label="Loading recommendations">
            <ProgramCardSkeleton />
            <ProgramCardSkeleton />
            <ProgramCardSkeleton />
          </div>
        ) : recommended.length === 0 ? (
          <Notice>
            No potential matches yet. Adding your state and the kinds of help you need usually changes that.{' '}
            <a className="font-medium text-brand underline underline-offset-2" href="#/app/settings">
              Update profile
            </a>
          </Notice>
        ) : (
          <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {recommended.map((r) => (
              <li key={r.programId}>
                <ProgramCard program={getProgram(r.programId)!} match={r} />
              </li>
            ))}
          </ul>
        )}
      </section>

      <div className="mt-10 grid gap-6 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <ApplicationsSummary />
        </div>
        <div className="lg:col-span-5">
          <MissingInfo />
        </div>
      </div>
    </>
  );
}
