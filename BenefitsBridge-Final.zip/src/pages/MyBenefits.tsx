import { Bookmark, FolderKanban, Trash2 } from 'lucide-react';
import { useMatches, useStore } from '../lib/store';
import { getProgram } from '../lib/programs';
import { CATEGORY_LABEL } from '../lib/labels';
import { Link, navigate } from '../lib/router';
import { Button, LinkButton } from '../components/Button';
import { AppStatusBadge, MatchBadge } from '../components/Badges';
import { EmptyState, PageHeader, ProgressBar } from '../components/Primitives';
import { useToast } from '../components/Toast';
import { useSaveToggle } from '../features/benefits/ProgramCard';

export function MyBenefitsPage() {
  const { state, dispatch } = useStore();
  const { byProgram } = useMatches();
  const notify = useToast();
  const unsave = useSaveToggle();

  const rows = state.saved.map((id) => getProgram(id)!).filter(Boolean);

  return (
    <>
      <PageHeader
        title="My benefits"
        description="Programs you’ve saved. Track an application to get a document checklist and progress."
        actions={
          <LinkButton href="#/app/discover" variant="primary">
            Discover more
          </LinkButton>
        }
      />

      {rows.length === 0 ? (
        <EmptyState
          icon={<Bookmark className="h-5 w-5" />}
          title="Nothing saved yet"
          action={
            <LinkButton href="#/app/discover" variant="primary">
              Browse programs
            </LinkButton>
          }
        >
          Save programs from Discover to keep them here alongside your applications and tasks.
        </EmptyState>
      ) : (
        <div className="overflow-hidden rounded-lg border border-line bg-white shadow-card">
          {/* Column labels (desktop) */}
          <div aria-hidden className="hidden grid-cols-[minmax(0,2.2fr)_1.2fr_1.4fr_auto] gap-6 border-b border-line bg-canvas px-5 py-2.5 text-xs font-medium uppercase tracking-wide text-muted lg:grid">
            <span>Program</span>
            <span>Match</span>
            <span>Your progress</span>
            <span className="w-[248px] text-right">Actions</span>
          </div>
          <ul className="divide-y divide-line">
            {rows.map((p) => {
              const app = state.applications.find((a) => a.programId === p.id);
              const m = byProgram.get(p.id);
              const openTasks = state.tasks.filter((t) => t.programId === p.id && !t.done).length;
              const docsDone = app?.documents.filter((d) => d.done).length ?? 0;
              return (
                <li key={p.id} className="grid gap-4 px-5 py-5 lg:grid-cols-[minmax(0,2.2fr)_1.2fr_1.4fr_auto] lg:items-center lg:gap-6">
                  <div className="min-w-0">
                    <h2 className="text-[0.9375rem] font-semibold leading-snug">
                      <Link to={`/app/discover/${p.id}`} className="hover:underline underline-offset-4">
                        {p.name}
                      </Link>
                    </h2>
                    <p className="mt-0.5 text-sm text-muted">{CATEGORY_LABEL[p.category]}</p>
                  </div>
                  <div>
                    <span className="sr-only">Match status: </span>
                    {m ? <MatchBadge status={m.status} /> : <span className="text-sm text-muted">—</span>}
                  </div>
                  <div className="text-sm">
                    {app ? (
                      <div className="space-y-2">
                        <AppStatusBadge status={app.status} />
                        <div className="flex items-center gap-2">
                          <div className="w-28">
                            <ProgressBar value={docsDone} max={app.documents.length} label={`${p.name} documents`} tone="positive" />
                          </div>
                          <span className="text-muted tnum">
                            {docsDone}/{app.documents.length} docs
                          </span>
                        </div>
                      </div>
                    ) : (
                      <span className="text-muted">Not tracking an application</span>
                    )}
                    {openTasks > 0 && (
                      <p className="mt-1.5 text-muted tnum">
                        {openTasks} open {openTasks === 1 ? 'task' : 'tasks'}
                      </p>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2 lg:w-[248px] lg:justify-end">
                    {app ? (
                      <LinkButton size="sm" href={`#/app/applications?focus=${app.id}`} icon={<FolderKanban aria-hidden className="h-4 w-4" />}>
                        Application<span className="sr-only"> for {p.name}</span>
                      </LinkButton>
                    ) : (
                      <Button
                        size="sm"
                        variant="primary"
                        onClick={() => {
                          dispatch({ type: 'startApplication', programId: p.id });
                          notify(`Tracking ${p.name}.`, { label: 'Open', onClick: () => navigate('/app/applications') });
                        }}
                        icon={<FolderKanban aria-hidden className="h-4 w-4" />}
                      >
                        Track<span className="sr-only"> application for {p.name}</span>
                      </Button>
                    )}
                    {p.officialUrl && (
                      <LinkButton size="sm" variant="ghost" href={p.officialUrl} external>
                        Official site<span className="sr-only"> for {p.name}</span>
                      </LinkButton>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => unsave(p)} aria-label={`Remove ${p.name} from My Benefits`} title="Remove">
                      <Trash2 aria-hidden className="h-4 w-4" />
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </>
  );
}
