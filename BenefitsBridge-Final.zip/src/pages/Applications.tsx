import { FolderKanban, Info } from 'lucide-react';
import { useStore } from '../lib/store';
import { useQueryParam } from '../lib/router';
import { APP_STATUS_LABEL, APP_STATUS_ORDER } from '../lib/labels';
import { LinkButton } from '../components/Button';
import { EmptyState, Notice, PageHeader } from '../components/Primitives';
import { ApplicationCard } from '../features/applications/ApplicationCard';

export function ApplicationsPage() {
  const { state } = useStore();
  const focus = useQueryParam('focus');
  const counts = APP_STATUS_ORDER.map((s) => [s, state.applications.filter((a) => a.status === s).length] as const);

  return (
    <>
      <PageHeader
        title="Applications"
        description="Track documents, tasks and the stage you’re at for each program you’re applying to."
        actions={
          <LinkButton href="#/app/discover" variant="primary">
            Track another program
          </LinkButton>
        }
      />

      {state.applications.length > 0 && (
        <dl className="detail mb-6 grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-line bg-line sm:grid-cols-5">
          {counts.map(([s, n]) => (
            <div key={s} className="bg-white px-4 py-3">
              <dt className="text-xs font-medium text-muted">{APP_STATUS_LABEL[s]}</dt>
              <dd className="mt-1 text-xl font-semibold tnum">{n}</dd>
            </div>
          ))}
        </dl>
      )}

      {state.applications.length === 0 ? (
        <EmptyState
          icon={<FolderKanban className="h-5 w-5" />}
          title="No applications yet"
          action={
            <LinkButton href="#/app/discover" variant="primary">
              Find a program
            </LinkButton>
          }
        >
          Open a program and choose “Track application” to start a checklist.
        </EmptyState>
      ) : (
        <div className="space-y-6">
          {state.applications.map((a) => (
            <ApplicationCard key={a.id} app={a} focused={focus === a.id} />
          ))}
        </div>
      )}

      <div className="mt-8">
        <Notice icon={<Info className="h-4 w-4" />}>
          Stages are updated by you. BenefitsBridge isn’t connected to any government system and can’t see the official status of an application.
        </Notice>
      </div>
    </>
  );
}
