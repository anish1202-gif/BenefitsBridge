import { useEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import { useStore } from '../lib/store';
import { Link, navigate } from '../lib/router';
import { Button, LinkButton } from '../components/Button';
import { Logo } from '../components/Primitives';
import { useToast } from '../components/Toast';

const PILLARS = [
  {
    n: '01',
    title: 'Discover',
    body: 'Answer a few optional questions and see which healthcare, money, transportation, work and housing programs may fit — with the reasons, and what’s still missing.',
  },
  {
    n: '02',
    title: 'Manage',
    body: 'Save programs, track each application from gathering documents to awaiting a decision, and keep every task and date in one list.',
  },
  {
    n: '03',
    title: 'Protect',
    body: 'Before a new job, a raise, a move or a renewal, see which of your supports might need a closer look and what to ask.',
  },
];

export function LandingPage() {
  const { state, dispatch } = useStore();
  const notify = useToast();

  useEffect(() => {
    document.title = 'BenefitsBridge — Your benefits. Your healthcare. One clear path.';
  }, []);

  const demo = () => {
    dispatch({ type: 'loadDemo' });
    notify('Loaded the demo profile for Jordan. All data is fictional.');
    navigate('/app/overview');
  };

  return (
    <div className="min-h-screen bg-canvas">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-white focus:px-4 focus:py-2 focus:shadow-raised">
        Skip to main content
      </a>
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <Logo />
        <nav aria-label="Primary" className="flex items-center gap-2">
          {state.profile ? (
            <LinkButton href="#/app/overview" variant="primary" size="sm">
              Open dashboard
            </LinkButton>
          ) : (
            <>
              <LinkButton href="#/onboarding" variant="ghost" size="sm" className="hidden sm:inline-flex">
                Set up profile
              </LinkButton>
              <Button variant="dark" size="sm" onClick={demo}>
                Explore demo
              </Button>
            </>
          )}
        </nav>
      </header>

      <main id="main">
        <section className="mx-auto max-w-6xl px-4 pb-16 pt-14 sm:px-6 md:pt-24">
          <p className="text-sm font-medium text-muted">Disability benefits & healthcare access</p>
          <h1 className="mt-4 max-w-4xl text-[2.5rem] font-semibold leading-[1.05] tracking-[-0.03em] sm:text-[3.5rem] md:text-[4.5rem] text-balance">
            Your benefits. Your healthcare. <span className="text-brand">One clear path.</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-slate-700 text-pretty">
            BenefitsBridge is a command center for the programs that support your health and independence — what may be worth exploring, what you’re applying to, and what to do next.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" variant="primary" onClick={demo}>
              Explore the demo as Jordan <ArrowRight aria-hidden className="h-4 w-4" />
            </Button>
            <LinkButton size="lg" href="#/onboarding">
              Set up your own profile
            </LinkButton>
          </div>
          <p className="mt-4 text-sm text-muted">No account. No medical records. About three minutes.</p>
        </section>

        <section aria-labelledby="how" className="border-y border-line bg-white">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <h2 id="how" className="sr-only">
              How it works
            </h2>
            <ol className="divide-y divide-line">
              {PILLARS.map((p) => (
                <li key={p.n} className="grid gap-3 py-9 md:grid-cols-[120px_240px_1fr] md:items-baseline md:gap-8 md:py-11">
                  <span className="font-mono text-sm text-muted tnum" aria-hidden>
                    {p.n}
                  </span>
                  <h3 className="text-[1.75rem] font-semibold tracking-tight">{p.title}</h3>
                  <p className="max-w-xl text-base leading-relaxed text-slate-700">{p.body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section aria-labelledby="honest" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-20">
          <div className="grid gap-10 md:grid-cols-[1fr_1.4fr]">
            <h2 id="honest" className="text-[1.75rem] font-semibold leading-tight tracking-tight text-balance">
              Clear about what it is — and what it isn’t.
            </h2>
            <dl className="grid gap-6 sm:grid-cols-2">
              {[
                ['Not a decision-maker', 'Results say “Potential Match” or “More Information Needed.” Only a program can decide eligibility.'],
                ['Not a government portal', 'Statuses are what you report. We link you to the official site for every program.'],
                ['Private by design', 'Answers stay in your browser tab. We ask about support needs, never diagnoses.'],
                ['Built for access', 'Keyboard and screen-reader friendly, adjustable text size, and a simplified mode.'],
              ].map(([t, d]) => (
                <div key={t} className="border-t border-ink pt-4">
                  <dt className="font-semibold">{t}</dt>
                  <dd className="mt-1.5 text-[0.9375rem] text-slate-700">{d}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>
      </main>

      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-6 text-sm text-muted sm:flex-row sm:justify-between sm:px-6">
          <p>BenefitsBridge · Hackathon demo. Program summaries are illustrative and are not eligibility decisions.</p>
          <Link to="/onboarding" className="font-medium text-ink hover:underline underline-offset-4">
            Get started
          </Link>
        </div>
      </footer>
    </div>
  );
}
