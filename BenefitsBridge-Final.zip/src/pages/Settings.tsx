import { useState, type FormEvent } from 'react';
import { Database, Plug } from 'lucide-react';
import type { Profile, TextSize } from '../types';
import { useStore } from '../lib/store';
import { activeEngines } from '../lib/integration';
import { navigate } from '../lib/router';
import { Button } from '../components/Button';
import { ChoiceGroup, Switch } from '../components/Field';
import { Dialog } from '../components/Dialog';
import { PageHeader, Panel } from '../components/Primitives';
import { useToast } from '../components/Toast';
import { STEPS, StepFields, validateAge } from '../features/onboarding/ProfileFields';

export function SettingsPage() {
  const { state, dispatch, prefs, setPrefs } = useStore();
  const notify = useToast();
  const [draft, setDraft] = useState<Profile>(state.profile ?? { supportNeeds: [], assistanceSought: [] });
  const [ageText, setAgeText] = useState(draft.age?.toString() ?? '');
  const [ageError, setAgeError] = useState<string>();
  const [confirm, setConfirm] = useState<null | 'clear' | 'demo'>(null);
  const engines = activeEngines();

  const save = (e: FormEvent) => {
    e.preventDefault();
    const { age, error } = validateAge(ageText);
    if (error) {
      setAgeError(error);
      document.getElementById('age-input')?.focus();
      return;
    }
    setAgeError(undefined);
    dispatch({ type: 'setProfile', profile: { ...draft, age } });
    notify('Profile saved. Results updated.', { label: 'See results', onClick: () => navigate('/app/discover') });
  };

  return (
    <>
      <PageHeader title="Settings" description="Your profile, display preferences and data." />

      <div className="grid gap-8 xl:grid-cols-[1fr_380px]">
        <form onSubmit={save} noValidate aria-labelledby="profile-title" className="rounded-lg border border-line bg-white shadow-card">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-4">
            <div>
              <h2 id="profile-title" className="text-[1.0625rem] font-semibold">
                Profile
              </h2>
              <p className="mt-0.5 text-sm text-muted">Every question is optional. Changes re-run your matches.</p>
            </div>
            <Button type="submit" variant="primary">
              Save profile
            </Button>
          </div>
          <div className="divide-y divide-line">
            {STEPS.map((s, i) => (
              <section key={s.key} aria-labelledby={`ps-${s.key}`} className="px-5 py-7">
                <h3 id={`ps-${s.key}`} className="mb-1 text-base font-semibold">
                  {s.title}
                </h3>
                <p className="mb-5 text-sm text-muted">{s.why}</p>
                <StepFields step={i} profile={draft} onChange={setDraft} ageText={ageText} setAgeText={setAgeText} ageError={ageError} />
              </section>
            ))}
          </div>
          <div className="flex justify-end border-t border-line bg-canvas px-5 py-4 rounded-b-lg">
            <Button type="submit" variant="primary">
              Save profile
            </Button>
          </div>
        </form>

        <div className="space-y-6 xl:sticky xl:top-8 xl:self-start">
          <Panel title="Display" description="Saved on this device.">
            <ChoiceGroup<TextSize>
              legend="Text size"
              name="text-size"
              value={prefs.textSize}
              onChange={(v) => setPrefs({ textSize: v })}
              options={[
                { value: 'default', label: 'Default' },
                { value: 'large', label: 'Large' },
                { value: 'larger', label: 'Larger' },
              ]}
            />
            <div className="mt-2 divide-y divide-line">
              <Switch
                label="Simplified interface"
                description="Hides secondary details like summary metrics and extra card text. Every feature stays available."
                checked={prefs.simplified}
                onChange={(v) => setPrefs({ simplified: v })}
              />
              <Switch
                label="Reduce motion"
                description="Turns off animations. We also follow your system setting."
                checked={prefs.reduceMotion}
                onChange={(v) => setPrefs({ reduceMotion: v })}
              />
            </div>
          </Panel>

          <Panel title="Data & privacy">
            <div className="flex gap-3 text-sm text-slate-700">
              <Database aria-hidden className="mt-0.5 h-4 w-4 shrink-0 text-muted" />
              <p>Your profile, tasks, applications, and equipment notes are stored only in this browser tab and cleared when you close it. Nothing is sent to a server.</p>
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button onClick={() => setConfirm('demo')}>Load demo profile</Button>
              <Button variant="danger" onClick={() => setConfirm('clear')}>
                Clear all data
              </Button>
            </div>
          </Panel>

          <Panel title="Integrations" description="For the hackathon team.">
            <ul className="space-y-3 text-sm">
              {[
                ['Benefits matching', 'matchBenefits(profile)', engines.matcher],
                ['Life-event simulator', 'simulateLifeEvent(profile, event)', engines.simulator],
              ].map(([label, fn, kind]) => (
                <li key={label} className="flex items-start gap-3">
                  <Plug aria-hidden className="mt-0.5 h-4 w-4 shrink-0 text-muted" />
                  <div className="flex-1">
                    <p className="font-medium">{label}</p>
                    <code className="font-mono text-xs text-muted">{fn}</code>
                  </div>
                  <span className={kind === 'demo' ? 'rounded bg-caution-soft px-2 py-0.5 text-xs font-medium text-caution-ink' : 'rounded bg-positive-soft px-2 py-0.5 text-xs font-medium text-positive-ink'}>
                    {kind === 'demo' ? 'Demo adapter' : 'Live'}
                  </span>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>

      <Dialog
        open={confirm !== null}
        onClose={() => setConfirm(null)}
        size="sm"
        title={confirm === 'clear' ? 'Clear all data?' : 'Replace with the demo profile?'}
        description={
          confirm === 'clear'
            ? 'This removes your profile, saved programs, applications and tasks from this tab.'
            : 'Your current profile, saved programs, applications and tasks will be replaced with Jordan’s fictional data.'
        }
        footer={
          <>
            <Button onClick={() => setConfirm(null)}>Cancel</Button>
            <Button
              variant={confirm === 'clear' ? 'danger' : 'primary'}
              onClick={() => {
                if (confirm === 'clear') {
                  dispatch({ type: 'reset' });
                  notify('All data cleared.');
                  navigate('/');
                } else {
                  dispatch({ type: 'loadDemo' });
                  notify('Demo profile loaded.');
                  navigate('/app/overview');
                }
                setConfirm(null);
              }}
            >
              {confirm === 'clear' ? 'Clear data' : 'Load demo'}
            </Button>
          </>
        }
      >
        <p className="text-sm text-slate-700">This can’t be undone.</p>
      </Dialog>
    </>
  );
}
