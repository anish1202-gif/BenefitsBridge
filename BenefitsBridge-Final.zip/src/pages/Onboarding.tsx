import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowLeft, ArrowRight, Check, Lock, Sparkles } from 'lucide-react';
import type { Profile } from '../types';
import { useStore } from '../lib/store';
import { Link, navigate } from '../lib/router';
import { Button } from '../components/Button';
import { Logo, ProgressBar } from '../components/Primitives';
import { STEPS, StepFields, validateAge } from '../features/onboarding/ProfileFields';
import { useToast } from '../components/Toast';
import { cx } from '../components/cx';

const EMPTY: Profile = { supportNeeds: [], assistanceSought: [] };

export function OnboardingPage() {
  const { state, dispatch } = useStore();
  const notify = useToast();
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState<Profile>(() => (state.profile && !state.profile.isDemo ? state.profile : EMPTY));
  const [ageText, setAgeText] = useState(profile.age?.toString() ?? '');
  const [ageError, setAgeError] = useState<string>();
  const heading = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    document.title = `Set up · Step ${step + 1} of ${STEPS.length} · BenefitsBridge`;
    heading.current?.focus();
  }, [step]);

  const loadDemo = () => {
    dispatch({ type: 'loadDemo' });
    notify('Loaded the demo profile for Jordan. All data is fictional.');
    navigate('/app/overview');
  };

  const finish = (p: Profile) => {
    dispatch({ type: 'setProfile', profile: { ...p, isDemo: false } });
    notify('Profile saved. Your results are ready.');
    navigate('/app/overview');
  };

  const next = (e?: FormEvent, skip = false) => {
    e?.preventDefault();
    let p = profile;
    if (STEPS[step].key === 'basics') {
      if (skip) {
        p = { ...p, age: undefined };
        setAgeText('');
        setAgeError(undefined);
      } else {
        const { age, error } = validateAge(ageText);
        if (error) {
          setAgeError(error);
          document.getElementById('age-input')?.focus();
          return;
        }
        setAgeError(undefined);
        p = { ...p, age };
      }
      setProfile(p);
    }
    if (step === STEPS.length - 1) finish(p);
    else setStep(step + 1);
  };

  const s = STEPS[step];

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[minmax(320px,420px)_1fr]">
      {/* Context rail */}
      <aside className="on-dark bg-night px-6 py-6 text-slate-300 lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col lg:px-10 lg:py-10">
        <Link to="/" className="inline-block rounded-md" aria-label="BenefitsBridge home">
          <Logo dark />
        </Link>
        <div className="mt-8 hidden lg:block">
          <p className="text-sm font-medium text-slate-400">Set up your profile</p>
          <ol className="mt-5 space-y-1">
            {STEPS.map((st, i) => (
              <li key={st.key} className="flex items-center gap-3 py-1.5" aria-current={i === step ? 'step' : undefined}>
                <span
                  aria-hidden
                  className={cx(
                    'flex h-6 w-6 items-center justify-center rounded-full border text-xs tnum',
                    i < step ? 'border-brand bg-brand text-white' : i === step ? 'border-brand-ring text-white' : 'border-white/20 text-slate-500',
                  )}
                >
                  {i < step ? <Check className="h-3.5 w-3.5" strokeWidth={3} /> : i + 1}
                </span>
                <span className={cx('text-[0.9375rem]', i === step ? 'font-medium text-white' : i < step ? 'text-slate-300' : 'text-slate-400')}>
                  {st.title}
                  <span className="sr-only">{i < step ? ' (done)' : i === step ? ' (current)' : ''}</span>
                </span>
              </li>
            ))}
          </ol>
        </div>
        <div className="mt-auto hidden space-y-4 lg:block">
          <div className="flex gap-3 text-sm text-slate-400">
            <Lock aria-hidden className="mt-0.5 h-4 w-4 shrink-0" />
            <p>No account needed. Answers stay in this browser tab and are cleared when you close it. We never ask for medical records or ID numbers.</p>
          </div>
        </div>
      </aside>

      {/* Form */}
      <main className="px-4 py-8 sm:px-8 lg:px-16 lg:py-14">
        <div className="mx-auto max-w-xl">
          <div className="mb-8 flex flex-col gap-3 rounded-lg border border-line bg-white p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <Sparkles aria-hidden className="mt-0.5 h-5 w-5 shrink-0 text-brand" />
              <p className="text-sm text-slate-700">
                <span className="font-medium text-ink">Just looking?</span> Explore with Jordan, a fictional 19-year-old college student in Georgia.
              </p>
            </div>
            <Button size="sm" variant="dark" onClick={loadDemo} className="shrink-0">
              Explore demo
            </Button>
          </div>

          <p className="text-sm font-medium text-muted tnum">
            Step {step + 1} of {STEPS.length}
          </p>
          <div className="mt-2">
            <ProgressBar value={step} max={STEPS.length} label="Setup progress" />
          </div>

          <form onSubmit={next} noValidate className="mt-8">
            <h1 ref={heading} tabIndex={-1} className="text-[1.75rem] font-semibold leading-tight">
              {s.title}
            </h1>
            <p className="mt-2 text-base text-muted">{s.lede}</p>

            <details className="group mt-4 rounded-md border border-line bg-white px-4 py-3 text-sm">
              <summary className="cursor-pointer font-medium text-ink marker:text-muted">Why we ask</summary>
              <p className="mt-2 text-slate-700">{s.why}</p>
            </details>

            <div className="mt-8">
              <StepFields step={step} profile={profile} onChange={setProfile} ageText={ageText} setAgeText={setAgeText} ageError={ageError} />
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-3 border-t border-line pt-6">
              {step > 0 && (
                <Button onClick={() => setStep(step - 1)} icon={<ArrowLeft aria-hidden className="h-4 w-4" />}>
                  Back
                </Button>
              )}
              <div className="ml-auto flex flex-wrap gap-3">
                <Button variant="ghost" onClick={() => next(undefined, true)}>
                  Skip this step
                </Button>
                <Button variant="primary" type="submit">
                  {step === STEPS.length - 1 ? 'See my results' : 'Continue'}
                  <ArrowRight aria-hidden className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}
