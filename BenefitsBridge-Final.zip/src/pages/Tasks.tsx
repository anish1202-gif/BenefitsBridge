import { useMemo, useState } from 'react';
import { ListChecks, Plus } from 'lucide-react';
import type { Task } from '../types';
import { useStore } from '../lib/store';
import { daysUntil } from '../lib/dates';
import { Button } from '../components/Button';
import { EmptyState, PageHeader } from '../components/Primitives';
import { TaskRow } from '../features/tasks/TaskRow';
import { useTaskComposer } from '../features/tasks/TaskComposer';
import { cx } from '../components/cx';

type Filter = 'open' | 'done' | 'all';

const GROUPS: { key: string; title: string; test: (t: Task) => boolean }[] = [
  { key: 'overdue', title: 'Overdue', test: (t) => !!t.dueDate && daysUntil(t.dueDate) < 0 },
  { key: 'week', title: 'Next 7 days', test: (t) => !!t.dueDate && daysUntil(t.dueDate) >= 0 && daysUntil(t.dueDate) <= 7 },
  { key: 'later', title: 'Later', test: (t) => !!t.dueDate && daysUntil(t.dueDate) > 7 },
  { key: 'nodate', title: 'No due date', test: (t) => !t.dueDate },
];

export function TasksPage() {
  const { state } = useStore();
  const compose = useTaskComposer();
  const [filter, setFilter] = useState<Filter>('open');

  const list = useMemo(
    () =>
      state.tasks
        .filter((t) => (filter === 'open' ? !t.done : filter === 'done' ? t.done : true))
        .sort((a, b) => (a.dueDate ?? '9999').localeCompare(b.dueDate ?? '9999') || (a.priority === 'high' ? -1 : 1)),
    [state.tasks, filter],
  );

  const counts = { open: state.tasks.filter((t) => !t.done).length, done: state.tasks.filter((t) => t.done).length, all: state.tasks.length };

  return (
    <>
      <PageHeader
        title="Tasks & deadlines"
        description="Everything you need to do, in date order. Dates are the ones you set — check official notices for real deadlines."
        actions={
          <Button variant="primary" onClick={() => compose()} icon={<Plus aria-hidden className="h-4 w-4" />}>
            New task
          </Button>
        }
      />

      <div role="group" aria-label="Show tasks" className="mb-6 inline-flex rounded-md border border-line bg-white p-1">
        {(['open', 'done', 'all'] as Filter[]).map((f) => (
          <button
            key={f}
            type="button"
            aria-pressed={filter === f}
            onClick={() => setFilter(f)}
            className={cx('h-9 rounded px-4 text-sm font-medium capitalize transition-colors', filter === f ? 'bg-ink text-white' : 'text-slate-700 hover:bg-slate-100')}
          >
            {f === 'done' ? 'Completed' : f} <span className="tnum opacity-70">{counts[f]}</span>
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <EmptyState
          icon={<ListChecks className="h-5 w-5" />}
          title={filter === 'done' ? 'No completed tasks yet' : 'No open tasks'}
          action={
            <Button variant="primary" onClick={() => compose()}>
              Add a task
            </Button>
          }
        >
          {filter === 'done' ? 'Tasks you check off will appear here.' : 'Add tasks yourself, or create them from a program or the Life Simulator.'}
        </EmptyState>
      ) : filter === 'done' ? (
        <section className="overflow-hidden rounded-lg border border-line bg-white shadow-card">
          <ul className="divide-y divide-line">
            {list.map((t) => (
              <TaskRow key={t.id} task={t} />
            ))}
          </ul>
        </section>
      ) : (
        <div className="space-y-6">
          {GROUPS.map((g) => {
            const items = list.filter(g.test);
            if (!items.length) return null;
            return (
              <section key={g.key} aria-labelledby={`g-${g.key}`} className="overflow-hidden rounded-lg border border-line bg-white shadow-card">
                <h2 id={`g-${g.key}`} className={cx('flex items-center justify-between border-b border-line bg-canvas px-5 py-2.5 text-sm font-semibold', g.key === 'overdue' && 'text-danger-ink')}>
                  {g.title}
                  <span className="font-normal text-muted tnum">{items.length}</span>
                </h2>
                <ul className="divide-y divide-line">
                  {items.map((t) => (
                    <TaskRow key={t.id} task={t} />
                  ))}
                </ul>
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}
