import { ArrowLeft, Building2, CircleCheck, CircleHelp, FileText, FolderKanban, ListPlus, Plus, Users } from 'lucide-react';
import type { ReactNode } from 'react';
import { useMatches, useStore } from '../lib/store';
import { getProgram } from '../lib/programs';
import { CATEGORY_LABEL, stateName } from '../lib/labels';
import { addDays } from '../lib/dates';
import { Link, navigate } from '../lib/router';
import { Button, LinkButton } from '../components/Button';
import { MatchBadge, Tag } from '../components/Badges';
import { EmptyState, Notice } from '../components/Primitives';
import { useToast } from '../components/Toast';
import { SaveButton } from '../features/benefits/ProgramCard';
import { useTaskComposer } from '../features/tasks/TaskComposer';
import { useEffect, useRef } from 'react';

function Section({ title, icon, children }: { title: string; icon: ReactNode; children: ReactNode }) {
  return (
    <section className="border-t border-line py-7 first:border-t-0 first:pt-0">
      <h2 className="mb-3 flex items-center gap-2 text-[1.0625rem] font-semibold">
        <span aria-hidden className="text-muted">
          {icon}
        </span>
        {title}
      </h2>
      {children}
    </section>
  );
}

function Bullets({ items }: { items: string[] }) {
  return (
    <ul className="space-y-2">
      {items.map((it) => (
        <li key={it} className="flex gap-3 text-[0.9375rem] text-slate-700">
          <span aria-hidden className="mt-[0.6em] h-1.5 w-1.5 shrink-0 rounded-full bg-slate-400" />
          {it}
        </li>
      ))}
    </ul>
  );
}

export function ProgramDetailPage({ id }: { id: string }) {
  const program = getProgram(id);
  const { state, dispatch } = useStore();
  const { byProgram, match: matchState } = useMatches();
  const notify = useToast();
  const compose = useTaskComposer();
  const h1 = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (program) document.title = `${program.name} · BenefitsBridge`;
    h1.current?.focus({ preventScroll: true });
  }, [program]);

  if (!program) {
    return (
      <EmptyState icon={<CircleHelp className="h-5 w-5" />} title="Program not found" action={<LinkButton href="#/app/discover">Back to Discover</LinkButton>}>
        This link may be out of date.
      </EmptyState>
    );
  }

  const match = byProgram.get(program.id);
  const app = state.applications.find((a) => a.programId === program.id);
  const programTasks = state.tasks.filter((t) => t.programId === program.id && !t.done);

  const track = () => {
    dispatch({ type: 'startApplication', programId: program.id });
    notify(`Tracking ${program.name}. A document checklist was created.`, { label: 'Open', onClick: () => navigate('/app/applications') });
  };

  const addSuggestedTasks = () => {
    const titles = [program.defaultNextAction, `Gather documents for ${program.name}`];
    const fresh = titles.filter((t) => !state.tasks.some((x) => x.title === t && !x.done));
    fresh.forEach((title, i) => dispatch({ type: 'addTask', task: { title, programId: program.id, dueDate: addDays(7 * (i + 1)), priority: i === 0 ? 'high' : 'normal', source: 'suggested' } }));
    notify(fresh.length ? `Added ${fresh.length} ${fresh.length === 1 ? 'task' : 'tasks'} with sample due dates you can change.` : 'Those tasks are already on your list.', {
      label: 'View tasks',
      onClick: () => navigate('/app/tasks'),
    });
  };

  return (
    <>
      <nav aria-label="Breadcrumb" className="mb-6">
        <Link to="/app/discover" className="inline-flex items-center gap-1.5 rounded text-sm font-medium text-muted hover:text-ink">
          <ArrowLeft aria-hidden className="h-4 w-4" />
          Discover benefits
        </Link>
      </nav>

      <header className="mb-8 max-w-3xl">
        <p className="text-sm font-medium text-muted">
          {CATEGORY_LABEL[program.category]} · {program.jurisdiction === 'US' ? 'National program' : stateName(program.jurisdiction)}
        </p>
        <h1 ref={h1} tabIndex={-1} className="mt-2 text-[1.875rem] font-semibold leading-tight md:text-[2.25rem] text-balance">
          {program.name}
        </h1>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          {match ? <MatchBadge status={match.status} /> : matchState.status === 'loading' ? <span className="skeleton inline-block h-6 w-32 rounded-full" /> : null}
          <span className="inline-flex items-center gap-1.5 text-sm text-muted">
            <Building2 aria-hidden className="h-4 w-4" />
            {program.provider}
          </span>
        </div>
      </header>

      <div className="grid gap-8 lg:grid-cols-[1fr_340px] lg:gap-12">
        <div className="min-w-0">
          <Section title="Overview" icon={<FileText className="h-4 w-4" />}>
            <p className="text-base leading-relaxed text-slate-700">{program.summary}</p>
          </Section>

          {match && match.status !== 'not_matched' && (
            <Section title="Why it might match your profile" icon={<CircleCheck className="h-4 w-4" />}>
              <Bullets items={match.reasons} />
            </Section>
          )}
          {match?.status === 'not_matched' && (
            <Section title="Why it isn’t currently matched" icon={<CircleHelp className="h-4 w-4" />}>
              <Bullets items={match.reasons} />
            </Section>
          )}

          {match && match.missingInfo.length > 0 && (
            <Section title="Information still missing" icon={<CircleHelp className="h-4 w-4" />}>
              <ul className="divide-y divide-caution-line overflow-hidden rounded-md border border-caution-line bg-caution-soft/40">
                {match.missingInfo.map((m) => (
                  <li key={m} className="px-4 py-2.5 text-[0.9375rem] text-caution-ink">
                    {m}
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-sm text-muted">
                Some of these can be added to your{' '}
                <Link to="/app/settings" className="font-medium text-brand underline underline-offset-2">
                  profile
                </Link>
                . Others only the program can confirm.
              </p>
            </Section>
          )}

          <Section title="Who it may help" icon={<Users className="h-4 w-4" />}>
            <Bullets items={program.whoItMayHelp} />
          </Section>

          <Section title="What the program generally considers" icon={<FileText className="h-4 w-4" />}>
            <Bullets items={program.eligibilityFactors} />
            <p className="mt-4 text-sm text-muted">Exact limits and rules change. Check the official site for current requirements.</p>
          </Section>

          <Section title="Documents that may be requested" icon={<FolderKanban className="h-4 w-4" />}>
            <Bullets items={program.documents} />
          </Section>

          <Notice>
            <Tag className="mr-2 align-middle">Illustrative</Tag>
            This summary was written for the BenefitsBridge demo and hasn’t been verified against current program rules.
            {program.officialUrl ? ' Confirm everything on the official site.' : ' Contact the provider directly to confirm.'}
          </Notice>
        </div>

        {/* Action rail */}
        <aside aria-label="Actions" className="lg:sticky lg:top-8 lg:self-start">
          <div className="rounded-lg border border-line bg-white shadow-card">
            <div className="border-b border-line p-5">
              <p className="text-sm font-medium text-muted">Recommended next action</p>
              <p className="mt-1.5 text-[1.0625rem] font-semibold leading-snug">{match?.nextAction ?? program.defaultNextAction}</p>
            </div>
            <div className="space-y-2.5 p-5">
              {app ? (
                <LinkButton href={`#/app/applications?focus=${app.id}`} variant="primary" className="w-full" icon={<FolderKanban aria-hidden className="h-4 w-4" />}>
                  View application
                </LinkButton>
              ) : (
                <Button variant="primary" className="w-full" onClick={track} icon={<FolderKanban aria-hidden className="h-4 w-4" />}>
                  Track application
                </Button>
              )}
              <Button className="w-full" onClick={addSuggestedTasks} icon={<ListPlus aria-hidden className="h-4 w-4" />}>
                Create application tasks
              </Button>
              <div className="grid grid-cols-2 gap-2.5">
                <SaveButton program={program} size="md" className="w-full" />
                <Button className="w-full" onClick={() => compose({ programId: program.id })} icon={<Plus aria-hidden className="h-4 w-4" />}>
                  Task
                  <span className="sr-only"> for {program.name}</span>
                </Button>
              </div>
            </div>
            <div className="border-t border-line p-5">
              {program.officialUrl ? (
                <>
                  <p className="text-sm text-muted">Official source</p>
                  <LinkButton href={program.officialUrl} external variant="ghost" className="-ml-3 mt-1 h-auto py-1.5 text-brand">
                    {program.officialLabel}
                  </LinkButton>
                </>
              ) : (
                <p className="text-sm text-muted">No single official website — contact your college directly.</p>
              )}
            </div>
          </div>

          {programTasks.length > 0 && (
            <div className="mt-4 rounded-lg border border-line bg-white p-5">
              <p className="text-sm font-medium">
                Open tasks for this program <span className="tnum text-muted">({programTasks.length})</span>
              </p>
              <ul className="mt-2 space-y-1.5 text-sm text-slate-700">
                {programTasks.map((t) => (
                  <li key={t.id}>• {t.title}</li>
                ))}
              </ul>
              <Link to="/app/tasks" className="mt-3 inline-block text-sm font-medium text-brand underline-offset-2 hover:underline">
                Manage tasks
              </Link>
            </div>
          )}
        </aside>
      </div>
    </>
  );
}
