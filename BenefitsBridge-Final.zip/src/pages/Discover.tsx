import { useMemo, useState } from 'react';
import { Info, RefreshCw, Search, SearchX } from 'lucide-react';
import type { BenefitCategory, MatchStatus } from '../types';
import { useMatches, useStore } from '../lib/store';
import { PROGRAMS } from '../lib/programs';
import { CATEGORIES, CATEGORY_LABEL, MATCH_LABEL } from '../lib/labels';
import { Button } from '../components/Button';
import { EmptyState, Notice, PageHeader } from '../components/Primitives';
import { ProgramCard, ProgramCardSkeleton } from '../features/benefits/ProgramCard';
import { cx } from '../components/cx';

export function DiscoverPage() {
  const { state } = useStore();
  const { match, byProgram, retry } = useMatches();
  const [q, setQ] = useState('');
  const [cats, setCats] = useState<BenefitCategory[]>([]);
  const [status, setStatus] = useState<MatchStatus | 'all'>('all');

  const order = useMemo(() => (match.status === 'ready' ? match.data.results.map((r) => r.programId) : PROGRAMS.map((p) => p.id)), [match]);

  const visible = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return order
      .map((id) => PROGRAMS.find((p) => p.id === id)!)
      .filter((p) => (cats.length ? cats.includes(p.category) : true))
      .filter((p) => (status === 'all' ? true : byProgram.get(p.id)?.status === status))
      .filter((p) => !needle || [p.name, p.provider, p.summary, CATEGORY_LABEL[p.category]].join(' ').toLowerCase().includes(needle));
  }, [order, cats, status, q, byProgram]);

  const statusCounts = useMemo(() => {
    const c: Record<string, number> = { potential_match: 0, more_info_needed: 0, not_matched: 0 };
    byProgram.forEach((r) => (c[r.status] += 1));
    return c;
  }, [byProgram]);

  const clear = () => {
    setQ('');
    setCats([]);
    setStatus('all');
  };
  const filtered = q || cats.length || status !== 'all';

  return (
    <>
      <PageHeader
        title="Discover benefits"
        description={
          <>
            Programs that may fit {state.profile?.firstName ? `${state.profile.firstName}’s` : 'your'} profile, across healthcare, money, transportation, work and more.
          </>
        }
      />

      <div className="mb-6 space-y-4">
        <div className="flex flex-col gap-3 md:flex-row">
          <div className="relative flex-1">
            <label htmlFor="program-search" className="sr-only">
              Search programs
            </label>
            <Search aria-hidden className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
            <input
              id="program-search"
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search by program, agency or need"
              className="h-11 w-full rounded-md border border-line bg-white pl-9 pr-3 text-[0.9375rem] placeholder:text-slate-400 hover:border-slate-300"
            />
          </div>
          <div className="md:w-64">
            <label htmlFor="status-filter" className="sr-only">
              Filter by match status
            </label>
            <select
              id="status-filter"
              value={status}
              onChange={(e) => setStatus(e.target.value as MatchStatus | 'all')}
              className="h-11 w-full rounded-md border border-line bg-white px-3 text-[0.9375rem] hover:border-slate-300"
            >
              <option value="all">All statuses</option>
              {(Object.keys(MATCH_LABEL) as MatchStatus[]).map((s) => (
                <option key={s} value={s}>
                  {MATCH_LABEL[s]} ({statusCounts[s]})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div role="group" aria-label="Filter by category" className="-mx-1 flex flex-wrap gap-2 px-1">
          {CATEGORIES.map((c) => {
            const on = cats.includes(c);
            return (
              <button
                key={c}
                type="button"
                aria-pressed={on}
                onClick={() => setCats(on ? cats.filter((x) => x !== c) : [...cats, c])}
                className={cx(
                  'h-9 rounded-full border px-3.5 text-sm font-medium transition-colors',
                  on ? 'border-ink bg-ink text-white' : 'border-line bg-white text-slate-700 hover:border-slate-300',
                )}
              >
                {CATEGORY_LABEL[c]}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <p role="status" aria-live="polite" className="text-sm text-muted tnum">
          {match.status === 'loading' ? 'Updating results…' : `Showing ${visible.length} of ${PROGRAMS.length} programs`}
        </p>
        {filtered ? (
          <Button size="sm" variant="ghost" onClick={clear}>
            Clear filters
          </Button>
        ) : null}
      </div>

      {match.status === 'error' ? (
        <Notice tone="caution">
          <p className="font-medium">The matching service didn’t respond.</p>
          <p className="mt-0.5">{match.message} You can still browse programs below.</p>
          <Button size="sm" className="mt-3" onClick={retry} icon={<RefreshCw aria-hidden className="h-4 w-4" />}>
            Try again
          </Button>
        </Notice>
      ) : null}

      {match.status === 'loading' && byProgram.size === 0 ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3" aria-busy="true">
          {Array.from({ length: 6 }, (_, i) => (
            <ProgramCardSkeleton key={i} />
          ))}
        </div>
      ) : visible.length === 0 ? (
        <EmptyState icon={<SearchX className="h-5 w-5" />} title="No programs match those filters" action={<Button onClick={clear}>Clear filters</Button>}>
          Try a broader search or remove a category.
        </EmptyState>
      ) : (
        <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {visible.map((p) => (
            <li key={p.id}>
              <ProgramCard program={p} match={byProgram.get(p.id)} />
            </li>
          ))}
        </ul>
      )}

      <div className="mt-10">
        <Notice icon={<Info className="h-4 w-4" />}>
          <span className="font-medium text-ink">How results work.</span> Statuses show how your answers line up with each program’s general criteria. They aren’t
          approvals or eligibility decisions — only the program can decide that. Program summaries are illustrative; always confirm details on the official site.
          {match.status === 'ready' && match.data.engine.kind === 'demo' && <> Results are produced by a demo adapter until the team’s matching engine is connected.</>}
        </Notice>
      </div>
    </>
  );
}
