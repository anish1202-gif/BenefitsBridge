/**
 * Shared domain types for BenefitsBridge.
 *
 * These are the contract between the frontend and teammates' modules
 * (matching engine, life-event simulator). Change with care: both
 * `src/lib/integration.ts` and the demo adapters implement against them.
 */

// ───────────────────────── Profile ─────────────────────────

export type EmploymentStatus = 'not_employed' | 'part_time' | 'full_time' | 'self_employed' | 'unable_to_work';
export type StudentStatus = 'not_student' | 'part_time' | 'full_time';
export type IncomeRange = 'none' | 'under_1000' | '1000_2000' | '2000_3500' | 'over_3500';
export type InsuranceStatus = 'none' | 'medicaid' | 'medicare' | 'employer' | 'marketplace' | 'parent_plan' | 'unsure';

export type SupportNeed =
  | 'mobility'
  | 'vision'
  | 'hearing'
  | 'communication'
  | 'learning_cognitive'
  | 'ongoing_care'
  | 'mental_health_support';

export type BenefitCategory =
  | 'healthcare'
  | 'financial'
  | 'transportation'
  | 'employment'
  | 'assistive_tech'
  | 'housing'
  | 'education';

/**
 * Only what program discovery needs. Every field is optional because users
 * can skip any question. No diagnoses or medical records are collected.
 */
export interface Profile {
  firstName?: string;
  state?: string; // two-letter code, e.g. "GA"
  age?: number;
  employment?: EmploymentStatus;
  student?: StudentStatus;
  monthlyIncome?: IncomeRange; // individual earned income, per month
  insurance?: InsuranceStatus;
  supportNeeds: SupportNeed[];
  assistanceSought: BenefitCategory[];
  isDemo?: boolean;
}

// ───────────────────────── Programs ─────────────────────────

export interface Program {
  id: string;
  name: string;
  category: BenefitCategory;
  provider: string;
  /** Two-letter state code, or 'US' for federal/national programs. */
  jurisdiction: string;
  summary: string;
  whoItMayHelp: string[];
  eligibilityFactors: string[];
  documents: string[];
  officialUrl?: string;
  officialLabel?: string;
  /** Where the description came from. All demo copy is 'illustrative'. */
  sourceStatus: 'verified' | 'illustrative';
  defaultNextAction: string;
}

// ───────────────────────── Matching ─────────────────────────

/** Never "Approved" or "Eligible" — this product does not make determinations. */
export type MatchStatus = 'potential_match' | 'more_info_needed' | 'not_matched';

export interface MatchResult {
  programId: string;
  status: MatchStatus;
  /** Plain-language reasons this program surfaced for the profile. */
  reasons: string[];
  /** Facts the matcher needed but the profile doesn't contain. */
  missingInfo: string[];
  nextAction: string;
}

export interface MatchResponse {
  results: MatchResult[];
  /** Identifies which implementation produced the results (shown in Settings). */
  engine: { name: string; kind: 'demo' | 'live'; version?: string };
}

// ───────────────────────── Life events ─────────────────────────

export type LifeEvent =
  | { type: 'start_job'; hoursPerWeek: 'under_20' | '20_to_34' | '35_plus'; monthlyIncome: IncomeRange; employerCoverage: 'yes' | 'no' | 'unknown' }
  | { type: 'lose_job' }
  | { type: 'income_increase'; monthlyIncome: IncomeRange }
  | { type: 'move_state'; toState: string }
  | { type: 'coverage_renewal'; renewalDate?: string };

export type LifeEventType = LifeEvent['type'];

export type ImpactLevel = 'review' | 'needs_verification' | 'no_link_identified';

export interface ProfileFieldSnapshot {
  key: string;
  label: string;
  value: string;
}

export interface AffectedProgram {
  programId: string;
  impact: ImpactLevel;
  explanation: string;
}

export interface SimulationResult {
  before: ProfileFieldSnapshot[];
  after: ProfileFieldSnapshot[];
  affectedPrograms: AffectedProgram[];
  unknowns: { label: string; why: string }[];
  questionsToVerify: string[];
  suggestedActions: { id: string; title: string; programId?: string }[];
  engine: { name: string; kind: 'demo' | 'live'; version?: string };
}

// ───────────────────────── Tracking ─────────────────────────

/** User-reported. Not synced with any government system. */
export type ApplicationStatus = 'not_started' | 'gathering_documents' | 'ready_to_apply' | 'submitted' | 'awaiting_decision';

export interface ChecklistItem {
  id: string;
  label: string;
  done: boolean;
}

export interface Application {
  id: string;
  programId: string;
  status: ApplicationStatus;
  documents: ChecklistItem[];
  /** User-entered key date, e.g. when they submitted or a renewal date. */
  keyDate?: string;
  keyDateLabel?: string;
  updatedAt: string;
}

export type TaskPriority = 'high' | 'normal';

export interface Task {
  id: string;
  title: string;
  programId?: string;
  dueDate?: string; // YYYY-MM-DD, user-entered
  done: boolean;
  priority: TaskPriority;
  source: 'user' | 'suggested' | 'simulator';
  createdAt: string;
}

/**
 * User-recorded notes for an assistive-equipment request.
 * These are reminders of what the person has verified — not coverage,
 * inventory, or supplier determinations.
 */
export type FundingRecord = 'not_recorded' | 'still_verifying' | 'confirmed_with_source';
export type SupplierRecord = 'not_recorded' | 'not_yet' | 'recorded';

export interface EquipmentProgress {
  fundingStatus: FundingRecord;
  supplierStatus: SupplierRecord;
  /** A name the user already contacted. Not verified by the app. */
  supplierNote: string;
  completedStepIds: string[];
}

// ───────────────────────── Preferences ─────────────────────────

export type TextSize = 'default' | 'large' | 'larger';

export interface DisplayPrefs {
  textSize: TextSize;
  simplified: boolean;
  reduceMotion: boolean;
}
