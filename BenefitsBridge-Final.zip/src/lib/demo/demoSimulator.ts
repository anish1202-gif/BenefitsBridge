/**
 * ⚠️ DEMO ADAPTER — NOT A REAL LIFE-EVENT SIMULATOR.
 *
 * Qualitative before/after for a life change. It updates the snapshot from the
 * event inputs and flags what to re-check. It never predicts approvals,
 * terminations, dates, or dollar amounts. Replace via
 * `registerLifeEventSimulator()` in `src/lib/integration.ts`.
 */
import type { AffectedProgram, LifeEvent, Profile, ProfileFieldSnapshot, SimulationResult } from '../../types';
import { EMPLOYMENT_LABEL, INCOME_LABEL, INSURANCE_LABEL, STUDENT_LABEL, stateName } from '../labels';
import { PROGRAMS } from '../programs';

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

function snapshot(p: Profile): ProfileFieldSnapshot[] {
  return [
    { key: 'state', label: 'State', value: p.state ? stateName(p.state) : 'Not provided' },
    { key: 'employment', label: 'Work', value: p.employment ? EMPLOYMENT_LABEL[p.employment] : 'Not provided' },
    { key: 'monthlyIncome', label: 'Monthly earned income', value: p.monthlyIncome ? INCOME_LABEL[p.monthlyIncome] : 'Not provided' },
    { key: 'insurance', label: 'Health coverage', value: p.insurance ? INSURANCE_LABEL[p.insurance] : 'Not provided' },
    { key: 'student', label: 'School', value: p.student ? STUDENT_LABEL[p.student] : 'Not provided' },
  ];
}

const HOURS_LABEL = { under_20: 'under 20 hrs/week', '20_to_34': '20–34 hrs/week', '35_plus': '35+ hrs/week' } as const;

export async function demoLifeEventSimulator(profile: Profile, event: LifeEvent): Promise<SimulationResult> {
  await wait(350);

  const after: Profile = { ...profile };
  const affected: AffectedProgram[] = [];
  const unknowns: SimulationResult['unknowns'] = [];
  const questions: string[] = [];
  const actions: SimulationResult['suggestedActions'] = [];
  const add = (programId: string, impact: AffectedProgram['impact'], explanation: string) => affected.push({ programId, impact, explanation });

  switch (event.type) {
    case 'start_job': {
      after.employment = event.hoursPerWeek === '35_plus' ? 'full_time' : 'part_time';
      after.monthlyIncome = event.monthlyIncome;
      if (event.employerCoverage === 'yes') after.insurance = 'employer';
      add('ga-medicaid-abd', 'review', 'Income-based programs usually ask you to report new earnings. Whether this changes your coverage depends on rules and work incentives that need to be checked.');
      add('ssi', 'review', 'SSI counts earned income, but some earnings are excluded and student earned-income rules may apply. The effect needs to be calculated by SSA.');
      add('ga-snap', 'needs_verification', 'New income and hours can affect SNAP and may change how student rules apply. Not enough information to say how.');
      add('gvra-vr', 'no_link_identified', 'Vocational rehabilitation is designed to support you while you work. It may help with job accommodations.');
      add('ticket-to-work', 'needs_verification', 'If you receive SSI or SSDI, work-incentive counseling can explain how this job interacts with benefits.');
      add('marta-mobility', 'no_link_identified', 'Paratransit eligibility is based on your ability to use fixed-route transit, not income. A new commute may mean new trips to book.');
      unknowns.push(
        { label: 'Exact gross monthly pay', why: 'Ranges aren’t precise enough for income-based rules.' },
        { label: 'Whether the employer plan is affordable and meets your needs', why: 'This affects whether you’d compare it with other coverage.' },
        { label: 'Disability-related work expenses', why: 'Some programs exclude certain work expenses from countable income.' },
      );
      questions.push(
        'Do I need to report this job, and by when?',
        'Which work incentives (for example, student earned-income exclusions) apply to me?',
        'Will my Medicaid coverage continue while I work, and is there a work-related pathway?',
        'Does the employer offer accommodations I should request before starting?',
      );
      actions.push(
        { id: 'a1', title: 'Contact a benefits counselor about work incentives', programId: 'ticket-to-work' },
        { id: 'a2', title: 'Find out how and when to report new income to Medicaid', programId: 'ga-medicaid-abd' },
        { id: 'a3', title: 'Ask GVRA about workplace accommodations', programId: 'gvra-vr' },
        { id: 'a4', title: 'Plan accessible transportation for the new commute', programId: 'marta-mobility' },
      );
      if (event.employerCoverage === 'unknown') unknowns.push({ label: 'Whether the job offers health insurance', why: 'You marked this as unknown.' });
      break;
    }
    case 'lose_job': {
      after.employment = 'not_employed';
      after.monthlyIncome = 'none';
      if (profile.insurance === 'employer') after.insurance = 'none';
      add('ga-medicaid-abd', 'review', 'A drop in income may make it worth re-checking Medicaid. Your earnings history and resources still matter.');
      add('marketplace-coverage', profile.insurance === 'employer' ? 'review' : 'needs_verification', 'Losing job-based coverage often opens a special enrollment window. Timing matters.');
      add('ga-snap', 'review', 'Lower income is a reason to re-check SNAP. Household size and deductions still have to be verified with the program.');
      add('gvra-vr', 'no_link_identified', 'You can use vocational rehabilitation services while looking for work.');
      unknowns.push({ label: 'Final paycheck and severance timing', why: 'Some programs count income in the month it’s received.' });
      questions.push('Is there a deadline to enroll in new coverage after losing job-based insurance?', 'Should I report the change in income, and to which programs?');
      actions.push(
        { id: 'b1', title: 'Check special enrollment timing for health coverage', programId: 'marketplace-coverage' },
        { id: 'b2', title: 'Re-check Medicaid with updated income', programId: 'ga-medicaid-abd' },
        { id: 'b3', title: 'Talk to GVRA about job search support', programId: 'gvra-vr' },
      );
      break;
    }
    case 'income_increase': {
      after.monthlyIncome = event.monthlyIncome;
      add('ga-medicaid-abd', 'review', 'Income-tested programs usually need to know about changes. The effect depends on the program’s current limits.');
      add('ssi', 'review', 'Higher income can change SSI payments; exclusions may apply.');
      add('ga-snap', 'needs_verification', 'The effect depends on household size and deductions.');
      add('ga-stable', 'no_link_identified', 'An ABLE account may help you save extra income without affecting resource limits. Confirm the rules first.');
      unknowns.push({ label: 'Whether the increase is earned or unearned income', why: 'Programs treat these differently.' });
      questions.push('Which programs do I need to report this change to?', 'Are there exclusions that apply to my income?');
      actions.push(
        { id: 'c1', title: 'List every program to report the income change to' },
        { id: 'c2', title: 'Learn how an ABLE account works', programId: 'ga-stable' },
      );
      break;
    }
    case 'move_state': {
      after.state = event.toState;
      const leaving = profile.state ?? 'your current state';
      PROGRAMS.filter((p) => p.jurisdiction === profile.state).forEach((p) =>
        add(p.id, 'review', `${p.name} is a ${stateName(leaving)} program. You would generally need to look for the equivalent in ${stateName(event.toState)}.`),
      );
      add('ssi', 'needs_verification', 'SSI is federal, but some states add a supplement. Report your new address to SSA.');
      unknowns.push({ label: `Program rules in ${stateName(event.toState)}`, why: 'Each state runs its own Medicaid, SNAP and transit programs with different rules.' });
      questions.push('Is there a gap between ending coverage in one state and starting in another?', 'Which programs need a change of address?');
      actions.push(
        { id: 'd1', title: `Research Medicaid in ${stateName(event.toState)}` },
        { id: 'd2', title: 'Report a change of address to Social Security', programId: 'ssi' },
        { id: 'd3', title: `Find paratransit options in ${stateName(event.toState)}` },
      );
      break;
    }
    case 'coverage_renewal': {
      add('ga-medicaid-abd', 'review', 'Renewals usually require confirming income, address and household details. Missing paperwork is a common reason coverage lapses.');
      add('medicaid-net', 'needs_verification', 'Ride benefits generally depend on active Medicaid coverage.');
      unknowns.push({ label: 'Whether your contact information is current', why: 'Renewal notices are mailed or sent electronically to the address on file.' });
      if (!event.renewalDate) unknowns.push({ label: 'Your renewal date', why: 'Add the date from your notice so we can remind you.' });
      questions.push('What documents do I need to send for renewal?', 'How will I be notified, and by when must I respond?');
      actions.push(
        { id: 'e1', title: 'Confirm your mailing address with Medicaid', programId: 'ga-medicaid-abd' },
        { id: 'e2', title: 'Gather renewal documents', programId: 'ga-medicaid-abd' },
      );
      break;
    }
  }

  // Note the event-specific inputs in the "after" snapshot.
  const afterSnap = snapshot(after);
  if (event.type === 'start_job') {
    const w = afterSnap.find((f) => f.key === 'employment');
    if (w) w.value = `${w.value} (${HOURS_LABEL[event.hoursPerWeek]})`;
  }

  return {
    before: snapshot(profile),
    after: afterSnap,
    affectedPrograms: affected,
    unknowns,
    questionsToVerify: questions,
    suggestedActions: actions,
    engine: { name: 'BenefitsBridge simulator (qualitative only)', kind: 'demo', version: '1.0' },
  };
}
