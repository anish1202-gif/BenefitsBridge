/**
 * ⚠️ DEMO ADAPTER — NOT A REAL MATCHING ENGINE.
 *
 * Deterministic, in-browser signals so recommendations change with the profile.
 * It does not apply official income limits or decide eligibility. A teammate
 * can replace it with `registerBenefitsMatcher()` in `src/lib/integration.ts`.
 */
import type { MatchResponse, MatchResult, MatchStatus, Profile } from '../../types';
import { PROGRAMS } from '../programs';
import { CATEGORY_LABEL, stateName } from '../labels';

const LOW_INCOME = new Set(['none', 'under_1000']);

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function demoBenefitsMatcher(profile: Profile): Promise<MatchResponse> {
  await wait(450); // simulate network latency so loading states are visible

  const results: MatchResult[] = PROGRAMS.map((program) => {
    const reasons: string[] = [];
    const missing: string[] = [];
    let status: MatchStatus = 'more_info_needed';

    const sought = profile.assistanceSought.includes(program.category);
    if (sought) reasons.push(`You’re looking for ${CATEGORY_LABEL[program.category].toLowerCase()}.`);

    // Jurisdiction signal
    if (program.jurisdiction !== 'US') {
      if (!profile.state) {
        missing.push('Your state');
      } else if (profile.state !== program.jurisdiction) {
        return {
          programId: program.id,
          status: 'not_matched',
          reasons: [`This is a ${stateName(program.jurisdiction)} program and your profile lists ${stateName(profile.state)}.`],
          missingInfo: [],
          nextAction: 'Look for the equivalent program in your state',
        };
      } else {
        reasons.push(`You live in ${stateName(profile.state)}.`);
      }
    }

    const low = profile.monthlyIncome ? LOW_INCOME.has(profile.monthlyIncome) : undefined;
    const hasNeed = profile.supportNeeds.length > 0;
    const student = profile.student && profile.student !== 'not_student';

    switch (program.id) {
      case 'ga-medicaid-abd':
        if (low) reasons.push('Your reported earned income is in a lower range.');
        if (profile.insurance === 'none' || profile.insurance === 'unsure') reasons.push('You reported no current health coverage.');
        if (profile.monthlyIncome === undefined) missing.push('Monthly income range');
        missing.push('Whether you have a disability determination', 'Savings and other resources');
        status = low && hasNeed && profile.state === 'GA' ? 'potential_match' : 'more_info_needed';
        break;
      case 'marketplace-coverage':
        if (profile.insurance === 'none') reasons.push('You reported no current health coverage.');
        missing.push('Expected household income for the coverage year');
        status = profile.insurance === 'none' ? 'more_info_needed' : profile.insurance ? 'not_matched' : 'more_info_needed';
        if (status === 'not_matched') reasons.splice(0, reasons.length, 'You already reported health coverage.');
        break;
      case 'ssi':
        if (low) reasons.push('Your reported earned income is in a lower range.');
        missing.push('Disability determination status', 'Savings and other resources', 'Living arrangement');
        status = 'more_info_needed';
        break;
      case 'ga-snap':
        if (low) reasons.push('Your reported earned income is in a lower range.');
        if (student) missing.push('Whether a student exemption applies to you');
        missing.push('Household size and shared expenses');
        status = 'more_info_needed';
        break;
      case 'ga-stable':
        if (hasNeed) reasons.push('Could help you save without affecting resource-tested programs.');
        missing.push('Age when your disability began');
        status = 'more_info_needed';
        break;
      case 'marta-mobility':
        if (profile.supportNeeds.includes('mobility')) reasons.push('You reported mobility support needs.');
        missing.push('Whether your trips are inside MARTA’s service area');
        status = profile.supportNeeds.includes('mobility') && profile.state === 'GA' ? 'potential_match' : 'more_info_needed';
        break;
      case 'medicaid-net':
        missing.push('Active Medicaid coverage');
        status = profile.insurance === 'medicaid' ? 'potential_match' : 'more_info_needed';
        if (profile.insurance === 'medicaid') reasons.push('You reported Medicaid coverage.');
        break;
      case 'gvra-vr':
        if (hasNeed) reasons.push('You reported support needs that could affect work or school.');
        if (student) reasons.push('Students can often begin transition services before graduating.');
        status = hasNeed && profile.state === 'GA' && (sought || student) ? 'potential_match' : 'more_info_needed';
        break;
      case 'ticket-to-work':
        if (profile.age !== undefined && (profile.age < 18 || profile.age > 64)) {
          reasons.splice(0, reasons.length, 'Ticket to Work describes its audience as ages 18–64. The age on this profile is outside that range.');
          status = 'not_matched';
          break;
        }
        missing.push('Whether you currently receive SSI or SSDI');
        if (profile.age === undefined) missing.push('Your age');
        status = 'more_info_needed';
        break;
      case 'tools-for-life':
        if (hasNeed) reasons.push('You reported support needs that assistive technology may help with.');
        status = hasNeed && profile.state === 'GA' ? 'potential_match' : 'more_info_needed';
        break;
      case 'ga-hcv':
        missing.push('Household size and total household income', 'Your county or city');
        status = sought ? 'more_info_needed' : 'not_matched';
        if (!sought) reasons.splice(0, reasons.length, 'Housing wasn’t one of the types of help you selected. You can still review it.');
        break;
      case 'campus-disability-services':
      case 'fafsa':
        if (student) {
          reasons.push('You reported that you’re a student.');
          status = 'potential_match';
        } else {
          status = profile.student === 'not_student' ? 'not_matched' : 'more_info_needed';
          if (status === 'not_matched') reasons.splice(0, reasons.length, 'You reported you aren’t currently a student.');
          else missing.push('Student status');
        }
        break;
    }

    if (reasons.length === 0) reasons.push('Commonly used by people with similar support needs.');

    return {
      programId: program.id,
      status,
      reasons,
      missingInfo: status === 'not_matched' ? [] : missing,
      nextAction: program.defaultNextAction,
    };
  });

  const rank: Record<MatchStatus, number> = { potential_match: 0, more_info_needed: 1, not_matched: 2 };
  results.sort((a, b) => {
    const sa = profile.assistanceSought.includes(PROGRAMS.find((p) => p.id === a.programId)!.category) ? 0 : 1;
    const sb = profile.assistanceSought.includes(PROGRAMS.find((p) => p.id === b.programId)!.category) ? 0 : 1;
    return rank[a.status] - rank[b.status] || sa - sb;
  });

  return { results, engine: { name: 'BenefitsBridge matcher (not an official determination)', kind: 'demo', version: '1.0' } };
}
