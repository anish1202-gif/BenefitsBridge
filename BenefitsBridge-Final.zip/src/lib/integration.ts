/**
 * ════════════════════════════════════════════════════════════════════
 *  INTEGRATION BOUNDARY — teammates plug their real modules in here.
 * ════════════════════════════════════════════════════════════════════
 *
 * The UI only ever calls `matchBenefits()` and `simulateLifeEvent()` from
 * this file. Until the real engines are wired in, the clearly labeled DEMO
 * adapters in `./demo/` are used.
 *
 * To connect the real matching engine:
 *
 *   import { registerBenefitsMatcher } from './lib/integration';
 *   import { realMatcher } from '../backend/matcher';      // teammate's module
 *   registerBenefitsMatcher(realMatcher);                    // e.g. in main.tsx
 *
 * The same pattern applies to `registerLifeEventSimulator`.
 * Nothing in this file implements eligibility rules.
 */
import type { LifeEvent, MatchResponse, Profile, SimulationResult } from '../types';
import { demoBenefitsMatcher } from './demo/demoMatcher';
import { demoLifeEventSimulator } from './demo/demoSimulator';

/** Contract for the matching engine. Must not return determinations like "Approved". */
export type BenefitsMatcher = (profile: Profile) => Promise<MatchResponse>;

/** Contract for the life-event simulator. Must flag uncertainty instead of inventing outcomes. */
export type LifeEventSimulator = (profile: Profile, event: LifeEvent) => Promise<SimulationResult>;

let matcher: BenefitsMatcher = demoBenefitsMatcher;
let simulator: LifeEventSimulator = demoLifeEventSimulator;

export function registerBenefitsMatcher(impl: BenefitsMatcher) {
  matcher = impl;
}
export function registerLifeEventSimulator(impl: LifeEventSimulator) {
  simulator = impl;
}

export function matchBenefits(profile: Profile): Promise<MatchResponse> {
  return matcher(profile);
}

export function simulateLifeEvent(profile: Profile, event: LifeEvent): Promise<SimulationResult> {
  return simulator(profile, event);
}

export function activeEngines() {
  return {
    matcher: matcher === demoBenefitsMatcher ? 'demo' : 'live',
    simulator: simulator === demoLifeEventSimulator ? 'demo' : 'live',
  } as const;
}
