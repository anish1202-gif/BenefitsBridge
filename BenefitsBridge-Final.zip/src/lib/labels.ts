import type {
  ApplicationStatus,
  BenefitCategory,
  EmploymentStatus,
  ImpactLevel,
  IncomeRange,
  InsuranceStatus,
  MatchStatus,
  StudentStatus,
  SupportNeed,
} from '../types';

export const CATEGORY_LABEL: Record<BenefitCategory, string> = {
  healthcare: 'Healthcare coverage',
  financial: 'Financial assistance',
  transportation: 'Transportation',
  employment: 'Employment support',
  assistive_tech: 'Assistive technology',
  housing: 'Housing',
  education: 'Education support',
};
export const CATEGORIES = Object.keys(CATEGORY_LABEL) as BenefitCategory[];

export const MATCH_LABEL: Record<MatchStatus, string> = {
  potential_match: 'Potential Match',
  more_info_needed: 'More Information Needed',
  not_matched: 'Not Currently Matched',
};

export const APP_STATUS_ORDER: ApplicationStatus[] = ['not_started', 'gathering_documents', 'ready_to_apply', 'submitted', 'awaiting_decision'];
export const APP_STATUS_LABEL: Record<ApplicationStatus, string> = {
  not_started: 'Not Started',
  gathering_documents: 'Gathering Documents',
  ready_to_apply: 'Ready to Apply',
  submitted: 'Submitted',
  awaiting_decision: 'Awaiting Decision',
};

export const EMPLOYMENT_LABEL: Record<EmploymentStatus, string> = {
  not_employed: 'Not currently employed',
  part_time: 'Working part-time',
  full_time: 'Working full-time',
  self_employed: 'Self-employed',
  unable_to_work: 'Not able to work right now',
};
export const STUDENT_LABEL: Record<StudentStatus, string> = {
  not_student: 'Not a student',
  part_time: 'Part-time student',
  full_time: 'Full-time student',
};
export const INCOME_LABEL: Record<IncomeRange, string> = {
  none: 'No earned income',
  under_1000: 'Under $1,000 / month',
  '1000_2000': '$1,000 – $2,000 / month',
  '2000_3500': '$2,000 – $3,500 / month',
  over_3500: 'Over $3,500 / month',
};
export const INSURANCE_LABEL: Record<InsuranceStatus, string> = {
  none: 'No health coverage',
  medicaid: 'Medicaid',
  medicare: 'Medicare',
  employer: 'Employer plan',
  marketplace: 'Marketplace plan',
  parent_plan: 'On a parent’s plan',
  unsure: 'Not sure',
};
export const SUPPORT_LABEL: Record<SupportNeed, string> = {
  mobility: 'Mobility (e.g. wheelchair, walker)',
  vision: 'Vision',
  hearing: 'Hearing',
  communication: 'Speech or communication',
  learning_cognitive: 'Learning, memory or attention',
  ongoing_care: 'Ongoing medical care',
  mental_health_support: 'Mental health support',
};
export const IMPACT_LABEL: Record<ImpactLevel, string> = {
  review: 'Review Needed',
  needs_verification: 'Needs Verification',
  no_link_identified: 'No Direct Link Found',
};

export const US_STATES: [string, string][] = [
  ['AL', 'Alabama'], ['AK', 'Alaska'], ['AZ', 'Arizona'], ['AR', 'Arkansas'], ['CA', 'California'], ['CO', 'Colorado'],
  ['CT', 'Connecticut'], ['DE', 'Delaware'], ['DC', 'District of Columbia'], ['FL', 'Florida'], ['GA', 'Georgia'],
  ['HI', 'Hawaii'], ['ID', 'Idaho'], ['IL', 'Illinois'], ['IN', 'Indiana'], ['IA', 'Iowa'], ['KS', 'Kansas'],
  ['KY', 'Kentucky'], ['LA', 'Louisiana'], ['ME', 'Maine'], ['MD', 'Maryland'], ['MA', 'Massachusetts'],
  ['MI', 'Michigan'], ['MN', 'Minnesota'], ['MS', 'Mississippi'], ['MO', 'Missouri'], ['MT', 'Montana'],
  ['NE', 'Nebraska'], ['NV', 'Nevada'], ['NH', 'New Hampshire'], ['NJ', 'New Jersey'], ['NM', 'New Mexico'],
  ['NY', 'New York'], ['NC', 'North Carolina'], ['ND', 'North Dakota'], ['OH', 'Ohio'], ['OK', 'Oklahoma'],
  ['OR', 'Oregon'], ['PA', 'Pennsylvania'], ['RI', 'Rhode Island'], ['SC', 'South Carolina'], ['SD', 'South Dakota'],
  ['TN', 'Tennessee'], ['TX', 'Texas'], ['UT', 'Utah'], ['VT', 'Vermont'], ['VA', 'Virginia'], ['WA', 'Washington'],
  ['WV', 'West Virginia'], ['WI', 'Wisconsin'], ['WY', 'Wyoming'],
];
export const stateName = (code?: string) => US_STATES.find(([c]) => c === code)?.[1] ?? code ?? '';
