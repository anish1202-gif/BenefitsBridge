/** Minimal hash router — no dependencies, works on any static host. */
import { useEffect, useState, type AnchorHTMLAttributes } from 'react';

const read = () => (window.location.hash.replace(/^#/, '') || '/').split('?')[0];

export function useRoute(): string {
  const [path, setPath] = useState(read);
  useEffect(() => {
    const on = () => setPath(read());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return path;
}

export function navigate(path: string) {
  if (read() === path) return;
  window.location.hash = path;
}

export function Link({ to, ...rest }: AnchorHTMLAttributes<HTMLAnchorElement> & { to: string }) {
  return <a href={`#${to}`} {...rest} />;
}

/** Read a query parameter from the hash, e.g. #/app/applications?focus=abc */
export function useQueryParam(name: string): string | null {
  const [v, setV] = useState(() => new URLSearchParams(window.location.hash.split('?')[1] ?? '').get(name));
  useEffect(() => {
    const on = () => setV(new URLSearchParams(window.location.hash.split('?')[1] ?? '').get(name));
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, [name]);
  return v;
}
