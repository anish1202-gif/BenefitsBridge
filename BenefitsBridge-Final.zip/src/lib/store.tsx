/**
 * Lightweight client-side state (React context + reducer).
 *
 * Privacy: app data lives in sessionStorage, so it survives a refresh but is
 * cleared when the tab closes. Only display preferences use localStorage.
 * Nothing is sent to a server.
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, useState, type ReactNode } from 'react';
import type { Application, ApplicationStatus, DisplayPrefs, EquipmentProgress, MatchResponse, MatchResult, Profile, Task } from '../types';
import { DEMO_PROFILE, demoSeed } from './demoProfile';
import { EMPTY_EQUIPMENT } from './equipment';
import { uid } from './dates';
import { matchBenefits } from './integration';
import { getProgram } from './programs';

export interface AppState {
  profile: Profile | null;
  saved: string[];
  applications: Application[];
  tasks: Task[];
  equipment: EquipmentProgress;
}

type Action =
  | { type: 'setProfile'; profile: Profile }
  | { type: 'loadDemo' }
  | { type: 'reset' }
  | { type: 'toggleSave'; programId: string }
  | { type: 'startApplication'; programId: string }
  | { type: 'updateApplication'; id: string; patch: Partial<Application> }
  | { type: 'setAppStatus'; id: string; status: ApplicationStatus }
  | { type: 'toggleDoc'; appId: string; docId: string }
  | { type: 'addDoc'; appId: string; label: string }
  | { type: 'removeDoc'; appId: string; docId: string }
  | { type: 'removeApplication'; id: string }
  | { type: 'addTask'; task: Omit<Task, 'id' | 'createdAt' | 'done'> & { id?: string; done?: boolean } }
  | { type: 'toggleTask'; id: string }
  | { type: 'updateTask'; id: string; patch: Partial<Task> }
  | { type: 'deleteTask'; id: string }
  | { type: 'setEquipment'; patch: Partial<EquipmentProgress> }
  | { type: 'toggleEquipmentStep'; id: string };

const EMPTY: AppState = { profile: null, saved: [], applications: [], tasks: [], equipment: { ...EMPTY_EQUIPMENT } };

function normalize(raw: AppState | null): AppState {
  if (!raw) return { ...EMPTY, equipment: { ...EMPTY_EQUIPMENT } };
  return {
    profile: raw.profile ?? null,
    saved: raw.saved ?? [],
    applications: raw.applications ?? [],
    tasks: raw.tasks ?? [],
    equipment: { ...EMPTY_EQUIPMENT, ...(raw.equipment ?? {}), completedStepIds: raw.equipment?.completedStepIds ?? [] },
  };
}

const touch = (a: Application): Application => ({ ...a, updatedAt: new Date().toISOString() });

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'setProfile':
      return { ...state, profile: action.profile };
    case 'loadDemo':
      return { profile: { ...DEMO_PROFILE }, ...demoSeed() };
    case 'reset':
      return EMPTY;
    case 'toggleSave': {
      const has = state.saved.includes(action.programId);
      return { ...state, saved: has ? state.saved.filter((id) => id !== action.programId) : [...state.saved, action.programId] };
    }
    case 'startApplication': {
      if (state.applications.some((a) => a.programId === action.programId)) return state;
      const program = getProgram(action.programId);
      const app: Application = {
        id: uid('app'),
        programId: action.programId,
        status: 'not_started',
        documents: (program?.documents ?? []).map((label) => ({ id: uid('doc'), label, done: false })),
        updatedAt: new Date().toISOString(),
      };
      const saved = state.saved.includes(action.programId) ? state.saved : [...state.saved, action.programId];
      return { ...state, saved, applications: [...state.applications, app] };
    }
    case 'updateApplication':
      return { ...state, applications: state.applications.map((a) => (a.id === action.id ? touch({ ...a, ...action.patch }) : a)) };
    case 'setAppStatus':
      return { ...state, applications: state.applications.map((a) => (a.id === action.id ? touch({ ...a, status: action.status }) : a)) };
    case 'toggleDoc':
      return {
        ...state,
        applications: state.applications.map((a) =>
          a.id === action.appId ? touch({ ...a, documents: a.documents.map((d) => (d.id === action.docId ? { ...d, done: !d.done } : d)) }) : a,
        ),
      };
    case 'addDoc':
      return {
        ...state,
        applications: state.applications.map((a) =>
          a.id === action.appId ? touch({ ...a, documents: [...a.documents, { id: uid('doc'), label: action.label, done: false }] }) : a,
        ),
      };
    case 'removeDoc':
      return {
        ...state,
        applications: state.applications.map((a) => (a.id === action.appId ? touch({ ...a, documents: a.documents.filter((d) => d.id !== action.docId) }) : a)),
      };
    case 'removeApplication':
      return { ...state, applications: state.applications.filter((a) => a.id !== action.id) };
    case 'addTask':
      return {
        ...state,
        tasks: [...state.tasks, { ...action.task, id: action.task.id ?? uid('task'), done: action.task.done ?? false, createdAt: new Date().toISOString() }],
      };
    case 'toggleTask':
      return { ...state, tasks: state.tasks.map((t) => (t.id === action.id ? { ...t, done: !t.done } : t)) };
    case 'updateTask':
      return { ...state, tasks: state.tasks.map((t) => (t.id === action.id ? { ...t, ...action.patch } : t)) };
    case 'deleteTask':
      return { ...state, tasks: state.tasks.filter((t) => t.id !== action.id) };
    case 'setEquipment':
      return { ...state, equipment: { ...state.equipment, ...action.patch } };
    case 'toggleEquipmentStep': {
      const has = state.equipment.completedStepIds.includes(action.id);
      return {
        ...state,
        equipment: {
          ...state.equipment,
          completedStepIds: has ? state.equipment.completedStepIds.filter((id) => id !== action.id) : [...state.equipment.completedStepIds, action.id],
        },
      };
    }
  }
}

// ───────────────── storage helpers ─────────────────
const SESSION_KEY = 'bb.session.v1';
const PREFS_KEY = 'bb.prefs.v1';

function readJSON<T>(storage: () => Storage, key: string): T | null {
  try {
    const raw = storage().getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}
function writeJSON(storage: () => Storage, key: string, value: unknown) {
  try {
    storage().setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable — keep working in memory */
  }
}

// ───────────────── contexts ─────────────────
interface StoreValue {
  state: AppState;
  dispatch: React.Dispatch<Action>;
  prefs: DisplayPrefs;
  setPrefs: (patch: Partial<DisplayPrefs>) => void;
}
const StoreCtx = createContext<StoreValue | null>(null);

export type MatchState =
  | { status: 'idle' }
  | { status: 'loading'; previous?: MatchResponse }
  | { status: 'ready'; data: MatchResponse }
  | { status: 'error'; message: string };

interface MatchValue {
  match: MatchState;
  byProgram: Map<string, MatchResult>;
  retry: () => void;
}
const MatchCtx = createContext<MatchValue | null>(null);

const DEFAULT_PREFS: DisplayPrefs = { textSize: 'default', simplified: false, reduceMotion: false };

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, EMPTY, () => normalize(readJSON<AppState>(() => sessionStorage, SESSION_KEY)));
  const [prefs, setPrefsState] = useState<DisplayPrefs>(() => ({ ...DEFAULT_PREFS, ...(readJSON<DisplayPrefs>(() => localStorage, PREFS_KEY) ?? {}) }));

  useEffect(() => writeJSON(() => sessionStorage, SESSION_KEY, state), [state]);
  useEffect(() => {
    writeJSON(() => localStorage, PREFS_KEY, prefs);
    const root = document.documentElement;
    root.dataset.textSize = prefs.textSize;
    root.dataset.simplified = String(prefs.simplified);
    root.dataset.reduceMotion = String(prefs.reduceMotion);
  }, [prefs]);

  const setPrefs = useCallback((patch: Partial<DisplayPrefs>) => setPrefsState((p) => ({ ...p, ...patch })), []);

  // Matching — re-run whenever the profile changes.
  const [match, setMatch] = useState<MatchState>({ status: 'idle' });
  const [attempt, setAttempt] = useState(0);
  const lastGood = useRef<MatchResponse | undefined>();
  useEffect(() => {
    if (!state.profile) {
      setMatch({ status: 'idle' });
      return;
    }
    let cancelled = false;
    setMatch({ status: 'loading', previous: lastGood.current });
    matchBenefits(state.profile)
      .then((data) => {
        if (cancelled) return;
        lastGood.current = data;
        setMatch({ status: 'ready', data });
      })
      .catch((err: unknown) => {
        if (!cancelled) setMatch({ status: 'error', message: err instanceof Error ? err.message : 'The matching service did not respond.' });
      });
    return () => {
      cancelled = true;
    };
  }, [state.profile, attempt]);

  const byProgram = useMemo(() => {
    const data = match.status === 'ready' ? match.data : match.status === 'loading' ? match.previous : undefined;
    return new Map((data?.results ?? []).map((r) => [r.programId, r]));
  }, [match]);

  const matchValue = useMemo(() => ({ match, byProgram, retry: () => setAttempt((n) => n + 1) }), [match, byProgram]);
  const storeValue = useMemo(() => ({ state, dispatch, prefs, setPrefs }), [state, prefs, setPrefs]);

  return (
    <StoreCtx.Provider value={storeValue}>
      <MatchCtx.Provider value={matchValue}>{children}</MatchCtx.Provider>
    </StoreCtx.Provider>
  );
}

export function useStore() {
  const v = useContext(StoreCtx);
  if (!v) throw new Error('useStore must be used inside StoreProvider');
  return v;
}

export function useMatches() {
  const v = useContext(MatchCtx);
  if (!v) throw new Error('useMatches must be used inside StoreProvider');
  return v;
}
