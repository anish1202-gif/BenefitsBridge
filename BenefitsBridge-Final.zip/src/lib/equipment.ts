import type { EquipmentProgress } from '../types';

/** Administrative steps for obtaining assistive equipment. The user checks these off. */
export const EQUIPMENT_STEPS = [
  {
    id: 'pathways',
    title: 'Identify pathways to verify',
    detail: 'Coverage, a device loan or reuse program, and employment-related assistive technology are different routes. None of them is an approval.',
  },
  {
    id: 'documentation',
    title: 'Ask what documentation to verify',
    detail: 'Many requests ask for a prescription or a clinician’s letter. Confirm the exact documents with the program.',
  },
  {
    id: 'authorization',
    title: 'Ask whether authorization is required',
    detail: 'Some payers require authorization before a supplier is paid. Whether that applies has to be confirmed with the payer.',
  },
  {
    id: 'funding',
    title: 'Record whether funding information is confirmed',
    detail: 'Mark this only after you have checked with the program or payer. BenefitsBridge cannot confirm coverage.',
  },
  {
    id: 'supplier',
    title: 'Record a supplier or reuse program you contacted',
    detail: 'Write down a name only after you have contacted them. This app does not list inventory or place orders.',
  },
] as const;

export const EQUIPMENT_PATHWAY_IDS = ['ga-medicaid-abd', 'tools-for-life', 'gvra-vr'] as const;

export const EMPTY_EQUIPMENT: EquipmentProgress = {
  fundingStatus: 'not_recorded',
  supplierStatus: 'not_recorded',
  supplierNote: '',
  completedStepIds: [],
};
