/**
 * Fictional demo data for "Jordan". Not a real person.
 * Dates are generated relative to today so the demo always has upcoming items.
 * These are sample, user-entered dates — not official program deadlines.
 */
import type { Application, EquipmentProgress, Profile, Task } from '../types';
import { addDays } from './dates';

export const DEMO_PROFILE: Profile = {
  firstName: 'Jordan',
  state: 'GA',
  age: 19,
  employment: 'not_employed',
  student: 'full_time',
  monthlyIncome: 'none',
  insurance: 'none',
  supportNeeds: ['mobility'],
  assistanceSought: ['healthcare', 'transportation', 'employment'],
  isDemo: true,
};

export function demoSeed(): { saved: string[]; applications: Application[]; tasks: Task[]; equipment: EquipmentProgress } {
  const now = new Date().toISOString();
  return {
    saved: ['ga-medicaid-abd', 'gvra-vr'],
    applications: [
      {
        id: 'app_medicaid',
        programId: 'ga-medicaid-abd',
        status: 'gathering_documents',
        documents: [
          { id: 'd1', label: 'Photo ID', done: true },
          { id: 'd2', label: 'Proof of Georgia address', done: true },
          { id: 'd3', label: 'Statement of no earned income', done: false },
          { id: 'd4', label: 'Bank statements', done: false },
          { id: 'd5', label: 'Disability determination letter (if any)', done: false },
        ],
        updatedAt: now,
      },
      {
        id: 'app_gvra',
        programId: 'gvra-vr',
        status: 'not_started',
        documents: [
          { id: 'g1', label: 'Photo ID', done: true },
          { id: 'g2', label: 'College transcript', done: false },
          { id: 'g3', label: 'Disability documentation I already have', done: false },
        ],
        updatedAt: now,
      },
    ],
    tasks: [
      { id: 't1', title: 'Check Georgia Medicaid eligibility requirements', programId: 'ga-medicaid-abd', dueDate: addDays(2), done: false, priority: 'high', source: 'suggested', createdAt: now },
      { id: 't2', title: 'Gather documents for vocational rehabilitation', programId: 'gvra-vr', dueDate: addDays(6), done: false, priority: 'high', source: 'suggested', createdAt: now },
      { id: 't3', title: 'Explore transportation assistance', programId: 'marta-mobility', dueDate: addDays(9), done: false, priority: 'normal', source: 'suggested', createdAt: now },
      { id: 't4', title: 'Request bank statements for the last 3 months', programId: 'ga-medicaid-abd', dueDate: addDays(13), done: false, priority: 'normal', source: 'user', createdAt: now },
      { id: 't5', title: 'Register with campus disability services', programId: 'campus-disability-services', done: true, priority: 'normal', source: 'user', createdAt: now },
    ],
    equipment: {
      fundingStatus: 'still_verifying',
      supplierStatus: 'not_yet',
      supplierNote: '',
      completedStepIds: ['pathways'],
    },
  };
}
