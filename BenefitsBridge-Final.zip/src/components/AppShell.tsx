import { useState, type ReactNode } from 'react';
import { Accessibility, Bookmark, Compass, FolderKanban, GitCompareArrows, LayoutDashboard, ListChecks, Menu, Settings } from 'lucide-react';
import { Link } from '../lib/router';
import { useStore } from '../lib/store';
import { stateName } from '../lib/labels';
import { daysUntil } from '../lib/dates';
import { Logo } from './Primitives';
import { Dialog } from './Dialog';
import { cx } from './cx';

export const NAV = [
  { key: 'overview', label: 'Overview', short: 'Overview', icon: LayoutDashboard },
  { key: 'discover', label: 'Discover Benefits', short: 'Discover', icon: Compass },
  { key: 'benefits', label: 'My Benefits', short: 'Saved', icon: Bookmark },
  { key: 'applications', label: 'Applications', short: 'Applications', icon: FolderKanban },
  { key: 'equipment', label: 'Equipment Access', short: 'Equipment', icon: Accessibility },
  { key: 'simulator', label: 'Life Simulator', short: 'Simulator', icon: GitCompareArrows },
  { key: 'tasks', label: 'Tasks & Deadlines', short: 'Tasks', icon: ListChecks },
  { key: 'settings', label: 'Settings', short: 'Settings', icon: Settings },
] as const;

const MOBILE_PRIMARY = ['overview', 'discover', 'tasks', 'simulator'];

export function AppShell({ section, children }: { section: string; children: ReactNode }) {
  const { state } = useStore();
  const [moreOpen, setMoreOpen] = useState(false);
  const p = state.profile;
  const openTasks = state.tasks.filter((t) => !t.done);
  const dueSoon = openTasks.filter((t) => t.dueDate && daysUntil(t.dueDate) <= 7).length;

  const counts: Record<string, number | undefined> = {
    benefits: state.saved.length || undefined,
    applications: state.applications.length || undefined,
    tasks: openTasks.length || undefined,
  };

  return (
    <div className="min-h-screen lg:pl-[264px]">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-md focus:bg-white focus:px-4 focus:py-2 focus:shadow-raised">
        Skip to main content
      </a>

      {/* Desktop sidebar */}
      <aside className="on-dark fixed inset-y-0 left-0 z-30 hidden w-[264px] flex-col bg-night text-slate-300 lg:flex">
        <div className="px-5 pb-6 pt-5">
          <Link to="/" aria-label="BenefitsBridge home" className="inline-block rounded-md">
            <Logo dark />
          </Link>
        </div>
        <nav aria-label="Main" className="flex-1 overflow-y-auto px-3">
          <ul className="space-y-0.5">
            {NAV.filter((n) => n.key !== 'settings').map((n) => {
              const active = section === n.key;
              return (
                <li key={n.key}>
                  <Link
                    to={`/app/${n.key}`}
                    aria-current={active ? 'page' : undefined}
                    className={cx(
                      'group flex h-10 items-center gap-3 rounded-md px-3 text-[0.9375rem] transition-colors',
                      active ? 'bg-white/[0.08] text-white font-medium' : 'hover:bg-white/[0.05] hover:text-white',
                    )}
                  >
                    <n.icon aria-hidden className={cx('h-[18px] w-[18px]', active ? 'text-brand-ring' : 'text-slate-400 group-hover:text-slate-200')} />
                    <span className="flex-1">{n.label}</span>
                    {counts[n.key] !== undefined && (
                      <span className="tnum text-xs text-slate-400">
                        {counts[n.key]}
                        <span className="sr-only"> items</span>
                      </span>
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>

          {dueSoon > 0 && (
            <div className="mx-1 mt-6 rounded-md border border-white/10 px-3 py-3 text-sm">
              <p className="font-medium text-white tnum">{dueSoon} due this week</p>
              <Link to="/app/tasks" className="mt-1 inline-block text-brand-ring underline-offset-2 hover:underline">
                Review deadlines
              </Link>
            </div>
          )}
        </nav>

        <div className="border-t border-white/10 p-3">
          <Link
            to="/app/settings"
            aria-current={section === 'settings' ? 'page' : undefined}
            className={cx('flex items-center gap-3 rounded-md px-2 py-2 transition-colors hover:bg-white/[0.05]', section === 'settings' && 'bg-white/[0.08]')}
          >
            <span aria-hidden className="flex h-9 w-9 items-center justify-center rounded-full bg-night-3 text-sm font-semibold text-white">
              {(p?.firstName ?? 'Y').slice(0, 1).toUpperCase()}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm font-medium text-white">{p?.firstName ?? 'Your profile'}</span>
              <span className="block truncate text-xs text-slate-400">
                {p?.state ? stateName(p.state) : 'No state set'}
                {p?.isDemo ? ' · Demo profile' : ''}
              </span>
            </span>
            <Settings aria-hidden className="h-4 w-4 text-slate-400" />
            <span className="sr-only">Settings</span>
          </Link>
        </div>
      </aside>

      {/* Mobile / tablet top bar */}
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-line bg-white/95 px-4 backdrop-blur lg:hidden">
        <Link to="/app/overview" aria-label="BenefitsBridge overview" className="rounded-md">
          <Logo />
        </Link>
        {p?.isDemo && <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-700">Demo profile</span>}
      </header>

      <main id="main" className="mx-auto w-full max-w-[1240px] px-4 pb-28 pt-6 sm:px-6 md:pt-8 lg:px-10 lg:pb-16 lg:pt-10">
        {children}
      </main>

      {/* Mobile bottom navigation */}
      <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white pb-[env(safe-area-inset-bottom)] lg:hidden">
        <ul className="grid grid-cols-5">
          {NAV.filter((n) => MOBILE_PRIMARY.includes(n.key)).map((n) => {
            const active = section === n.key;
            return (
              <li key={n.key}>
                <Link
                  to={`/app/${n.key}`}
                  aria-current={active ? 'page' : undefined}
                  className={cx('flex h-16 flex-col items-center justify-center gap-1 text-[0.6875rem] font-medium', active ? 'text-brand' : 'text-slate-600')}
                >
                  <n.icon aria-hidden className="h-5 w-5" />
                  {n.short}
                </Link>
              </li>
            );
          })}
          <li>
            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              aria-haspopup="dialog"
              className={cx(
                'flex h-16 w-full flex-col items-center justify-center gap-1 text-[0.6875rem] font-medium',
                !MOBILE_PRIMARY.includes(section) ? 'text-brand' : 'text-slate-600',
              )}
            >
              <Menu aria-hidden className="h-5 w-5" />
              More
            </button>
          </li>
        </ul>
      </nav>

      <Dialog open={moreOpen} onClose={() => setMoreOpen(false)} title="More" size="sm">
        <ul className="-mx-2 -my-2">
          {NAV.filter((n) => !MOBILE_PRIMARY.includes(n.key)).map((n) => (
            <li key={n.key}>
              <Link
                to={`/app/${n.key}`}
                onClick={() => setMoreOpen(false)}
                aria-current={section === n.key ? 'page' : undefined}
                className="flex h-12 items-center gap-3 rounded-md px-3 text-base hover:bg-slate-50 aria-[current=page]:font-semibold aria-[current=page]:text-brand"
              >
                <n.icon aria-hidden className="h-5 w-5 text-slate-500" />
                <span className="flex-1">{n.label}</span>
                {counts[n.key] !== undefined && <span className="tnum text-sm text-muted">{counts[n.key]}</span>}
              </Link>
            </li>
          ))}
        </ul>
      </Dialog>
    </div>
  );
}
