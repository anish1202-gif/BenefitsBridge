import { CircleCheck, CircleDashed, CircleHelp, CircleMinus, Search, Link2Off, TriangleAlert } from 'lucide-react';
import type { ApplicationStatus, ImpactLevel, MatchStatus } from '../types';
import { APP_STATUS_LABEL, IMPACT_LABEL, MATCH_LABEL } from '../lib/labels';
import { cx } from './cx';

const pill = 'badge inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.8125rem] font-medium leading-none whitespace-nowrap';

/** Match status always pairs color with an icon and text — never color alone. */
export function MatchBadge({ status, className }: { status: MatchStatus; className?: string }) {
  const styles: Record<MatchStatus, [string, JSX.Element]> = {
    potential_match: ['bg-positive-soft text-positive-ink', <CircleCheck key="i" aria-hidden className="h-3.5 w-3.5" />],
    more_info_needed: ['bg-caution-soft text-caution-ink', <CircleHelp key="i" aria-hidden className="h-3.5 w-3.5" />],
    not_matched: ['bg-slate-100 text-slate-600', <CircleMinus key="i" aria-hidden className="h-3.5 w-3.5" />],
  };
  const [c, icon] = styles[status];
  return (
    <span className={cx(pill, c, className)}>
      {icon}
      {MATCH_LABEL[status]}
    </span>
  );
}

export function AppStatusBadge({ status }: { status: ApplicationStatus }) {
  const done = status === 'submitted' || status === 'awaiting_decision';
  return (
    <span className={cx(pill, done ? 'bg-brand-soft text-brand' : 'bg-slate-100 text-slate-700')}>
      {done ? <CircleCheck aria-hidden className="h-3.5 w-3.5" /> : <CircleDashed aria-hidden className="h-3.5 w-3.5" />}
      {APP_STATUS_LABEL[status]}
    </span>
  );
}

export function ImpactBadge({ impact }: { impact: ImpactLevel }) {
  const map: Record<ImpactLevel, [string, JSX.Element]> = {
    review: ['bg-brand-soft text-brand', <Search key="i" aria-hidden className="h-3.5 w-3.5" />],
    needs_verification: ['bg-caution-soft text-caution-ink', <TriangleAlert key="i" aria-hidden className="h-3.5 w-3.5" />],
    no_link_identified: ['bg-slate-100 text-slate-600', <Link2Off key="i" aria-hidden className="h-3.5 w-3.5" />],
  };
  const [c, icon] = map[impact];
  return (
    <span className={cx(pill, c)}>
      {icon}
      {IMPACT_LABEL[impact]}
    </span>
  );
}

export function Tag({ children, className }: { children: React.ReactNode; className?: string }) {
  return <span className={cx('inline-flex items-center rounded px-1.5 py-0.5 text-xs font-medium text-muted bg-slate-100', className)}>{children}</span>;
}
