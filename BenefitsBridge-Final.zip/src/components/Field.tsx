import { useId, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes } from 'react';
import { Check, CircleAlert } from 'lucide-react';
import { cx } from './cx';

const control =
  'block w-full h-11 rounded-md border bg-white px-3 text-[0.9375rem] text-ink placeholder:text-slate-400 transition-colors hover:border-slate-300 focus-visible:border-brand';

interface FieldShell {
  label: string;
  hint?: string;
  error?: string;
  optional?: boolean;
}

function Label({ htmlFor, label, optional }: { htmlFor: string; label: string; optional?: boolean }) {
  return (
    <label htmlFor={htmlFor} className="mb-1.5 flex items-baseline gap-2 text-sm font-medium text-ink">
      {label}
      {optional && <span className="text-xs font-normal text-muted">Optional</span>}
    </label>
  );
}

function Messages({ hintId, errorId, hint, error }: { hintId: string; errorId: string; hint?: string; error?: string }) {
  return (
    <>
      {hint && (
        <p id={hintId} className="mt-1.5 text-sm text-muted">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} className="mt-1.5 flex items-center gap-1.5 text-sm font-medium text-danger-ink">
          <CircleAlert aria-hidden className="h-4 w-4 shrink-0" />
          {error}
        </p>
      )}
    </>
  );
}

export function TextField({ label, hint, error, optional, className, id, ...rest }: FieldShell & InputHTMLAttributes<HTMLInputElement>) {
  const auto = useId();
  const fid = id ?? auto;
  const hintId = `${fid}-hint`;
  const errorId = `${fid}-error`;
  return (
    <div className={className}>
      <Label htmlFor={fid} label={label} optional={optional} />
      <input
        id={fid}
        className={cx(control, error ? 'border-danger-ink' : 'border-line')}
        aria-invalid={error ? true : undefined}
        aria-describedby={[hint && hintId, error && errorId].filter(Boolean).join(' ') || undefined}
        {...rest}
      />
      <Messages hintId={hintId} errorId={errorId} hint={hint} error={error} />
    </div>
  );
}

export function SelectField({
  label,
  hint,
  error,
  optional,
  className,
  id,
  children,
  ...rest
}: FieldShell & SelectHTMLAttributes<HTMLSelectElement> & { children: ReactNode }) {
  const auto = useId();
  const fid = id ?? auto;
  const hintId = `${fid}-hint`;
  const errorId = `${fid}-error`;
  return (
    <div className={className}>
      <Label htmlFor={fid} label={label} optional={optional} />
      <select
        id={fid}
        className={cx(control, 'appearance-none bg-[length:16px] bg-[right_12px_center] bg-no-repeat pr-10', error ? 'border-danger-ink' : 'border-line')}
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2364748B' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")",
        }}
        aria-invalid={error ? true : undefined}
        aria-describedby={[hint && hintId, error && errorId].filter(Boolean).join(' ') || undefined}
        {...rest}
      >
        {children}
      </select>
      <Messages hintId={hintId} errorId={errorId} hint={hint} error={error} />
    </div>
  );
}

interface ChoiceOption<T extends string> {
  value: T;
  label: string;
  description?: string;
}

/** Radio group rendered as large selectable rows. Native radios → arrow-key navigation for free. */
export function ChoiceGroup<T extends string>({
  legend,
  hint,
  name,
  options,
  value,
  onChange,
  columns = 1,
}: {
  legend: string;
  hint?: string;
  name: string;
  options: ChoiceOption<T>[];
  value?: T;
  onChange: (v: T) => void;
  columns?: 1 | 2;
}) {
  const hid = useId();
  return (
    <fieldset aria-describedby={hint ? hid : undefined}>
      <legend className="mb-1.5 text-sm font-medium text-ink">{legend}</legend>
      {hint && (
        <p id={hid} className="mb-3 text-sm text-muted">
          {hint}
        </p>
      )}
      <div className={cx('grid gap-2', columns === 2 && 'sm:grid-cols-2')}>
        {options.map((o) => {
          const checked = value === o.value;
          return (
            <label
              key={o.value}
              className={cx(
                'group relative flex min-h-[3rem] cursor-pointer items-center gap-3 rounded-md border bg-white px-3.5 py-2.5 transition-colors has-[:focus-visible]:outline has-[:focus-visible]:outline-[3px] has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-brand',
                checked ? 'border-brand bg-brand-soft/60' : 'border-line hover:border-slate-300',
              )}
            >
              <input type="radio" name={name} value={o.value} checked={checked} onChange={() => onChange(o.value)} className="peer sr-only" />
              <span
                aria-hidden
                className={cx('flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full border-2', checked ? 'border-brand' : 'border-slate-300')}
              >
                {checked && <span className="h-2 w-2 rounded-full bg-brand" />}
              </span>
              <span className="min-w-0">
                <span className="block text-[0.9375rem] font-medium">{o.label}</span>
                {o.description && <span className="block text-sm text-muted">{o.description}</span>}
              </span>
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}

export function CheckGroup<T extends string>({
  legend,
  hint,
  options,
  values,
  onChange,
  columns = 2,
}: {
  legend: string;
  hint?: string;
  options: ChoiceOption<T>[];
  values: T[];
  onChange: (v: T[]) => void;
  columns?: 1 | 2;
}) {
  const hid = useId();
  return (
    <fieldset aria-describedby={hint ? hid : undefined}>
      <legend className="mb-1.5 text-sm font-medium text-ink">{legend}</legend>
      {hint && (
        <p id={hid} className="mb-3 text-sm text-muted">
          {hint}
        </p>
      )}
      <div className={cx('grid gap-2', columns === 2 && 'sm:grid-cols-2')}>
        {options.map((o) => {
          const checked = values.includes(o.value);
          return (
            <label
              key={o.value}
              className={cx(
                'flex min-h-[3rem] cursor-pointer items-center gap-3 rounded-md border bg-white px-3.5 py-2.5 transition-colors has-[:focus-visible]:outline has-[:focus-visible]:outline-[3px] has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-brand',
                checked ? 'border-brand bg-brand-soft/60' : 'border-line hover:border-slate-300',
              )}
            >
              <input
                type="checkbox"
                className="sr-only"
                checked={checked}
                onChange={() => onChange(checked ? values.filter((v) => v !== o.value) : [...values, o.value])}
              />
              <span aria-hidden className={cx('flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded border-2', checked ? 'border-brand bg-brand' : 'border-slate-300')}>
                {checked && <Check className="h-3 w-3 text-white" strokeWidth={3} />}
              </span>
              <span className="text-[0.9375rem] font-medium">{o.label}</span>
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}

/** Accessible on/off switch built on a native checkbox. */
export function Switch({ label, description, checked, onChange }: { label: string; description?: string; checked: boolean; onChange: (v: boolean) => void }) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-6 py-4">
      <div>
        <label htmlFor={id} className="block text-[0.9375rem] font-medium">
          {label}
        </label>
        {description && (
          <p id={`${id}-d`} className="mt-0.5 text-sm text-muted">
            {description}
          </p>
        )}
      </div>
      <span className="relative mt-0.5 inline-flex shrink-0">
        <input
          id={id}
          type="checkbox"
          role="switch"
          checked={checked}
          aria-describedby={description ? `${id}-d` : undefined}
          onChange={(e) => onChange(e.target.checked)}
          className="peer h-7 w-12 cursor-pointer appearance-none rounded-full bg-slate-300 transition-colors checked:bg-brand"
        />
        <span aria-hidden className="pointer-events-none absolute left-1 top-1 h-5 w-5 rounded-full bg-white shadow transition-transform peer-checked:translate-x-5" />
      </span>
    </div>
  );
}
