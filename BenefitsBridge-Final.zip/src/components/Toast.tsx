import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react';
import { CircleCheck, X } from 'lucide-react';

interface ToastItem {
  id: number;
  message: string;
  action?: { label: string; onClick: () => void };
}

const Ctx = createContext<(message: string, action?: ToastItem['action']) => void>(() => {});

/**
 * Notifications are announced through a polite live region and stay on screen
 * long enough to read (8s), with a dismiss button.
 */
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const n = useRef(0);

  const dismiss = useCallback((id: number) => setItems((xs) => xs.filter((x) => x.id !== id)), []);
  const notify = useCallback(
    (message: string, action?: ToastItem['action']) => {
      const id = ++n.current;
      setItems((xs) => [...xs.slice(-2), { id, message, action }]);
      window.setTimeout(() => dismiss(id), 8000);
    },
    [dismiss],
  );

  return (
    <Ctx.Provider value={notify}>
      {children}
      <div
        role="status"
        aria-live="polite"
        className="pointer-events-none fixed inset-x-0 bottom-20 z-50 flex flex-col items-center gap-2 px-4 lg:bottom-6 lg:items-end lg:pr-6"
      >
        {items.map((t) => (
          <div key={t.id} className="on-dark enter pointer-events-auto flex w-full max-w-sm items-center gap-3 rounded-lg bg-night px-4 py-3 text-sm text-white shadow-raised">
            <CircleCheck aria-hidden className="h-4 w-4 shrink-0 text-emerald-300" />
            <p className="flex-1">{t.message}</p>
            {t.action && (
              <button
                type="button"
                className="rounded px-2 py-1 font-semibold text-brand-ring hover:bg-white/10"
                onClick={() => {
                  t.action!.onClick();
                  dismiss(t.id);
                }}
              >
                {t.action.label}
              </button>
            )}
            <button type="button" aria-label="Dismiss notification" className="rounded p-1 text-slate-400 hover:bg-white/10 hover:text-white" onClick={() => dismiss(t.id)}>
              <X aria-hidden className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export const useToast = () => useContext(Ctx);
