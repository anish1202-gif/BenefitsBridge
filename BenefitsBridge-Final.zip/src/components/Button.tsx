import { forwardRef, type ButtonHTMLAttributes, type AnchorHTMLAttributes, type ReactNode } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { cx } from './cx';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'dark';
type Size = 'sm' | 'md' | 'lg';

const base =
  'inline-flex items-center justify-center gap-2 font-medium whitespace-nowrap rounded-md transition-colors disabled:opacity-50 disabled:pointer-events-none select-none';

const variants: Record<Variant, string> = {
  primary: 'bg-brand text-white hover:bg-brand-hover shadow-[inset_0_1px_0_rgba(255,255,255,0.12)]',
  secondary: 'bg-white text-ink border border-line hover:bg-slate-50 hover:border-slate-300',
  ghost: 'text-ink hover:bg-slate-100',
  danger: 'bg-white text-danger-ink border border-line hover:bg-danger-soft',
  dark: 'bg-night text-white hover:bg-night-2',
};

const sizes: Record<Size, string> = {
  sm: 'h-9 px-3 text-sm',
  md: 'h-11 px-4 text-[0.9375rem]',
  lg: 'h-12 px-5 text-base',
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  icon?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'secondary', size = 'md', icon, className, children, type = 'button', ...rest },
  ref,
) {
  return (
    <button ref={ref} type={type} className={cx(base, variants[variant], sizes[size], className)} {...rest}>
      {icon}
      {children}
    </button>
  );
});

interface LinkButtonProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  variant?: Variant;
  size?: Size;
  icon?: ReactNode;
  external?: boolean;
}

/** Looks like a button, behaves like a link (navigation). */
export function LinkButton({ variant = 'secondary', size = 'md', icon, external, className, children, ...rest }: LinkButtonProps) {
  return (
    <a
      className={cx(base, variants[variant], sizes[size], className)}
      {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
      {...rest}
    >
      {icon}
      {children}
      {external && (
        <>
          <ArrowUpRight aria-hidden className="h-4 w-4 -mr-0.5 opacity-70" />
          <span className="sr-only"> (opens in a new tab)</span>
        </>
      )}
    </a>
  );
}

/** Square icon-only button with a required accessible label. */
export function IconButton({ label, className, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      className={cx('inline-flex h-10 w-10 items-center justify-center rounded-md text-muted hover:bg-slate-100 hover:text-ink transition-colors', className)}
      {...rest}
    >
      {children}
    </button>
  );
}
