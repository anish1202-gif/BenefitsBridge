import { useEffect, useId, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { IconButton } from './Button';
import { cx } from './cx';

/**
 * Accessible modal built on native <dialog>.showModal(): focus is contained,
 * Escape closes it, and the rest of the page becomes inert. Focus returns to
 * the element that opened it.
 */
export function Dialog({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  size = 'md',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'md' | 'sm';
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const opener = useRef<Element | null>(null);
  const tid = useId();
  const did = useId();

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) {
      opener.current = document.activeElement;
      d.showModal();
    } else if (!open && d.open) {
      d.close();
      (opener.current as HTMLElement | null)?.focus?.();
    }
  }, [open]);

  return (
    <dialog
      ref={ref}
      aria-labelledby={tid}
      aria-describedby={description ? did : undefined}
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onClick={(e) => {
        if (e.target === ref.current) onClose(); // backdrop click
      }}
      className={cx(
        'm-auto w-[calc(100%-2rem)] rounded-xl border border-line bg-white p-0 text-ink shadow-raised',
        size === 'md' ? 'max-w-lg' : 'max-w-md',
      )}
    >
      <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4">
        <div>
          <h2 id={tid} className="text-lg font-semibold">
            {title}
          </h2>
          {description && (
            <p id={did} className="mt-0.5 text-sm text-muted">
              {description}
            </p>
          )}
        </div>
        <IconButton label="Close dialog" onClick={onClose} className="-mr-2 -mt-1">
          <X aria-hidden className="h-5 w-5" />
        </IconButton>
      </div>
      <div className="px-5 py-5">{children}</div>
      {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-line bg-canvas px-5 py-3.5 rounded-b-xl">{footer}</div>}
    </dialog>
  );
}
