import { useEffect, useRef, type ReactNode } from 'react';
import { cx } from './cx';
import type { ApplicationStatus } from '../types';
import { APP_STATUS_LABEL, APP_STATUS_ORDER } from '../lib/labels';
import { Check } from 'lucide-react';

/** Page title. Receives focus on navigation so screen readers announce the new page. */
export function PageHeader({ title, eyebrow, description, actions }: { title: string; eyebrow?: string; description?: ReactNode; actions?: ReactNode }) {
  const ref = useRef<HTMLHeadingElement>(null);
  useEffect(() => {
    document.title = `${title} · BenefitsBridge`;
    ref.current?.focus({ preventScroll: true });
  }, [title]);
  return (
    <header className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div className="max-w-2xl">
        {eyebrow && <p className="mb-2 text-sm font-medium text-muted">{eyebrow}</p>}
        <h1 ref={ref} tabIndex={-1} className="text-[1.75rem] font-semibold leading-tight md:text-[2rem] text-balance">
          {title}
        </h1>
        {description && <div className="mt-2 text-base text-muted text-pretty">{description}</div>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </header>
  );
}

/** Bordered surface with optional header row. */
export function Panel({
  title,
  titleAs: H = 'h2',
  description,
  action,
  children,
  className,
  bodyClassName,
  id,
}: {
  title?: ReactNode;
  titleAs?: 'h2' | 'h3';
  description?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
  id?: string;
}) {
  return (
    <section id={id} aria-labelledby={title && id ? `${id}-title` : undefined} className={cx('rounded-lg border border-line bg-white shadow-card', className)}>
      {title && (
        <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4">
          <div>
            <H id={id ? `${id}-title` : undefined} className="text-[1.0625rem] font-semibold">
              {title}
            </H>
            {description && <p className="mt-0.5 text-sm text-muted">{description}</p>}
          </div>
          {action}
        </div>
      )}
      <div className={cx(bodyClassName ?? 'p-5')}>{children}</div>
    </section>
  );
}

export function ProgressBar({ value, max, label, tone = 'brand' }: { value: number; max: number; label: string; tone?: 'brand' | 'positive' }) {
  const pct = max === 0 ? 0 : Math.round((value / max) * 100);
  return (
    <div
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={max}
      aria-valuenow={value}
      aria-valuetext={`${value} of ${max} complete`}
      className="h-2 w-full overflow-hidden rounded-full bg-slate-100"
    >
      <div className={cx('h-full rounded-full transition-[width] duration-500', tone === 'brand' ? 'bg-brand' : 'bg-positive')} style={{ width: `${pct}%` }} />
    </div>
  );
}

/**
 * The "bridge path": five connected application stages.
 * Each stage shows a check (done), a filled node (current) or an empty node,
 * plus text, so the state is never conveyed by color alone.
 */
export function StatusPath({ status, compact }: { status: ApplicationStatus; compact?: boolean }) {
  const idx = APP_STATUS_ORDER.indexOf(status);
  return (
    <ol className="flex w-full items-start" aria-label="Application stages">
      {APP_STATUS_ORDER.map((s, i) => {
        const done = i < idx;
        const current = i === idx;
        return (
          <li key={s} className="relative flex flex-1 flex-col items-center text-center" aria-current={current ? 'step' : undefined}>
            {i > 0 && (
              <span
                aria-hidden
                className={cx('absolute top-[11px] h-[2px]', i <= idx ? 'bg-brand' : 'bg-slate-200')}
                style={{ left: 'calc(-50% + 16px)', right: 'calc(50% + 16px)' }}
              />
            )}
            <span
              aria-hidden
              className={cx(
                'relative z-10 flex h-6 w-6 items-center justify-center rounded-full border-2',
                done ? 'border-brand bg-brand text-white' : 'bg-white',
                current && 'border-brand',
                !done && !current && 'border-slate-300',
              )}
            >
              {done && <Check className="h-3.5 w-3.5" strokeWidth={3} />}
              {current && <span className="h-2.5 w-2.5 rounded-full bg-brand" />}
            </span>
            <span className={cx('mt-2 px-1 text-xs leading-tight', compact && 'hidden sm:block', current ? 'font-semibold text-ink' : 'text-muted')}>
              {APP_STATUS_LABEL[s]}
              <span className="sr-only">{done ? ' — done' : current ? ' — current stage' : ' — not yet'}</span>
            </span>
          </li>
        );
      })}
    </ol>
  );
}

export function EmptyState({ icon, title, children, action }: { icon: ReactNode; title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center rounded-lg border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
      <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-full bg-slate-100 text-slate-600" aria-hidden>
        {icon}
      </div>
      <h3 className="text-base font-semibold">{title}</h3>
      {children && <p className="mt-1 max-w-sm text-sm text-muted">{children}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

/** Persistent, plain-language disclaimer used wherever eligibility is discussed. */
export function Notice({ children, tone = 'neutral', icon }: { children: ReactNode; tone?: 'neutral' | 'caution'; icon?: ReactNode }) {
  return (
    <div className={cx('flex gap-3 rounded-md border px-4 py-3 text-sm', tone === 'caution' ? 'border-caution-line bg-caution-soft/60 text-caution-ink' : 'border-line bg-slate-50 text-slate-700')}>
      {icon && <span className="mt-0.5 shrink-0" aria-hidden>{icon}</span>}
      <div>{children}</div>
    </div>
  );
}

export function Logo({ className, dark }: { className?: string; dark?: boolean }) {
  return (
    <span className={cx('inline-flex items-center gap-2.5', className)}>
      <svg viewBox="0 0 28 28" className="h-7 w-7" aria-hidden>
        <rect width="28" height="28" rx="7" fill={dark ? '#5146E5' : '#111827'} />
        <path d="M6 19.5c2.6-6.2 13.4-6.2 16 0" stroke="#fff" strokeWidth="2.2" fill="none" strokeLinecap="round" />
        <path d="M5 19.5h18" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" />
        <path d="M10 15.6v3.9M14 14.3v5.2M18 15.6v3.9" stroke={dark ? '#C7D2FE' : '#A5B4FC'} strokeWidth="1.6" strokeLinecap="round" />
      </svg>
      <span className={cx('text-[1.0625rem] font-semibold tracking-tight', dark ? 'text-white' : 'text-ink')}>BenefitsBridge</span>
    </span>
  );
}
