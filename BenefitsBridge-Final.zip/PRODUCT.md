# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

The primary user is a person seeking disability benefits and healthcare access for themselves. The reference situation is the fictional demo: a young adult in Georgia, in college, who uses a wheelchair, has no earned income, and is looking for healthcare, transportation, and work support. They need to see what might fit, what is still missing, and what a life change (such as starting a job) might mean before they act.

No caregiver, caseworker, or hackathon-judge audience was confirmed.

## Product Purpose

BenefitsBridge is a command center for the programs that support health and independence: what might fit, what the person is applying to, and what to do next. Success is a person who can move from “what might fit” to a tracked application and a clearer sense of a life change, without being told they are eligible.

## Positioning

The life simulator is the difference. A neighboring benefits site could copy program discovery and a checklist. BenefitsBridge lets the person preview a qualitative before/after of a life change, see which programs are affected, and turn the open questions into tasks. Matching and application tracking exist to support that decision. The product never claims eligibility, official status, dollar outcomes, dates, or probabilities.

## Operating Context

Used alone in a browser. There is no account.

Entry is either a 5-step onboarding (every question skippable, with “Why we ask” on each step) or **Explore the demo as Jordan**. After a profile exists, the working surfaces are Overview, Discover Benefits, program detail, My Benefits, Applications, Life Simulator, Tasks, and Settings.

The person saves a program, tracks an application (which creates a document checklist), creates tasks, runs a life event such as “Start a job,” reviews before/after and what needs verification, and adds those questions as tasks. Overview then shows the new tasks in Next moves and Deadlines.

App data (profile, saved programs, applications, tasks) lives in `sessionStorage` and clears when the tab closes. Display preferences (text size, simplified interface, reduce motion) live in `localStorage`. Nothing is sent to a server.

Program summaries are illustrative and currently Georgia-first. People in other states see national programs, and Georgia-only programs show as not currently matched. Official sites are linked; BenefitsBridge is not connected to any government system. Application stages are updated by the person.

## Capabilities and Constraints

Preserve the current product behavior and these teammate interfaces. The UI calls only:

- `matchBenefits(profile: Profile): Promise<MatchResponse>`
- `simulateLifeEvent(profile: Profile, event: LifeEvent): Promise<SimulationResult>`

Register replacements with `registerBenefitsMatcher` and `registerLifeEventSimulator` (see `src/lib/integration.ts` and `src/main.tsx`). Until then, the labeled demo adapters run. Settings shows each engine as Demo adapter or Live.

Contract the UI relies on:

- `MatchStatus` is only `potential_match`, `more_info_needed`, or `not_matched`. Do not return approved or eligible.
- `MatchResult.missingInfo` feeds “Still needed” and the dashboard’s missing-information panel.
- `SimulationResult.affectedPrograms[].impact` is `review`, `needs_verification`, or `no_link_identified`. Use `needs_verification` plus an `unknowns` entry when data is insufficient.
- Do not return dates, probabilities, or dollar outcomes.
- `before` and `after` snapshots must be the same length and order.
- A rejected promise is an error state with Try again. Loading states show while promises are pending.

Locked:

- No account and no server calls. App data stays in the browser. Income is a range. Onboarding asks about support needs, never diagnoses, records, or ID numbers.
- Never claim eligibility or official application status. Demo engines and illustrative program copy stay labeled as such.
- Accessibility is mandatory. Target WCAG 2.2 AA.

Current, not permanent:

- The catalog is Georgia-first. Catalog scope can change.
- The repo is a hackathon frontend today. That limit can change.

Open:

- Real matcher and life-event engines are not connected.

## Brand Commitments

Name: BenefitsBridge.

Line in use: “Your benefits. Your healthcare. One clear path.”

Binding constraint, recorded without a visual system: avoid generic AI-generated design patterns. Prioritize a premium, usable fintech-style dashboard.

## Evidence on Hand

- Fictional demo profile and seed data for Jordan in `src/lib/demoProfile.ts`. Not a real person. Do not present it as a testimonial or case study.
- Thirteen illustrative program summaries in `src/lib/programs.ts` (`sourceStatus: 'illustrative'`), each with an official URL. Do not add thresholds, dollar amounts, or dates, and do not mark a record `verified` without a real source.
- Demo matcher and simulator in `src/lib/demo/`. They are illustrative signals only.
- No customer quotes, press, pricing, licensing, or deployment commitment. Static hosting is possible because routing is hash-based; no host is chosen.

## Product Principles

1. The life simulator is the decision. Discovery and tracking exist so a life-change preview has somewhere to land.
2. Speak as a guide, not an agency. Possible fit, missing information, and needs verification are the strongest claims.
3. The person’s data stays on their device. No account, and no questions that collect a diagnosis or an ID number.
4. Accessibility is part of the product, at WCAG 2.2 AA, for people whose disability is why they are here.
5. Teammate engines plug in at the existing boundary. The interface does not invent eligibility rules.

## Accessibility & Inclusion

WCAG 2.2 AA is mandatory.

The primary user may be disabled. The reference situation includes wheelchair use and campus disability services. Keep the existing access behavior working: skip link, one `h1` per screen, focus moved to the page heading on route change, keyboard access, visible focus, status shown as icon plus text, labeled fields, errors announced and focused, live regions, text size (Default / Large / Larger), simplified interface, reduced motion (including `prefers-reduced-motion`), and targets at least 36px with most at 44px.
